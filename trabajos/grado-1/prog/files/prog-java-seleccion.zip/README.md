# Selección de prácticas de Programación (2020–2021)

Código conservado de los ZIP originales recibido para el portfolio.

- `laboratorio1/`: primer programa Java.
- `laboratorio2/`: ejercicios iniciales de clases/objetos.
- `practica1/`: pruebas de las abstracciones Punto y Contacto y un pequeño intérprete de comandos.
- `practica3/`: visualización Swing sobre mapa, historial de contactos y pruebas de riesgo.

Los ZIP originales no contienen todas las clases de dominio necesarias para recompilar las prácticas completas; por eso este paquete se presenta como **selección de código conservado**, no como una aplicación ejecutable autónoma. Se han eliminado binarios, metadatos de Eclipse y ficheros auxiliares de evaluación.
