/**
 * 
 */
package es.upm.dit.prog.laboratorio1;

/**
 * @author A
 *
 */
public class HolaATodos {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println ("Hola a todos");
	}

}
