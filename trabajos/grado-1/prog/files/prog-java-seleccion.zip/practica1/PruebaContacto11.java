package es.upm.dit.prog.practica1;

import java.util.Scanner;

import javax.swing.SwingUtilities;

public class PruebaContacto11 {
	private String[] cmds = new String[] {
			"hello", "status", "contacto",
			"punto",
			"help", "exit"};

	private Contacto c;

	public PruebaContacto11() {
		this.c = new Contacto();
	}
	
	public String run (String c) {
		String[] fs = c.split(" ");
		
		if (c.indexOf("hello") >= 0)
			return c;
		if (c.indexOf("status") >= 0) {
			return this.c.toString();
		}
		if (c.indexOf("punto") >= 0) {
			try {
				Punto p = new Punto(Double.parseDouble(fs[1]), Double.parseDouble(fs[2]));
				return p.toString();
			} catch (Exception e) {
				return "punto x y"
						+ "\n x:double y: double"
;
			}
		}
		if (c.indexOf("contacto") >= 0) {
			try {
			this.c = new Contacto (fs[1]
								, new Punto(Double.parseDouble(fs[2]), Double.parseDouble(fs[3]))
								, Long.parseLong (fs[4]), Long.parseLong(fs[5])
								, Double.parseDouble(fs[6]));
			return "" + this.c.toString(); 
			} catch (Exception e) {
				return "contacto id x y fini ffin riesgo"
						+ "\n id:String x:double y: double fini:long ffin:long riesgo:double[0..1]"
;			
				}
		}
		if (c.indexOf("help") >= 0) {
			String r = "";
			for (String ci: cmds)
				r += ci + " ";
			return r;
		}
		if (c.indexOf("exit") >= 0) {
			System.out.println("bye");
			System.exit(0);
		}
		return "";
	}
	
	public boolean ok(String c) {
		c = c.trim();
		for (String cmd : cmds) 
			if (c.indexOf(cmd) >= 0)
				return true;
		return false;
	}
	
	public static void main(String[] args) throws Exception{
		PruebaContacto11 m = new PruebaContacto11();
		Scanner sc= new Scanner(System.in);
		String cmd = "hello";
		do {
			System.out.print ("" + m.run(cmd) + "\n>" );
			cmd = sc.nextLine();   				
		} while (true);
	}
}
