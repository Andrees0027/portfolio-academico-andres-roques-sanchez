package es.upm.dit.prog.practica1;

import static org.junit.Assert.assertEquals;

public class PruebaContacto12 {
	
	public void testPunto1() {
		try {
		Punto p1 = new Punto(0,0);
		System.out.println(p1);
		System.out.println("p1.getX()=" + p1.getX()
		+ "\n***correcto=" + (p1.getX() == 0));
		System.out.println("p1.getY()=" + p1.getY()
		+ "\n***correcto=" + (p1.getY() == 0));
		Punto p2 = new Punto(100, 100);
		System.out.println(p2);
		System.out.println("p2.getX()=" + p2.getX()
		+ "\n***correcto=" + (p2.getX() == 100));
		System.out.println("p2.getY()=" + p2.getY()
		+ "\n***correcto=" + (p2.getY() == 100));

		p2.setX(1000);
		p2.setY(-1000);
		System.out.println("p2.setX(1000); p2.getX()=" + p2.getX()
		+ "\n***correcto=" + (p2.getX() == 1000));
		System.out.println("p2.setY(-1000); p2.getY()=" + p2.getY()
		+ "\n***correcto=" + (p2.getY() == -1000));
		} catch (Exception e) {
			System.out.println("Punto: Error en constructor, accesores o modificadores");
		}
	}
	public void testPunto2() {
		try {
		Punto p1 = new Punto(0,0);
		Punto p2 = new Punto(1000, -1000);
		System.out.println("p1.modulo()=" + p1.modulo()
		+ "\n***correcto=" + (p1.modulo() == 0));
		System.out.println("p2.modulo()=" + p2.modulo()
		+ "\n***correcto=" + (p2.modulo() == 1000*Math.sqrt(2)));

		System.out.println("p1.distancia(p1)=" + p1.distancia(p1)
		+ "\n***correcto=" + (p1.distancia(p1) == 0));
		System.out.println("p2.distancia(p2)=" + p2.distancia(p2)
		+ "\n***correcto=" + (p2.distancia(p2) == 0));
		
		System.out.println("p1.distancia(p2)=" + p1.distancia(p2)
		+ "\n***correcto=" + (p1.distancia(p2) == 1000*Math.sqrt(2)));
		System.out.println("p2.distancia(p1)=" + p2.distancia(p1)
		+ "\n***correcto=" + (p2.distancia(p1) == 1000*Math.sqrt(2)));
		} catch (Exception e) {
			System.out.println("Punto: Error en constructor, módulo o distancia");
		}
	}
	
	public void testContacto1() {
		try {
		Contacto c = new Contacto();
		System.out.println(c);
		System.out.println("c.getId()=" + c.getId()
		+ "\n***correcto=" + (c.getId() == null));
		System.out.println("c.getPos()=" + c.getPos()
		+ "\n***correcto=" + (c.getPos() == null));
		System.out.println("c.getFini()=" + c.getFini()
		+ "\n***correcto=" + (c.getFini() == 0));
		System.out.println("c.getFfin()=" + c.getFfin()
		+ "\n***correcto=" + (c.getFfin() == 0));
		System.out.println("c.getRiesgo()=" + c.getRiesgo()
		+ "\n***correcto=" + (c.getRiesgo() == 0));
		} catch (Exception e) {
			System.out.println("Contacto: Error en constructor sin parámetros o accesores");
		}
	}
	
	public void testContacto2() {
		try {
		Contacto c = new Contacto("111111111", new Punto (100, 100), 10000000, 10000100, 0.9);
		System.out.println(c);
		System.out.println("c.getId()=" + c.getId()
		+ "\n***correcto=" + (c.getId().equals("111111111")));
		System.out.println("c.getPos()=" + c.getPos()
		+ "\n***correcto=" + (c.getPos().equals(new Punto (100, 100))));
		System.out.println("c.getFini()=" + c.getFini()
		+ "\n***correcto=" + (c.getFini() == 10000000));
		System.out.println("c.getFfin()=" + c.getFfin()
		+ "\n***correcto=" + (c.getFfin() == 10000100));
		System.out.println("c.getRiesgo()=" + c.getRiesgo()
		+ "\n***correcto=" + (c.getRiesgo() == 0.9));
		} catch (Exception e) {
			System.out.println("Contacto: Error en constructor con parámetros o accesores");
		}
	}
	
	public void testContacto3() {
		try {
		Contacto c = new Contacto("111111111", new Punto (100, 100), 10000000, 10000100, 0.9);
		System.out.println(c);
		c.setId("222222222");
		System.out.println("c.getId()=" + c.getId()
		+ "\n***correcto=" + (c.getId().equals("222222222")));
		c.setPos(new Punto(200, 200));
		System.out.println("c.getPos()=" + c.getPos()
		+ "\n***correcto=" + (c.getPos().equals(new Punto (200, 200))));
		c.setFini(20000000);
		System.out.println("c.getFini()=" + c.getFini()
		+ "\n***correcto=" + (c.getFini() == 20000000));
		c.setFfin(20000100);
		System.out.println("c.getFfin()=" + c.getFfin()
		+ "\n***correcto=" + (c.getFfin() == 20000100));
		c.setRiesgo(0.1);
		System.out.println("c.getRiesgo()=" + c.getRiesgo()
		+ "\n***correcto=" + (c.getRiesgo() == 0.1));
		} catch (Exception e) {
			System.out.println("Contacto: Error en constructor con parámetros o modificadores");
		}
	}
	
	public void testContacto4() {
		// equals: id, fini, ffin
		try {
			Contacto c1 = new Contacto("111111111", new Punto (100, 100), 10000000, 10000100, 0.9);
			Contacto c2 = new Contacto("111111111", new Punto (100, 100), 10000000, 10000100, 0.9);
			Contacto c3 = new Contacto("111111111", new Punto (0, 0), 10000000, 10000100, 0.0);
			Contacto c4 = new Contacto("111111111", new Punto (100, 100), 0, 10000100, 0.9);
			Contacto c5 = new Contacto("222222222", new Punto (100, 100), 0, 10000100, 0.9);
			System.out.println("c1:" + c1);
			System.out.println("c2:" + c2);
			System.out.println("c1.equals(c2)=" + c1.equals(c2)
			+ "\n***correcto=" + (c1.equals(c2)));

			System.out.println("c1:" + c1);
			System.out.println("c3:" + c3);
			System.out.println("c1.equals(c3)=" + c1.equals(c3)
			+ "\n***correcto=" + (c1.equals(c3)));

			System.out.println("c1:" + c1);
			System.out.println("c4:" + c4);
			System.out.println("c1.equals(c4)=" + c1.equals(c4)
			+ "\n***correcto=" + (! c1.equals(c4)));

			System.out.println("c1:" + c1);
			System.out.println("c5:" + c5);
			System.out.println("c1.equals(c5)=" + c1.equals(c5)
			+ "\n***correcto=" + (! c1.equals(c5)));

		} catch (Exception e) {
			System.out.println("Contacto: Error en equals");			
		}
	}
	
	
	public PruebaContacto12() {
	}
	
	public static void main(String[] args) {
		PruebaContacto12 p = new PruebaContacto12();
		p.testPunto1();
		p.testPunto2();
		p.testContacto1();
		p.testContacto2();
		p.testContacto3();
		p.testContacto4();
		
	}

}
