package es.upm.dit.prog.practica3;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JPanel;


public class MapaPanel extends JPanel {
	private Contacto[] cs;
	private Image im;
	private static final int WIDTH = 1050;
	private static final int HEIGHT = 915;
	private int x0;
	private int y0;
	
	public MapaPanel() {
		setBorder(BorderFactory.createLineBorder(Color.black));
		try {
            this.im = ImageIO.read(new File("madrid.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
		this.x0 = WIDTH / 2;
		this.y0 = HEIGHT / 2;
	}

	public void setContactos (Contacto[] cs) {
		this.cs = (cs != null) ? cs : new Contacto[0];
	}
	
	public Dimension getPreferredSize() {
		return new Dimension(WIDTH,HEIGHT);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);    
		if (this.im == null) {
			g.setColor(Color.black);
			g.fillRect(0,0, this.getWidth(), this.getHeight());
		} else
			g.drawImage(this.im, 0, 0, null);

		g.setColor(Color.white);
		this.linea(g, -this.getWidth() / 2, 0, this.getWidth() / 2, 0); 
		this.linea(g, 0, -this.getHeight() / 2, 0, this.getHeight() / 2);

		Contacto ultimo = null;
		for (int i = 0 ; i < this.cs.length; i++ ) {
			if (this.cs[i] == null)
				continue;
			if ((ultimo != null) && (ultimo.getPos().distancia(this.cs[i].getPos()) > 20)){
				g.setColor(Color.red);
				this.drawArrowLine(g, (int)ultimo.getPos().getX()
									, (int)ultimo.getPos().getY()
									, (int)this.cs[i].getPos().getX()
									, (int)this.cs[i].getPos().getY());
			}
			this.paintContacto (g, this.cs[i]);
			ultimo = this.cs[i];
		}
	}

    public void paintContacto(Graphics g, Contacto a) {
    	if (a.getRiesgo() < 0.4)
    		g.setColor (Color.green);
    	else if (a.getRiesgo() < 0.9)
    		g.setColor (Color.yellow);
    	else g.setColor (Color.red);
    	this.circulo(g, a.getPos().getX(), a.getPos().getY(), 10);
     	this.texto(g, a.getId() + "[" + a.getFini() + "," + a.getFfin() +"]", a.getPos().getX() + 10, a.getPos().getY());
    }
	

    public void texto(Graphics g, String str, double x, double y) {
		g.setColor(Color.black);
    	g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString(str,
    		 (int)Math.round(x+this.x0),
    		 (int)Math.round(this.y0-y));
    }

    public void linea(Graphics g, double x1, double y1, double x2, double y2) {
        g.drawLine((int)Math.round(x1+this.x0),
    	       (int)Math.round(this.y0-y1),
    	       (int)Math.round(x2+this.x0),
    	       (int)Math.round(this.y0-y2));
    }
    
    public void circulo(Graphics g, double x, double y, double radio) {
	   	g.fillOval((int)Math.round(x-radio+this.x0),
	       (int)Math.round(this.y0-y-radio),
	       (int)Math.round(2*radio),
	       (int)Math.round(2*radio));
    }
       
    public void drawArrowLine(Graphics g, int x1, int y1, int x2, int y2) {
    	this.drawArrowLine(g, x1, y1, x2, y2, 20, 6);
    }
    
    /**
     * Draw an arrow line between two points.
     * @param g the graphics component.
     * @param x1 x-position of first point.
     * @param y1 y-position of first point.
     * @param x2 x-position of second point.
     * @param y2 y-position of second point.
     * @param d  the width of the arrow. Default=20
     * @param h  the height of the arrow. Default=6
     */
    public void drawArrowLine(Graphics g, int x1, int y1, int x2, int y2, int d, int h) {
        x1 = this.x0+x1;
        x2 = this.x0+x2;
        y1 = this.y0-y1;
        y2 = this.y0-y2;
  	    int dx = x2 - x1;
        int dy = y2 - y1;
        double D = Math.sqrt(dx*dx + dy*dy);
        double xm = D - d;
        double xn = xm;
        double ym = h;
        double yn = -h;
        double sin = dy / D;
        double cos = dx / D;

        double x = xm*cos - ym*sin + x1;
        ym = xm*sin + ym*cos + y1;
        xm = x;

        x = xn*cos - yn*sin + x1;
        yn = xn*sin + yn*cos + y1;
        xn = x;

        int[] xpoints = {x2, (int) xm, (int) xn};
        int[] ypoints = {y2, (int) ym, (int) yn};

        g.drawLine(x1, y1, x2, y2);
        g.fillPolygon(xpoints, ypoints, 3);
    }
    
    public void limpia(Graphics g, double x1, double y1, double x2, double y2) {
        g.clearRect((int)Math.round(x1+x0),
    		(int)Math.round(y0-y1),
    		(int)Math.round(x2+x0),
    		(int)Math.round(y0-y2));
    }
}
