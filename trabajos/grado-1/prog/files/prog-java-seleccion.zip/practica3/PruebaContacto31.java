package es.upm.dit.prog.practica3;

import java.util.Scanner;

import javax.swing.SwingUtilities;

public class PruebaContacto31 {
	private String[] cmds = new String[] {
			"hello", "status", "contacto",
			"punto", "riesgo",
			"add", "historial", "clear", "show",
			// "filter", "after", "id", "high", "pos", "or", "and", 
			"help", "exit"};

	private Contacto c;
	private HistorialContactos h;
//	private SelectorContacto s1;
//	private SelectorContacto s2;
	
	
	public PruebaContacto31() {
		this.c = new Contacto();
		this.h = new HistorialContactos();
		//this.s1 = new SelectorContactoTrue();
		//this.s2 = new SelectorContactoTrue();
	}
	
	public String run (String c) {
		String[] fs = c.split(" ");
		
		if (c.indexOf("hello") >= 0)
			return c;
		if (c.indexOf("help") >= 0) {
			String r = "";
			for (String ci: cmds)
				r += ci + " ";
			return r;
		}
		if (c.indexOf("exit") >= 0) {
			System.out.println("bye");
			System.exit(0);
		}
		if (c.indexOf("status") >= 0) {
			return this.c.toString() + this.h.toString(); //+ this.s1 + this.s2 + this.m;
		}
		if (c.indexOf("punto") >= 0) {
			try {
				Punto p = new Punto(Double.parseDouble(fs[1]), Double.parseDouble(fs[2]));
				return p.toString();
			} catch (Exception e) {
				return "punto x y"
						+ "\n x:double y: double"
;
			}
		}
		if (c.indexOf("contacto") >= 0) {
			try {
			this.c = new Contacto (fs[1]
								, new Punto(Double.parseDouble(fs[2]), Double.parseDouble(fs[3]))
								, Long.parseLong (fs[4]), Long.parseLong(fs[5])
								, Double.parseDouble(fs[6]));
			return "" + this.c.toString(); 
			} catch (Exception e) {
				return "contacto id x y fini ffin riesgo"
						+ "\n id:String x:double y: double fini:long ffin:long riesgo:double[0..1]"
;			
				}
		}
		if (c.indexOf("riesgo") >= 0) {
			try {
			Riesgo r = new Riesgo();
			return ""+ r.riesgo (Long.parseLong (fs[2]) - Long.parseLong(fs[1])
	                  , Double.parseDouble(fs[3]), fs[4].equals("1") ? true : false
	                  , Integer.parseInt(fs[5]), Integer.parseInt(fs[6]));	
			} catch (Exception e) {
				return "riesgo fini ffin density special emission ventilation"
						+ "\n fini:long ffin:long density:double special:0/1 emission:[0..2] ventilation:double"
;			}
		}
		if (c.indexOf("add") >= 0) {
			if (this.c.getId() != null)
				this.h.add(this.c);
			return this.h.toString();
		}
		if (c.indexOf("historial") >= 0)
			return this.h.toString();
		if (c.indexOf("clear") >= 0) {
			this.c = new Contacto();
			this.h = new HistorialContactos();
			//this.s1 = new SelectorContactoTrue();
			//this.s2 = new SelectorContactoTrue();
			return this.h.toString();
		}
		if (c.indexOf("show") >= 0) {
			SwingUtilities.invokeLater(new Runnable() {
	            public void run() {
	                Visualizador pva = new Visualizador();
	                pva.init(h); //s1));
	                pva.createAndShowGUI();
	            }
	        });
			return "";
		}
		if (c.indexOf("filter") >= 0) {
			return this.h.getRiesgoAlto().toString();
		}
		
		/*
		if (c.indexOf("filter") >= 0) {
			return this.h.getContactos(this.s1).toString();
		}
		if (c.indexOf("after") >= 0) {
			try {
			this.s2 = this.s1;
			this.s1 = new SelectorContactoPosteriorA(Long.parseLong (fs[1]));
			return "SelectorContactoPosteriorA("+fs[1]+")";
			} catch (Exception e) {
				return "after fini:long";
			}
		}
		if (c.indexOf("id") >= 0) {
			try {
			this.s2 = this.s1;
			this.s1 = new SelectorContactoId(fs[1]);
			return "SelectorContactoId("+fs[1]+")";
			} catch (Exception e) {
				return "id id:String";
			}
		}
		if (c.indexOf("pos") >= 0) {
			try {this.s2 = this.s1;
			this.s1 = new SelectorContactoPos(new Punto(Double.parseDouble(fs[1]), Double.parseDouble(fs[2])));
			return "SelectorContactoPos("+fs[1]+"," + fs[2] + ")";
			} catch(Exception e) {
				return "pos x:double y:double";
			}
		}
		if (c.indexOf("high") >= 0) {
			this.s2 = this.s1;
			this.s1 = new SelectorContactoRiesgoAlto();
			return "SelectorContactoRiesgoAlto()";
		}
		if (c.indexOf("and") >= 0) {
			SelectorContacto ss = new SelectorContactoY(this.s1, this.s2);
			this.s2 = this.s1;
			this.s1 = ss;
			return "SelectorContactoY()";
		}
		if (c.indexOf("or") >= 0) {
			SelectorContacto ss = new SelectorContactoO(this.s1, this.s2);
			this.s2 = this.s1;
			this.s1 = ss;
			return "SelectorContactoO()";
		}
*/
		return "";
	}
	
	public static void main(String[] args) throws Exception{
		PruebaContacto31 m = new PruebaContacto31();
		Scanner sc= new Scanner(System.in);
		String cmd = "hello";
		do {
			System.out.print ("" + m.run(cmd) + "\n>" );
			cmd = sc.nextLine(); 				
		} while (true);
	}
}
