package es.upm.dit.prog.practica3;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

import es.upm.dit.prog.practica3.Contacto;

public class PruebaContacto32 {

	private double delta = 0.1;

	public boolean assertEquals (String msg, double expected, double obtained, double delta) {
		System.out.println (msg + "expected: " + expected + " obtained: " + obtained);
		return (Math.abs (expected - obtained) <= delta);
	}
	
	public boolean assertEquals (String msg, int expected, int obtained) {
		return assertEquals(msg, expected, obtained, 0.0);
	}
	
	public boolean assertArrayEquals(String msg, Contacto[] expected, Contacto[] obtained) {
		if (expected.length != obtained.length) {
			System.out.println(msg + " expected: " + expected.length + " obtained: " + obtained.length);
			return false;
		}
		//Arrays.sort(expected, (c1, c2) -> (int) (c1.getFini() - c2.getFini()));	
		//Arrays.sort(obtained, (c1, c2) -> (int) (c1.getFini() - c2.getFini()));
		for (int i = 0; i < expected.length; i++)
			if ((expected[i] != null) && (obtained[i] != null) && (! expected[i].equals(obtained[i]))) {
				System.out.println(msg + "[ " + i + "] expected: " + expected[i] + " obtained: " + obtained[i]);
				return false;
			}
		System.out.println(msg + " ok");
		return true;
	}

	//@Test (timeout=500)
	public void testCtor0() {
		// ctor: vacio, accesor
		HistorialContactos h = new HistorialContactos();
		assertEquals("new HistorialContactos(); getContactos().length== 10", 10, h.getContactos().length);
	}

	//@Test (timeout=500)
	public void testCtor1() {
		// ctor: con parámetro, accesor
		HistorialContactos h = new HistorialContactos(new Contacto[0]);
		assertEquals("new HistorialContactos(new Contacto[0]); getContactos().length== 0", 0, h.getContactos().length);
		h = new HistorialContactos(new Contacto[100]);
		assertEquals("new HistorialContactos(new Contacto[100]); getContactos().length== 100", 100, h.getContactos().length);
	}
	
	//@Test (timeout=500)
	public void testAdd1() {
		// add: vacio, primero
		HistorialContactos h = new HistorialContactos();
		Contacto c1 = new Contacto ("000000000", new Punto(0, 0), 0, 0, 0);
		Contacto[] r = new Contacto[] {c1, null, null, null, null, null, null, null, null, null};
		h.add(c1);
		assertArrayEquals("add("+ c1.toString()+ ")", r, h.getContactos());
	}

	//@Test (timeout=500)
	public void testAdd2() {
		// add: intermedio, final
		HistorialContactos h = new HistorialContactos();
		Contacto[] r = new Contacto[10];
		for (int i = 0; i < r.length; i++) {
			r[i] = new Contacto("00000000" + i, new Punto(i, i), 1000000+i, 1000100+i, 1);
			h.add(r[i]);
		}
		assertArrayEquals("add(array completo)", r, h.getContactos());
	}

	//@Test (timeout=500)
	public void testAdd3() {
		// add: intermedio, final
		HistorialContactos h = new HistorialContactos();
		Contacto[] rr = new Contacto[15];
		for (int i = 0; i < rr.length; i++) {
			rr[i] = new Contacto("00000000" + i, new Punto(i, i), 1000000+i, 1000100+i, 1);
			h.add(rr[i]);
		}
		Contacto[] r = new Contacto[10];
		for (int i = 0; i < r.length; i++)
			r[i]=rr[rr.length - r.length + i];
		assertArrayEquals("add(array mayor 10)", r, h.getContactos());
	}

	//@Test (timeout=500)
	public void testGetHistorialContactos1() {
		// getContactos(): vacio
		HistorialContactos h = new HistorialContactos();
		assertArrayEquals("new HistorialContactos(); getHistorialContactos().getContactos()"
				, new Contacto[0], h.getHistorialContactos().getContactos());
	}
	
	//@Test (timeout=500)
	public void testGetHistorialContactos2() {
		HistorialContactos h = new HistorialContactos();
		Contacto[] r = new Contacto[10];
		for (int i = 0; i < r.length; i++) {
			r[i] = new Contacto("00000000" + i, new Punto(i, i), 1000000+i, 1000100+i, 1);
			h.add(r[i]);
		}
		assertArrayEquals("add(array);getHistorialContactos().getContactos()", r, h.getHistorialContactos().getContactos());
	}

	//@Test (timeout=500)
	public void testGetHistorialContactos3() {
		// getContactos(): todos
		HistorialContactos h = new HistorialContactos();
		Contacto[] rr = new Contacto[15];
		for (int i = 0; i < rr.length; i++) {
			rr[i] = new Contacto("00000000" + i, new Punto(i, i), 1000000+i, 1000100+i, 1);
			h.add(rr[i]);
		}
		Contacto[] r = new Contacto[10];
		for (int i = 0; i < r.length; i++)
			r[i]=rr[rr.length - r.length + i];
		assertArrayEquals("add(array mayor 10);getHistorialContactos().getContactos()", r, h.getHistorialContactos().getContactos());
	}

	//@Test (timeout=500)
	public void testGetRiesgoAlto1() {
		// getContactos(): vacio
		HistorialContactos h = new HistorialContactos();
		assertArrayEquals("new HistorialContactos(); getRiesgoAlto().getContactos()"
				, new Contacto[0], h.getRiesgoAlto().getContactos());
	}
	
	//@Test (timeout=500)
	public void testGetRiesgoAlto2() {
		HistorialContactos h = new HistorialContactos();
		Contacto[] r = new Contacto[10];
		for (int i = 0; i < r.length; i++) {
			r[i] = new Contacto("00000000" + i, new Punto(i, i), 1000000+i, 1000100+i, 0.1 * (i+1));
			h.add(r[i]);
		}
		assertArrayEquals("add(array);getRiesgoAlto().getContactos()", new Contacto [] {r[8], r[9]}, h.getRiesgoAlto().getContactos());
	}

	
	public static void main(String[] args) {
		PruebaContacto32 p = new PruebaContacto32();
		p.testCtor0();
		p.testCtor1();
		p.testAdd1();
		p.testAdd2();
		p.testAdd3();
		p.testGetHistorialContactos1();
		p.testGetHistorialContactos2();
		p.testGetHistorialContactos3();
		p.testGetRiesgoAlto1();
		p.testGetRiesgoAlto2();		
	}
}
