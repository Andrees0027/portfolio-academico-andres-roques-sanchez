package es.upm.dit.prog.practica3;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Visualizador {
	private Contacto[] tc;
    private JFrame f;
	private MapaPanel rp;
	
    public void init(HistorialContactos h) {
    	Contacto[] cs = h.getHistorialContactos().getContactos();
    	if (cs.length > 1)
    	Arrays.sort(cs, (c1, c2) -> (int) (c1.getFini() - c2.getFini()));
    	this.tc = cs; 
    }
 	
    public void createAndShowGUI() {
        System.out.println("Launching PruebaContactos " + 
                SwingUtilities.isEventDispatchThread());
        this.f = new JFrame("PruebaContactos ");
        //this.f.setResizable(false);
        this.f.setLayout(new BorderLayout());
        this.f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);    
 
        this.rp = new MapaPanel();
        this.f.add(this.rp, BorderLayout.CENTER);
        this.rp.setContactos(this.tc); 
        this.f.pack();
    	this.f.setVisible(true);
    }
}

