----------------------------------------------------------------------------------
-- MUX4x8

--  Multiplexor de 4 entradas de 8 bits
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity MUX4x8 is
    Port ( E0 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 0
           E1 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 1
           E2 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 2
           E3 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 3
           S : in  STD_LOGIC_VECTOR (1 downto 0);  -- Se�al de control
           Y : out  STD_LOGIC_VECTOR (7 downto 0)); -- Salida
end MUX4x8;

architecture a_MUX4x8 of MUX4x8 is

begin

      -- La selecci�n de entrada a poner en la salida..
    Y <= E0 when S = "00" else
        E1 when S = "01" else
        E2 when S = "10" else
        E3 when S = "11" else
        "11111111";

end a_MUX4x8;

