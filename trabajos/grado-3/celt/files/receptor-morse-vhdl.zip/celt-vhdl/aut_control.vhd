----------------------------------------------------------------------------------
-- 
-- Aut�mata de control del receptor
-- Toma los datos del aut�mata de medida de duraciones y construye el 
-- c�digo morse de los caracteres que van apareciendo en la l�nea.
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity aut_control is
  Port ( CLK       : in STD_LOGIC;    -- reloj
      VALID_INT : in STD_LOGIC;    -- entrada de intervalo v�lido
      DATO      : in STD_LOGIC;    -- dato (0 o 1)
      DURACION  : in STD_LOGIC_VECTOR (15 downto 0); -- duraci�n del intervalo
      CODIGO    : out  STD_LOGIC_VECTOR (7 downto 0); -- c�digo morse obtenido  
      VALID_COD : out  STD_LOGIC);                   -- validaci�n del c�digo
end aut_control;                                            

architecture a_aut_control  of aut_control is

constant UMBRAL0 : integer := 200;  -- umbral para los 0
constant UMBRAL1 : integer := 200;  -- umbral para los 1

type STATE_TYPE is (ESPACIO,RESET,SIMBOLO,ESPERA);

signal ST : STATE_TYPE := RESET;
signal s_ncod : STD_LOGIC_VECTOR (2 downto 0):="000";
signal s_cod  : STD_LOGIC_VECTOR (4 downto 0):="00000";
signal n : INTEGER range 0 to 4;
begin

process (CLK)   -- Aut�mata digital s�ncrono
  begin
    if (CLK'event and CLK='1') then
      case ST is
        when RESET =>
          n <= 4;
			 s_ncod<="000";
			 s_cod<="00000";
			 if (VALID_INT='1' and DATO='1') then
				ST<=SIMBOLO;
			 else
				ST<=RESET;		  
			 end if;
        when SIMBOLO =>
          n <= n-1;
			 s_ncod <= s_ncod+1;
			 if (DURACION>UMBRAL1) then
				s_cod(n)<='1';
			 else
				s_cod(n)<='0';		  
			 end if;
			 ST<=ESPERA;
        when ESPERA =>
			 if (VALID_INT='1' and DATO='1') then
				ST <= SIMBOLO;
			 else if (VALID_INT='1' and DATO='0' and DURACION>UMBRAL0) then
				ST <= ESPACIO;				  
			 end if;	 
			 end if;
        when ESPACIO =>
				ST <= RESET;
      end case;
    end if;
  end process;
  
-- CABLEADOS DE LAS SALIDAS

VALID_COD<='1' when ST=ESPACIO  else '0';
CODIGO(4 downto 0)<= s_cod ;              -- Complete las asignaciones
CODIGO(7 downto 5)<= s_ncod ;
end a_aut_control ;
