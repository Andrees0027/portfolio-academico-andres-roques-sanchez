----------------------------------------------------------------------------------
-- 
-- Aut�mata que mide la duraci�n de los 0 y los 1 que entran por LIN
--
-- El dato y la duraci�n son v�lidos cuando la salida VALID=1
-- Se mide en intervalos de 1 ms
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


entity aut_duracion is
  Port ( CLK       : in  STD_LOGIC;    -- reloj de 1 ms
         LIN       : in  STD_LOGIC;    -- l�nea de entrada de datos
         VALID_INT : out  STD_LOGIC;   -- salida de validaci�n de intervalo
         DATO      : out  STD_LOGIC;   -- salida de dato (0 o 1) 
         DURACION  : out  STD_LOGIC_VECTOR (15 downto 0)); -- salida de 
end aut_duracion;                                   -- duraci�n del intervalo      

architecture a_aut_duracion of aut_duracion is

type STATE_TYPE is (CONTAR,VALIDAR,RESET);
signal ST : STATE_TYPE := RESET;
signal cont : STD_LOGIC_VECTOR (15 downto 0):="0000000000000000";
signal dato_act : STD_LOGIC:= '0';

begin
process (CLK)  -- Aut�mata digital s�ncrono
  begin
    if (CLK'event and CLK='1') then
      case ST is      			 
        when RESET =>
          cont<="0000000000000010";
          dato_act<=LIN;
          ST<=CONTAR; 
		  when CONTAR =>
				cont<=cont+1;		  
			 if ((cont > 600) or (LIN /= dato_act)) then
				ST<=VALIDAR;
			 end if;
		  when VALIDAR =>
			 ST<=RESET;
      end case;	
    end if;
  end process;

-- CABLEADOS DE LAS SALIDAS
  
VALID_INT <='1' when ST=VALIDAR else '0';
DATO <= dato_act;
DURACION <= cont;

end a_aut_duracion;	

