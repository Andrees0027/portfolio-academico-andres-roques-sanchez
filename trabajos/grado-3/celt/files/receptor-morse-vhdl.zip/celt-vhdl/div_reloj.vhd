----------------------------------------------------------------------------------
--
-- Divisor de la frecuencia del reloj a 1 KHz.
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity div_reloj is
    Port ( CLK_50MHz : in  STD_LOGIC;       -- Entrada reloj de la FPGA 50 MHz -- T=1/f=2*10^-8=2ns
           CLK       : out  STD_LOGIC);     -- Salida reloj a 1 KHz -- T=1/f=1ms
end div_reloj;

architecture a_div_reloj of div_reloj is

signal contador : STD_LOGIC_VECTOR (15 downto 0);  -- contador
signal frec_div : STD_LOGIC;                       -- se�al de frecuencia dividida

begin

process(CLK_50MHz)
  begin
  if (CLK_50Mhz'event and CLK_50MHz='1') then  -- En cada flanco de subida
    contador<=contador+1;                      -- Incrementar el contador
	 if (contador>=25000) then                  -- cuando alcanza el valor m�ximo T/2 !!!!
	   contador<=(others=>'0');                 -- Poner el contador a 0
		frec_div<=not frec_div;                  -- e intercambiar el valor de frec_div
	 end if;
  end if;
  
  end process;
  
CLK<=frec_div;                                 -- La salida es la se�al frec_div

end a_div_reloj;

