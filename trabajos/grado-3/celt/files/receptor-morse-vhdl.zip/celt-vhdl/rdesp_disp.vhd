----------------------------------------------------------------------------------
-- 
-- Registro de desplazamiento para la visualizaci�n. Los displays se mueven
-- hacia la izquierda cada vez que se activa el ENABLE y entra un nuevo dato por la
-- ENTRADA.
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity rdesp_disp is
    Port ( CLK     : in   STD_LOGIC;                       -- entrada de reloj
	        ENABLE  : in   STD_LOGIC;                       -- enable 
           ENTRADA : in   STD_LOGIC_VECTOR (7 downto 0);   -- entrada de datos
           Q0      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q0
           Q1      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q1
           Q2      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q2
           Q3      : out  STD_LOGIC_VECTOR (7 downto 0));  -- salida Q3
end rdesp_disp;

architecture a_rdesp_disp of rdesp_disp is
	signal A0 : STD_LOGIC_VECTOR (7 downto 0) := (others=>'0'); 
	signal A1 : STD_LOGIC_VECTOR (7 downto 0) := (others=>'0'); 
	signal A2 : STD_LOGIC_VECTOR (7 downto 0) := (others=>'0'); 
	signal A3 : STD_LOGIC_VECTOR (7 downto 0) := (others=>'0'); 


begin

	process (CLK) -- el proceso se dispara cada vez que cambia el reloj
	begin
		if CLK'event and CLK='1' then
			if ENABLE ='1' then
				A3<=A2; 
				A2<=A1;
				A1<=A0;
				A0<=ENTRADA;
			end if;
		end if;
	end process;
		Q0 <= A0;
		Q1 <= A1;
		Q2 <= A2;
		Q3 <= A3;		
end a_rdesp_disp;


