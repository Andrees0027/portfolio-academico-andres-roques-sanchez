----------------------------------------------------------------------------------
-- 
-- Receptor Morse: pr�ctica completa
--
-- Decodifica la se�al serie de 0 y 1 que entra por la entrada DAT y obtiene
-- los caracteres gr�ficos para visualizar por el display.
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity receptor is
    Port ( CLK_50MHz : in  STD_LOGIC;       -- reloj de la FPGA (50 MHz)
           DAT  : in  STD_LOGIC;       -- L�nea de entrada de datos
           SEG7 : out  STD_LOGIC_VECTOR (0 to 6);      -- Salida para los displays 
           AN   : out  STD_LOGIC_VECTOR (3 downto 0)); -- Activaci�n individual
end receptor;

architecture a_receptor of receptor is

component visualizacion is
  Port ( ENTRADA : in STD_LOGIC_VECTOR (7 downto 0);   -- Entrada sig. Car�cter
         ENABLE  : in STD_LOGIC;            -- Activaci�n para desplazamiento
         CLK  : in STD_LOGIC;                       -- Entrada de reloj 
         SEG7 : out STD_LOGIC_VECTOR (0 to 6);      -- Segmentos displays 
         AN   : out STD_LOGIC_VECTOR (3 downto 0)); -- Activaci�n displays
end component;

component aut_control is
  Port ( CLK       : in STD_LOGIC;    -- reloj
			VALID_INT : in STD_LOGIC;    -- entrada de intervalo v�lido
			DATO      : in STD_LOGIC;    -- dato (0 o 1)
			DURACION  : in STD_LOGIC_VECTOR (15 downto 0); -- duraci�n del intervalo
			CODIGO    : out  STD_LOGIC_VECTOR (7 downto 0); -- c�digo morse obtenido  
			VALID_COD : out  STD_LOGIC);
end component;

component aut_duracion is
  Port ( CLK       : in  STD_LOGIC;    -- reloj de 1 ms
         LIN       : in  STD_LOGIC;    -- l�nea de entrada de datos
         VALID_INT : out  STD_LOGIC;   -- salida de validaci�n de intervalo
         DATO      : out  STD_LOGIC;   -- salida de dato (0 o 1) 
         DURACION  : out  STD_LOGIC_VECTOR (15 downto 0));
end component;

component detector_flanco is
  Port ( CLK      : in  STD_LOGIC;    -- reloj
         DAT      : in  STD_LOGIC;    -- L�nea de datos
         LIN      : out  STD_LOGIC);  -- Valor detectado en el flanco
end component;

component div_reloj is 
    Port ( CLK_50MHz : in  STD_LOGIC;       -- Entrada reloj de la FPGA 50 MHz -- T=1/f=2*10^-8=2ns
           CLK       : out  STD_LOGIC);     -- Salida reloj a 1 KHz -- T=1/f=1ms
end component;

signal ANDRES1 : STD_LOGIC;
signal ANDRES2 : STD_LOGIC;
signal ANDRES3 : STD_LOGIC;
signal ANDRES4 : STD_LOGIC_VECTOR (15 downto 0);
signal ANDRES5 : STD_LOGIC_VECTOR (7 downto 0);
signal ANDRES6 : STD_LOGIC;
signal reloj : STD_LOGIC;

begin

  U1 : visualizacion port map (
			CLK => reloj,
			ENTRADA => ANDRES5,
			ENABLE => ANDRES6,
			SEG7 => SEG7,
			AN => AN
			);
			
	U2 : aut_control port map (
			CLK => reloj,	
			VALID_INT => ANDRES2,
			DATO => ANDRES3,
			DURACION => ANDRES4,
			CODIGO => ANDRES5,
			VALID_COD => ANDRES6
			);			
			
	U3 : aut_duracion port map (
			CLK => reloj,	
			LIN => ANDRES1,
			VALID_INT => ANDRES2,
			DATO => ANDRES3,
			DURACION => ANDRES4
			);

	U4 : detector_flanco port map (
			CLK => reloj,	
			LIN => ANDRES1,
			DAT => DAT
			);
			
	U5 : div_reloj port map (
			CLK_50MHz => CLK_50MHz,	
			CLK => reloj
			);			
			
			

end a_receptor;
