----------------------------------------------------------------------------------
-- refresco

-- Circuito que refresca los displays peri�dicamente
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity refresco is
    Port ( CLK : in  STD_LOGIC;                      -- reloj de refresco
           S : out  STD_LOGIC_VECTOR (1 downto 0);   -- Control para el mux
           AN : out  STD_LOGIC_VECTOR (3 downto 0)); -- Control displays individuales
end refresco;

architecture a_refresco of refresco is
	signal sel_mux : unsigned (1 downto 0) :="00"; -- se�al para controlar el mux
	begin
		process (CLK) -- el proceso se dispara cada vez que cambia el reloj
		begin
			if CLK'event and CLK='1' then -- En cada flanco de subida
				sel_mux<=sel_mux+1;
			end if;
		end process;
	
	S <= STD_LOGIC_VECTOR(sel_mux); -- Se cablea S con la se�al sel_mux
	
	AN<="0111" when sel_mux = "00" else -- La se�al AN se cablea de modo que se activa
		 "1011" when sel_mux = "01" else -- cada display
		 "1101" when sel_mux = "10" else -- en funci�n del valor de sel_mux
		 "1110" when sel_mux = "11"; -- Los displays se encienden con un '0'
end a_refresco;

