--------------------------------------------------------------------------------
-- 
-- Test del aut�mata de control
--
-- Departamento de Ingenier�a Electr�nica 2022
--
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY tb_aut_control IS
END tb_aut_control;
 
ARCHITECTURE behavior OF tb_aut_control IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT aut_control
    PORT(
         CLK : IN  std_logic;
         VALID_INT : IN  std_logic;
         DATO : IN  std_logic;
         DURACION : IN std_logic_vector (15 downto 0);
         CODIGO : OUT  std_logic_vector(7 downto 0);
         VALID_COD : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal VALID_INT : std_logic := '0';
   signal DATO : std_logic := '0';
   signal DURACION : std_logic_vector (15 downto 0) :="0000000000000000";

 	--Outputs
   signal CODIGO : std_logic_vector(7 downto 0);
   signal VALID_COD : std_logic;

   -- Clock period definitions
   constant CLK_period : time := 1 ms;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: aut_control PORT MAP (
          CLK => CLK,
          VALID_INT => VALID_INT,
          DATO => DATO,
          DURACION => DURACION,
          CODIGO => CODIGO,
          VALID_COD => VALID_COD
        );

   -- Clock process definitions
   CLK_1ms_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
	   VALID_INT<='0';      -- INICIO
		DATO<='0';
		DURACION<="0000000000000000"; -- 100
		wait for 200 ms;
		
      VALID_INT<='1';      -- PUNTO
		DATO<='1';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PAUSA
		DATO<='0';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 300 ms;
		
		VALID_INT<='1';      -- RAYA
		DATO<='1';
		DURACION<="0000000100101100"; -- 300
      wait for 1 ms;
		VALID_INT<='0';
		wait for 300 ms;
		
		VALID_INT<='1';      -- ESPACIO
		DATO<='0';
		DURACION<="0000000100101100"; -- 300
      wait for 1 ms;
		VALID_INT<='0';
		wait for 300 ms;
		
		VALID_INT<='1';      -- RAYA
		DATO<='1';
		DURACION<="0000000100101100"; -- 300
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PAUSA
		DATO<='0';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PUNTO
		DATO<='1';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PAUSA
		DATO<='0';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PUNTO
		DATO<='1';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PAUSA
		DATO<='0';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		VALID_INT<='1';      -- PUNTO
		DATO<='1';
		DURACION<="0000000001100100"; -- 100
      wait for 1 ms;
		VALID_INT<='0';
		wait for 300 ms;
		
		VALID_INT<='1';      -- ESPACIO
		DATO<='0';
		DURACION<="0000000100101100"; -- 300
      wait for 1 ms;
		VALID_INT<='0';
		wait for 100 ms;
		
		

      wait;
   end process;

END;
