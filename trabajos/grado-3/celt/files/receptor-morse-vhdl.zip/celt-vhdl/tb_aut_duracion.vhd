--------------------------------------------------------------------------------
-- 
-- Test para el aut�mata medidor de duraci�n
--
-- Departamento de Ingenier�a Electr�nica 2022
--
--------------------------------------------------------------------------------

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY tb_aut_duracion IS
END tb_aut_duracion;
 
ARCHITECTURE behavior OF tb_aut_duracion IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT aut_duracion
    PORT(
         CLK : IN  std_logic;
         LIN : IN  std_logic;
         VALID_INT : OUT  std_logic;
         DATO : OUT  std_logic;
         DURACION : OUT  std_logic_vector(15 downto 0)
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal LIN : std_logic := '0';

 	--Outputs
   signal VALID_INT : std_logic;
   signal DATO : std_logic;
   signal DURACION : std_logic_vector(15 downto 0);

   -- Clock period definitions
   constant CLK_period : time := 1 ms;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: aut_duracion PORT MAP (
          CLK => CLK,
          LIN => LIN,
          VALID_INT => VALID_INT,
          DATO => DATO,
          DURACION => DURACION
        );

   -- Clock process definitions
   CLK_1ms_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
	   LIN<='0';
      wait for 100 ms;	

      LIN<='1';
      wait for 300 ms;	
		LIN<='0';
      wait for 100 ms;	
		LIN<='1';
      wait for 100 ms;	
		LIN<='0';
      wait for 300 ms;	
		LIN<='1';
      wait for 300 ms;		
		LIN<='0';
		wait for 700 ms;
 
      
      wait;
   end process;

END;
