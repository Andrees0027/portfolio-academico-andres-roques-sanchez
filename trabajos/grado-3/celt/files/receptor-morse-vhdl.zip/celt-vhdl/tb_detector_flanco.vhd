--------------------------------------------------------------------------------
-- 
-- Test para el detector de flanco
--
-- Departamento de Ingenier�a Electr�nica 2022
--
--------------------------------------------------------------------------------

LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
ENTITY tb_detector_flanco IS
END tb_detector_flanco;
 
ARCHITECTURE behavior OF tb_detector_flanco IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT detector_flanco
    PORT(
         CLK : IN  std_logic;
         DAT : IN  std_logic;
         LIN : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal CLK : std_logic := '0';
   signal DAT : std_logic := '0';

 	--Outputs
   signal LIN : std_logic;

   -- Clock period definitions
   constant CLK_period : time := 1 ms;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: detector_flanco PORT MAP (
          CLK => CLK,
          DAT => DAT,
          LIN => LIN
        );

   -- Clock process definitions
   CLK_1ms_process :process
   begin
		CLK <= '0';
		wait for CLK_period/2;
		CLK <= '1';
		wait for CLK_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
	   DAT<='0';
      wait for 15 ms;	

      -- glitches
 
      DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 25 ms;
		
		-- flanco de subida con rebotes
 
      DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 100 ms;
		
		-- glitches
 
      DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 25 ms;
		
		-- flanco de bajada con rebotes
		
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 1 ms;
		DAT<='1';
		wait for 1 ms;
		DAT<='0';
		wait for 100 ms;
		
		
      wait;
   end process;

END;
