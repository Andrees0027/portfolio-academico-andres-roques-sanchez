----------------------------------------------------------------------------------
-- 
-- M�dulo de visualizaci�n, agrupa los elementos para presentar los datos
-- en los displays de forma que se desplacen hacia la izquierda. 
--
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity visualizacion is
  Port ( ENTRADA : in STD_LOGIC_VECTOR (7 downto 0);   -- Entrada sig. Car�cter
         ENABLE  : in STD_LOGIC;     				       -- Activaci�n para desplazamiento
         CLK     : in STD_LOGIC;                       -- Entrada de reloj 
         SEG7    : out STD_LOGIC_VECTOR (0 to 6);      -- Segmentos displays 
         AN     : out STD_LOGIC_VECTOR (3 downto 0));  -- Activaci�n displays
end visualizacion;

architecture a_visualizacion of visualizacion is

-- COMPONENTES

component decodmorsea7s is
    Port ( CODIGO    : in  STD_LOGIC_VECTOR (7 downto 0);    -- Entrada del c�digo morse
           SEGMENTOS : out  STD_LOGIC_VECTOR (0 to 6));  -- Salidas al display
end component;

component refresco is
    Port ( CLK : in  STD_LOGIC;  
           S : out  STD_LOGIC_VECTOR (1 downto 0); 
			  AN : out  STD_LOGIC_VECTOR (3 downto 0));
end component;

component MUX4x8 is
   Port ( E0 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 0
           E1 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 1
           E2 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 2
           E3 : in  STD_LOGIC_VECTOR (7 downto 0); -- Entrada 3
           S : in  STD_LOGIC_VECTOR (1 downto 0);  -- Se�al de control
           Y : out  STD_LOGIC_VECTOR (7 downto 0)); -- Salida
end component;

component rdesp_disp is
	Port ( CLK     : in   STD_LOGIC;                       -- entrada de reloj
	        ENABLE  : in   STD_LOGIC;                       -- enable 
           ENTRADA : in   STD_LOGIC_VECTOR (7 downto 0);   -- entrada de datos
           Q0      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q0
           Q1      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q1
           Q2      : out  STD_LOGIC_VECTOR (7 downto 0);   -- salida Q2
           Q3      : out  STD_LOGIC_VECTOR (7 downto 0));  -- salida Q3
end component;
    
signal ADRI1 : STD_LOGIC_VECTOR (7 downto 0);
signal ADRI2 : STD_LOGIC_VECTOR (7 downto 0);
signal ADRI3 : STD_LOGIC_VECTOR (7 downto 0);
signal ADRI4 : STD_LOGIC_VECTOR (7 downto 0);
signal s_mux : STD_LOGIC_VECTOR (1 downto 0);
signal s_datos : STD_LOGIC_VECTOR (7 downto 0);

begin

   U1 : decodmorsea7s port map (
			CODIGO => s_datos,
			SEGMENTOS => SEG7
			);
			
	U2 : refresco port map (
			CLK => CLK,
			AN => AN,
			S => s_mux
			);

	U3 : MUX4x8 port map (	
			E0 => ADRI1,
			E1 => ADRI2,
			E2 => ADRI3,
			E3 => ADRI4,
			S => s_mux,
			Y => s_datos
			);
			
	U4 : rdesp_disp port map (
			CLK=>CLK,
			ENTRADA=>ENTRADA,
			ENABLE=>ENABLE,
			Q0=>ADRI1,
			Q1=>ADRI2,
			Q2=>ADRI3,
			Q3=>ADRI4
			);
			
end a_visualizacion;




