# Blog CORE — práctica final publicada

Versión curada de la práctica P10 (Roles).

Se han eliminado `node_modules`, bases de datos locales, repositorios Git, `user.json`,
autocorrectores, `package-lock.json`, la fotografía y la vista de autor con datos personales.
La clave de sesión hardcodeada se sustituye por `SESSION_SECRET` con un valor local de ejemplo.

La aplicación mantiene el código de posts, usuarios, sesiones, autores, migraciones, seeders,
roles y autorización que forma el resultado final de la progresión P7–P10.
