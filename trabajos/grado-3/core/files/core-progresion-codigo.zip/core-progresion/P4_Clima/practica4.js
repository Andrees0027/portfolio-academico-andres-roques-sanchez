const fs = require("fs/promises");

exports.load = async (cities) => {
    const buf = await fs.readFile(cities)
    return JSON.parse(buf);
}

// export { load_ as load };


exports.max_temp = (cities) => {
    let res = -Infinity;
    for (let c of cities){
        if (c.main.temp > res){
            res = c.main.temp; 
        }
    }
    return res;
}
// export { max_temp_ as max_temp };

exports.min_temp = (cities) => {
    return Math.min (...cities.map( c => c.main.temp));
}
// export { min_temp_ as min_temp };

exports.max_temp_min = (cities) => {
    let res = -Infinity;
    for (let c of cities){
        if (c.main.temp_min > res){
            res = c.main.temp_min; 
        }
    }
    return res;
}
// export { max_temp_min_ as max_temp };

exports.min_temp_max = (cities) => {
    let res = Infinity;
    for (let c of cities){
        if (c.main.temp_max < res){
            res = c.main.temp_max; 
        }
    }
    return res;
}
// export { max_temp_max_ as max_temp_max };

exports.average_temp = (cities) => {
    let suma = 0;
    for ( let c of cities){
        suma += c.main.temp;
    }
    return suma / cities.length;
    // return cities.reduce((t,c) => t + c.main.temp, 0)/cities.length;
}
// export { average_temp_ as average_temp };

exports.warmer_average_temp = (cities) => {
    // const t = average_temp(cities);
    // const wc = cities.filter(c => c.main.temp > tm).map(c => c.name);
    // return[wc];
    let a = 0;
    for ( let c of cities){
        a += c.main.temp;
    }
    a /= cities.length;
    return[cities.filter(c => c.main.temp > a).map(c => c.name).sort().join(', ')]; //.sort()
}
// export { warmer_average_temp_ as warmer_average_temp };

exports.max_north = (cities) => {
    const lmax = Math.max (...cities.map( c => c.coord.lat));
    return (cities.find( c => c.coord.lat === lmax)).name ;
    // calcular la latitud mas grande
}
// export { max_north_ as max_north };

exports.max_south = (cities) => {
    const lmin = Math.min (...cities.map( c => c.coord.lat));
    return (cities.find( c => c.coord.lat === lmin)).name ;
}
// export { max_south_ as max_south };

exports.gravity_center = (cities) => {
    let s_lat = 0;
    let s_lon = 0;
    for ( let e of cities){
        s_lon = s_lon + e.coord.lon;
        s_lat += e.coord.lat;
    }
    s_lat /= cities.length;
    s_lon /= cities.length;
    return {lon : s_lon, lat : s_lat};
}
// export { gravity_center_ as gravity_center };

exports.closest_GC = (cities) => {
    let s_lat = 0;
    let s_lon = 0;
    let res = Infinity;
    let ciudad ;
    for ( let e of cities){
        s_lat += e.coord.lat;
        s_lon += e.coord.lon;
    }
    s_lat /= cities.length;
    s_lon /= cities.length;
    for ( let c of cities){
        if ( Math.sqrt((Math.pow ((s_lat-c.coord.lat), 2))+(Math.pow ((s_lon-c.coord.lon), 2))) < res ){
            ciudad = c;
            res = Math.sqrt(Math.pow ((s_lat-c.coord.lat), 2))+(Math.pow ((s_lon-c.coord.lon), 2));
        }
    }
    return (cities.find( c => c === ciudad)).name ;
}

    // let s_lat = 0;
    // let s_long = 0;
    // let ciudad ;
    // let res = Infinity;
    // for ( let c of cities){
    //     d = Math.sqrt((Math.pow ((s_lat-gravity_center.lat), 2))+(Math.pow ((s_long-gravity_center.long), 2)));
    //     if ( d < res ){
    //         ciudad = c;
    //     }
    // }
    // return ciudad;

// export { closest_GC_ as closest_GC };

// ultima funcion 
    // let dist;
    // let s_lat = 0;
    // let s_long = 0;
    // let s_lat_cg = 0;
    // let s_long_cg = 0;
    // let res = Infinity;
    // for ( let c of cities){
    //     s_lat += c.coord.lat;
    //     s_long += c.coord.long;
    // }
    // s_lat_cg = s_lat/c.length;
    // s_long_cg = s_long/c.length;
    // for ( let c of cities){
    //     d = Math.sqrt((Math.pow ((s_lat-s_lat_cg), 2))+(Math.pow ((s_long-s_long_cg), 2)));
    //     if ( d < res ){
    //         return c
    //     }
    // }