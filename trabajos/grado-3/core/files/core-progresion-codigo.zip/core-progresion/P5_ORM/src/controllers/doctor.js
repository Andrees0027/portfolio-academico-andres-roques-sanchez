const {models} = require('../models');

// Crear un doctor
exports.create = async function (name, surname, speciality){
    return await models.Doctor.create({name, surname, speciality});
}

// Asigna un doctor y devuelve los datos del paciente
exports.assignDoctor = async function(patientId, doctorId){
    const p = await models.Patient.findByPk(patientId);
    const d = await models.Doctor.findByPk(doctorId);
    await p.addDoctor(d);
    return p;
}

// Muestra los medicos de un paciente
exports.indexByPatient = async function(patientId){
    const p = await models.Patient.findByPk(patientId);
    return await p.getDoctors();
    // return await (models.Patient.findByPk(patientId)).getDoctors();
}

