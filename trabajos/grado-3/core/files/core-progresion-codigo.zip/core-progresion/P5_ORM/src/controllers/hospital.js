const {models} = require('../models');

exports.create = async function (name, city){
    return await models.Hospital.create({name, city})
}
exports.index = async function(){
    return await models.Hospital.findAll();
}
exports.indexByCity = async function (city) {
    return await models.Hospital.findAll({
        where : {city : city}
    });
}
