const {models} = require('../models');

// Muestra la informacion de un paciente
exports.read = async function (patientId) {
    return await models.Patient.findByPk (patientId);
}

// Crea un paciente en un hospital
exports.create = async function (hospitalId, name, surname, dni){
    return await models.Patient.create({hospitalId, name, surname, dni});
}

exports.update = async function (patientId, name, surname, dni) {
    const p = await models.Patient.findByPk(patientId);
    return await p.update({name, surname, dni});
}

// Borra un paciente
exports.delete = async function (patientId){
    await models.Patient.destroy({
        where: {id : patientId}
    })
}

// Buscar pacientes de un hospital ordenados por el nombre (de la A a la Z)
exports.indexByHospital = async function (hospitalId){
    const p = await models.Hospital.findByPk(hospitalId);
    return await p.getPatients();
}