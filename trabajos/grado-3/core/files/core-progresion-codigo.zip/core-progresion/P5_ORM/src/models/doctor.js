'use strict';

const {Model, DataTypes} = require('sequelize');

// Definition of the Quiz model:
module.exports = sequelize => {

    class Doctor extends Model {}
    
    // Inicialize el modelo Doctor aqui
    Doctor.init({
        name : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},
        surname : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},
        speciality : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},
    },
    {sequelize}
    );
    return Doctor;
}
