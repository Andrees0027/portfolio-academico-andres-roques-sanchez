const Sequelize = require('sequelize');

const url = process.env.DATABASE_URL || "sqlite:p5.sqlite";

const sequelize = new Sequelize (url); 
const Patient = require ('./patient')(sequelize);
const Doctor = require ('./doctor')(sequelize);
const Hospital = require ('./hospital')(sequelize);

Hospital.hasMany(Patient, {as : "patients", foreignKey : "hospitalId"});
Patient.belongsTo(Hospital, {as : "hospital", foreignKey : "patientId"});

Doctor.belongsToMany(Patient, {as : "patients", through : "DocPat", foreignKey : "doctorId", otherKey : "patientId"});
Patient.belongsToMany(Doctor, {as : "doctors", through : "DocPat", foreignKey : "patientId", otherKey : "doctorId"});

module.exports = exports = sequelize;
