'use strict';

const {Model, DataTypes, STRING} = require('sequelize');

// Definition of the Quiz model:
module.exports = sequelize => {

    class Patient extends Model {}

    // Inicializa nsq
    Patient.init({
        name : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},
        surname : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},
        dni : {type: DataTypes.STRING, validate: {notEmpty : {msg : "mal"}}},

    },
    {sequelize}
    );
    return Patient;
}