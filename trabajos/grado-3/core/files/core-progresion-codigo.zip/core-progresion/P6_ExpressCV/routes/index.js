// const { render } = require('ejs');
// var express = require('express');
// var router = express.Router();

// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', {title: 'Blog', h1:'Welcome to My Blog'});
// });

// /* GET author page. */
// router.get('/author', function(req, res, next) {
//   res.render('author', { title: 'CV' });
// });


// module.exports = router;

const { render } = require('ejs');
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {title: 'Blog', h1:'Welcome to My Blog'});
});


router.get('/author', function(req, res, next){
  res.render('author', {title: 'Blog'});
});
module.exports = router;
