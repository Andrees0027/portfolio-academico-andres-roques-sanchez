var express = require('express');
var router = express.Router();

const multer = require('multer');
const storage = multer.memoryStorage()
const upload = multer({
  storage: storage,
  limits: {fileSize: 20 * 1024 * 1024}});

const postController = require('../controllers/post');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {title: 'Blog', h1:'Welcome to My Blog'});
});

// Posts page
router.get('/', function(req, res, next) {
  res.redirect('/posts',);
});

// Author page
router.get('/author', function(req, res, next){
  res.render('author', {title: 'Blog'});
});

// Autoload for routes using :quizId
router.param('postId', postController.load);

//Routes fir the resource /posts
router.get('/posts', postController.index);
router.get('/posts/:postId(\\d+)', postController.show);
router.get('/posts/new', postController.new); //1
router.post('/posts', upload.single('image'), postController.create); //2
router.get('/posts/:postId(\\d+)/edit', postController.edit);
router.put('/posts/:postId(\\d+)', upload.single('image'), postController.update);
router.delete('/posts/:postId(\\d+)', postController.destroy);
router.get('/posts/:postId(\\d+)/attachment', postController.attachment);

module.exports = router;
