var express = require('express');
var router = express.Router();

const multer = require('multer');
const storage = multer.memoryStorage()
const upload = multer({
  storage: storage,
  limits: {fileSize: 20 * 1024 * 1024}});

const postController = require('../controllers/post');
const userController = require('../controllers/user');
const sessionController = require('../controllers/session');


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {title: 'Blog', h1:'Welcome to My Blog'});
});

// Posts page
router.get('/', function(req, res, next) {
  res.redirect('posts');
});

// Author page
router.get('/author', function(req, res, next){
  res.render('author', {title: 'Blog'});
});

// Users page 
router.get('/', function(req, res, next) {
  res.redirect('/users');
});

// Autoload for routes using :quizId
router.param('postId', postController.load);
router.param('userId', userController.load);

// autologout
router.all('*',sessionController.deleteExpiredUserSession);

//Routes for the resource /posts
router.get('/posts', postController.index);
router.get('/posts/:postId(\\d+)', postController.show);
router.get('/posts/new', postController.new); //1
router.post('/posts', upload.single('image'), postController.create); //2
router.get('/posts/:postId(\\d+)/edit', postController.edit);
router.put('/posts/:postId(\\d+)', upload.single('image'), postController.update);
router.delete('/posts/:postId(\\d+)', postController.destroy);
router.get('/posts/:postId(\\d+)/attachment', postController.attachment);

// Routes for the resource /users
router.get('/users',  userController.index);
router.get('/users/:userId(\\d+)',  userController.show);
router.get('/users/new', userController.new);
router.post('/users', userController.create);
router.get('/users/:userId(\\d+)/edit', userController.edit);
router.put('/users/:userId(\\d+)', userController.update);
router.delete('/users/:userId(\\d+)', userController.destroy);

// Routes for the resource /session
router.get('/login',    sessionController.new);     // login form
router.post('/login',   sessionController.create);  // create sesion
router.delete('/login', sessionController.destroy); // close sesion


module.exports = router;
