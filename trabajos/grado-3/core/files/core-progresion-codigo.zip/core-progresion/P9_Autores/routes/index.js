var express = require('express');
var router = express.Router();

const multer = require('multer');
const storage = multer.memoryStorage()
const upload = multer({
  storage: storage,
  limits: {fileSize: 20 * 1024 * 1024}
});
const postController = require('../controllers/post');
const userController = require('../controllers/user');
const sessionController = require('../controllers/session');

// autologout
router.all('*',sessionController.deleteExpiredUserSession);

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {title: 'Blog', h1:'Welcome to My Blog'});
});

// Posts page
router.get('/', function(req, res, next) {
  res.redirect('posts');
});

// Author page
router.get('/author', function(req, res, next){
  res.render('author', {title: 'Blog'});
});

// Users page 
router.get('/', function(req, res, next) {
  res.redirect('/users');
});

// Autoload for routes using :postId
router.param('postId', postController.load);
router.param('userId', userController.load);


//Routes for the resource /posts
router.get('/posts', postController.index);
router.get('/posts/:postId(\\d+)', postController.show);
router.get('/posts/new', postController.new); //1
router.post('/posts', upload.single('image'), postController.create); //2
router.get('/posts/:postId(\\d+)/edit', postController.adminOrAuthorRequired, postController.edit);
router.put('/posts/:postId(\\d+)', upload.single('image'), postController.adminOrAuthorRequired, postController.update);
router.delete('/posts/:postId(\\d+)', postController.adminOrAuthorRequired, postController.destroy);
router.get('/posts/:postId(\\d+)/attachment', postController.attachment);

// Routes for the resource /users
router.get('/users', userController.index);
router.get('/users/:userId(\\d+)', sessionController.adminOrMyselfRequired, userController.show);
router.get('/users/new',  userController.new);
router.post('/users', userController.create);
router.get('/users/:userId(\\d+)/edit', sessionController.loginRequired, sessionController.adminOrMyselfRequired, userController.edit);
router.put('/users/:userId(\\d+)', sessionController.adminOrMyselfRequired, userController.update);
router.delete('/users/:userId(\\d+)', sessionController.adminOrMyselfRequired, userController.destroy);

// Routes for the resource /session
router.get('/login',    sessionController.new);     // login form
router.post('/login',   sessionController.create);  // create sesion
router.delete('/login', sessionController.destroy); // close sesion


module.exports = router;
