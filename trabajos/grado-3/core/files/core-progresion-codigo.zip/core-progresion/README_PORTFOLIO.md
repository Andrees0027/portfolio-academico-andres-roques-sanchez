# CORE — progresión de prácticas (3º de Grado)

Selección curada de las prácticas entregadas en la asignatura CORE.

## Qué se incluye
- P1: peticiones HTTP manuales a la calculadora.
- P3: calculadora HTML/JavaScript.
- P4: procesamiento de datos meteorológicos con Node.js.
- P5: ORM con Sequelize/SQLite y relaciones Doctor-Hospital-Patient.
- P6: estructura Express/MVC sin la página de autor ni fotografía personal.
- P7: blog REST con posts y adjuntos.
- P8: usuarios, autenticación y sesiones.
- P9: relación de autores con posts.
- P10: roles y autorización.

## Qué se omite
- P2 (CV HTML/CSS): se describe en el portfolio, pero no se redistribuye porque contiene
  fecha de nacimiento, dirección, teléfono, correo académico y otros datos personales.
- `node_modules`, repositorios `.git`, bases de datos SQLite locales, `user.json`,
  autocorrectores, capturas de datos personales y `package-lock.json`.
- Los README/enunciados docentes de las prácticas no se incluyen como trabajo propio.
- En P6–P10 se elimina la vista/fotografía de autor por privacidad.

El fichero `cities.json` de P4 se conserva dentro de `input-docente/` únicamente como dato
de entrada necesario para reproducir el ejercicio; no es contenido creado por el alumno.

En las prácticas Express, el esqueleto inicial fue generado con Express Generator y material
base de la asignatura. La selección conserva el desarrollo realizado sobre esa base.
