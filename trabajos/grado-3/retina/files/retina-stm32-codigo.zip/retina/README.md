# Retina
|                        |                                        |
| ---------------------- | -------------------------------------- |
| **Autor**              | Andrés Roques Sánchez                  |
| **Versión del código** | V4 + Mejoras                           |
| **Fecha**              | 26/05/2023                             |


## Resumen
Es un proyecto que implementa una codificacion en una placa STM32 que permite usar la placa como transmisor o receptor de código de colores led, iluminando un led con varios colores.


## Introducción
El proyecto, portado para la placa Nucleo STM32F446RE (ver imagen), carga el proyecto en la misma que se usa como transmisor o receptor, incorporando los componentes necesarios.

El proyecto, portado para un led (puede estar en una protoboard(ver imagen)).

Este código implementa varias máquina de estados (FSM), para el botón, el transmisor y el receptor.

![Imagen de la placa Nucleo STM32F446RE](./assets/nucleo.jpg)
![Imagen de la protoboard con el laser incorporado](./assets/protoboard.jpg)


### BUTTON
Para configurar la entrada hardware del boton necesitamos implementar una maquina de estados, fsm_button, con la que trabajaremos en varios archivos como fsm_button.h, fsm_button.c, port_button.h y port_button.c y emplearemos ciertas funciones ya comentadas en ambos archivos.

### TRANSMISOR
En el caso de que queramos usar la placa como receptora de codigo de color led, tendremos que una maquina de estados fsm_tx, y varias funciones, con las que trabajaremos en los archivos fsm_tx.h, fsm_tx.c, port_tx.h y port_tx.c

### RECEPTOR
En el caso de que queramos usar la placa como receptora de codigo de color led, tendremos que una maquina de estados fsm_rx, y varias funciones, con las que trabajaremos en los archivos fsm_rx.h, fsm_rx_nec.h, fsm_rx.c, fsm_rx_nec.h, port_rx.h y port_rx.c

### RETINA
Son los archivos principales del programa, en los que programaremos las funciones necesarias para el funcionamiento de la placa. Estos son : retina.h, retina.c, fsm_retina.h y fsm_retina.c

### CONFIGURACION DEL SISTEMA
En archivos como port_system.c y port_system.h, se definirán y prohramarán los puertos y las gpios utilizadas para el correcto funcionamiento, en las respectivas funciones, comentadas en esos archivos.

### FUNCIONAMIENTO RGB
Para el funcionamiento RGB del sistema, debemos definir los codigos de colores empleados por los transmisores que optemos (usando una APP de movil llamada irplus para su transmision (mirar fotografía)), así como los puertos que usaremos para transmitir cada color RGB. Esto se definirá en port_rgb_h, en port_rgb.c y en commands.h
![Imagen de la app usada para la transmision](./assets/irplus.jpg)

### FUNCIONES AUXILIARES
Usaremos archivos auxiliares dados ya programados correctemante por el departamento de la asignatura, como por  syscall.c, que se emplearán para el correcto funcionamiento del sistema.


## Documentación de las mejoras

### MEJORA
En mi caso he optado por mejorar la capacidad de recibir códigos de colores de diferentes marcas de transmisores, para facilitar el empleo del mismo codigo usando diferentes mandos o codigos de distintos distribuidores y que sea lo más homogéneo posible. 
En este caso he decidido configurar el receptor para que funcione empleando dos códigos de dos diferentes marcas: Liluco y Paulmann, y siguiendo este modelo podrían usarse para todos los distintos códigos de distribuidores.
Los cambios realizados en fsm_retina.c para facilitar la mejora son:
1. Añadir un array por cada codigo de colores en la estructura definida del FSM DE RETINA:
uint32_t tx_codes_arr_paulmann [COMMANDS_MEMORY_SIZE]; //MEJORA
uint32_t tx_codes_arr_liluco [COMMANDS_MEMORY_SIZE];
2.  En la funcion _process_rgb_code, explicado lo que hace en los comentarios de la propia funcion del archivo fsm_retina.c, *para cada color*, añadimos la posibilidad de que el codigo recibido tome los valores de tantos codigos de color como tengamos implementados, en este caso DOS.
    if ((code == RED_BUTTON_LILUCO) || (code == RED_BUTTON_PAULMANN)) // ROJO
    {
        port_rgb_set_color(rgb_id, HIGH, LOW, LOW);
    }
3. En la función do_send_next_msg, tenemos en cuenta tantos arrays de codigos como codigos hayamos implementado para pasarselo como parámetro a la función set_code.
fsm_tx_set_code(p_fsm->p_fsm_tx, p_fsm->tx_codes_arr_liluco[p_fsm->tx_codes_index]);
fsm_tx_set_code(p_fsm->p_fsm_tx, p_fsm->tx_codes_arr_paulmann[p_fsm->tx_codes_index]);

4. En la función fsm_retina_init debemos inicializar tantos arrays como codigos tengamos con sus respectivos valores por cada color

    p_fsm -> tx_codes_arr_liluco[0] = RED_BUTTON_LILUCO;
    p_fsm -> tx_codes_arr_liluco[1] = GREEN_BUTTON_LILUCO;
    p_fsm -> tx_codes_arr_liluco[2] = BLUE_BUTTON_LILUCO;
...
    p_fsm -> tx_codes_arr_paulmann[0] = RED_BUTTON_PAULMANN;
    p_fsm -> tx_codes_arr_paulmann[1] = GREEN_BUTTON_PAULMANN;
    p_fsm -> tx_codes_arr_paulmann[2] = BLUE_BUTTON_PAULMANN;
...

5. Video explicativo de la mejora:

    [![Demostrador de la mejora](./assets/youtube.jpg)](https://youtu.be/G0SNajY7x5gI "Si pinchas en la imagen te lleva a un vídeo.")

6. Imagenes de los cambios producidos en la mejora
![Cambios de la mejora](./assets/cambio_mejora_0.jpg)
![Cambios de la mejora](./assets/cambio_mejora_1.jpg)
![Cambios de la mejora](./assets/cambio_mejora_2.jpg)
![Cambios de la mejora](./assets/cambio_mejora_3.jpg)
![Cambios de la mejora](./assets/cambio_mejora_4.jpg)

