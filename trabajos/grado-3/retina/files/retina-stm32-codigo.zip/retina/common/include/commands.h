/**
 * @file commands.h
 * @brief Commands definition for the different remotes used in the system using the NEC protocol
 * @author Andrés Roques Sánchez
 * @date fecha
 */

#ifndef COMMANDS_H_
#define COMMANDS_H_

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
/* Device: Liluco IR remote */
/* The Liluco IR remote and receiver work on NEC protocol */


#define GREEN_BUTTON_LILUCO 0x00F7A05F /*!< Liluco IR remote command for button GREEN */
#define RED_BUTTON_LILUCO 0x00F720DF   /*!< Liluco IR remote command for button RED */
#define BLUE_BUTTON_LILUCO 0x00F7609F  /*!< Liluco IR remote command for button BLUE */
#define CYAN_BUTTON_LILUCO 0x00F7A857  /*!< Liluco IR remote command for button CYAN*/
#define MAGENTA_BUTTON_LILUCO 0x00F76897   /*!< Liluco IR remote command for button MAGENTA */
#define YELLOW_BUTTON_LILUCO 0x00F728D7    /*!< Liluco IR remote command for button YELLOW */
#define WHITE_BUTTON_LILUCO 0xF7E01F   /*!< Liluco IR remote command for button WHITE */
#define BLACK_BUTTON_LILUCO 0x00F740BF   /*!< Liluco IR remote command for button BLACK */   

//MEJORA

#define RED_BUTTON_PAULMANN 0x00FF1AE5   /*!< Liluco IR remote command for button RED */
#define GREEN_BUTTON_PAULMANN 0x00FF9A65 /*!< Liluco IR remote command for button GREEN */
#define BLUE_BUTTON_PAULMANN 0x00FFA25D  /*!< Liluco IR remote command for button BLUE */
#define CYAN_BUTTON_PAULMANN 0x00FF8A75  /*!< Liluco IR remote command for button CYAN*/
#define MAGENTA_BUTTON_PAULMANN 0x00FF58A7   /*!< Liluco IR remote command for button MAGENTA */
#define YELLOW_BUTTON_PAULMANN 0x00FF18E7    /*!< Liluco IR remote command for button YELLOW */
#define WHITE_BUTTON_PAULMANN 0x00FF22DD   /*!< Liluco IR remote command for button WHITE */
#define BLACK_BUTTON_PAULMANN 0x00FF827D   /*!< Liluco IR remote command for button BLACK */   


#define LIL_NUMBER_OF_BUTTONS 9

/* Other devices */
#endif /* COMMANDS_H_ */
