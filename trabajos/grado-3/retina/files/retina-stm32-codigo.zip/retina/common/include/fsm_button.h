/**
 * @file fsm_button.h
 * @brief Header for fsm_button.c file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

#ifndef FSM_BUTTON_H_
#define FSM_BUTTON_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

/* Other includes */
#include "fsm.h"

/* Function prototypes and explanation -------------------------------------------------*/

/**
 * @brief Check if the button FSM is active, or not. The button is inactive when it is in the status BUTTON_RELEASED.
 * @param p_this
 * @return bool indicating if it is or not
*/
bool fsm_button_check_activity (fsm_t *p_this); 

/**
 * @brief Creates a new button FSM
 * @param debounce_time 
 * @param button_id 
 * @return fsm_t* 
 */
fsm_t * fsm_button_new (uint32_t debounce_time, uint32_t button_id); //MEJORA

/**
 * @brief Initializes a button FSM
 * @param p_this 
 * @param debounce_time 
 * @param button_id 
 */
void fsm_button_init (fsm_t *p_this, uint32_t debounce_time, uint32_t button_id); //MEJORA

/**
 * @brief Returns the duration of the last button press
 * @param p_this 
 * @return uint32_t 
 */
uint32_t fsm_button_get_duration (fsm_t *p_this); 

/**
 * @brief Resets the duration of the last button press 
 * @param p_this 
 */
void fsm_button_reset_duration (fsm_t *p_this);

#endif
