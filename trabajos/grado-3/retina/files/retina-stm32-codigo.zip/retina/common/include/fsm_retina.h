/**
 * @file fsm_retina.h
 * @brief Header for fsm_retina.c file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */
#ifndef FSM_RETINA_H_
#define FSM_RETINA_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

/* Other includes */
#include "fsm.h"

/* Function prototypes and explanation ---------------------------------------*/
/**
 * @brief Create a new RETINA FSM.
 * @param p_fsm_button  
 * @param button_press_time 
 * @param p_fsm_tx 
 * @return fsm_t* 
 */
fsm_t *fsm_retina_new(fsm_t *p_fsm_button, uint32_t button_press_time_ms, fsm_t *p_fsm_tx, fsm_t *p_fsm_rx, uint8_t rgb_id);

/**
 * @brief Initialize the infrared transmitter FSM.
 * This function initializes the default values of the FSM struct.
 * @param p_this 
 * @param p_fsm_button 
 * @param button_press_time 
 * @param p_fsm_tx 
 */
void fsm_retina_init (fsm_t *p_this, fsm_t *p_fsm_button, uint32_t button_press_time_ms, fsm_t *p_fsm_tx, fsm_t *p_fsm_rx, uint8_t rgb_id);

#endif
