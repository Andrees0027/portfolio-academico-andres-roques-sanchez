/**
 * @file fsm.c
 * @brief Library to create Finite State Machines using composition.
 * This library is expected to be used using composition
 * @author Teachers from the Departamento de Ingeniería Electrónica. Original authors: José M. Moya and Pedro J. Malagón. Latest contributor: Román Cárdenas.
 * @date 2023-01-01
 */

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdlib.h>

/* Other includes */
#include "fsm.h"

/**
 * @brief Allocates memory and create a new state machine from a transition table.
 *
 * The starting state of the state machine will correspond to the origin state of the first transition found in the transition table.  The transition table must end with a null transition {-1, NULL, -1, NULL}. In this way, the state machine will be able to detect that it has reached the end of the transition table.
 *
 * @param p_tt Pointer to the  state machine transition table
 * @return fsm_t* Pointer to the memory address where the new state machine is located
 */
fsm_t *fsm_new(fsm_trans_t *p_tt)
{
  if (p_tt == NULL)
  {
    return NULL;
  }
  if ((p_tt->orig_state == -1) || (p_tt->in == NULL) || (p_tt->dest_state == -1))
  {
    return NULL;
  }
  fsm_t *p_fsm = (fsm_t *) malloc(sizeof(fsm_t));
  if (p_fsm != NULL)
  {
    fsm_init(p_fsm, p_tt);
  }
  return p_fsm;
}

/**
 * @brief Create a new state machine from a table of transitions.
 *
 * The starting state of the state machine will correspond to the origin state of the first transition found in the transition table. The transition table must end with a null transition {-1, NULL, -1, NULL}. This will allow the state machine to detect that it has reached the end of the table. Unlike `fsm_new`, this function does not allocate memory for the state machine. Instead, it uses the memory address provided by the user.
 *
 * @param p_fsm Pointer to the memory address where the new state machine is located
 * @param p_tt Pointer to the  state machine transition table
 */
void fsm_init(fsm_t *p_fsm, fsm_trans_t *p_tt)
{
  if (p_tt != NULL)
  {
    p_fsm->p_tt = p_tt;
    p_fsm->current_state = p_tt->orig_state;
  }
}

/**
 * @brief
 *
 * It frees the memory previously allocated for the state machine. Once this function is called, the state machine becomes unusable. It is only necessary to call this function if the state machine was previously created by calling the `fsm_new` function.
 *
 * @param p_fsm Pointer to the memory address where the new state machine is located
 */
void fsm_destroy(fsm_t *p_fsm)
{
  free(p_fsm);
}

/**
 * @brief Check the full transition table.
 *
 * It loops through the transition table and, if an input condition is met, it switches to a new state and executes the corresponding output modification function.
 *
 * @param p_fsm Pointer to the memory address where the new state machine is located
 */
void fsm_fire(fsm_t *p_fsm)
{
  fsm_trans_t *p_t;
  for (p_t = p_fsm->p_tt; p_t->orig_state >= 0; ++p_t)
  {
    if ((p_fsm->current_state == p_t->orig_state) && p_t->in(p_fsm))
    {
      p_fsm->current_state = p_t->dest_state;
      if (p_t->out)
        p_t->out(p_fsm);
      break;
    }
  }
}