/**
 * @file fsm_button.c
 * @brief Button FSM main file.
 * @author Andrés Roques Sánchez
 * @date 24/03/2003
 */

/* Includes -----------------------------------------------------------------*/
#include "fsm_button.h"
#include "port_button.h"   
#include <stddef.h>
#include <stdlib.h>

/* Typedefs --------------------------------------------------------------------*/

typedef struct{
    fsm_t f;
    uint32_t debounce_time; /*!<Button debounce time in ms*/
    uint32_t button_id; /*!<Button name.*/
    uint32_t duration; /*!<Time the button has been pressed*/
    uint32_t next_timeout; /*!<Timeout for anti-debounce in ms*/
    uint32_t tick_pressed; /*!<Ticks counted when the button is pressed*/
} fsm_button_t ;


/* Defines and enums ----------------------------------------------------------*/
/* Enums */

enum  FSM_BUTTON {
  BUTTON_RELEASED = 0,
  BUTTON_RELEASED_WAIT,
  BUTTON_PRESSED,
  BUTTON_PRESSED_WAIT
};

/* State machine input or transition functions */


/* State machine output or action functions */


/* Other auxiliary functions */



/**
 * @brief This function checks if the button is currently pressed and returns a boolean value.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_button_pressed(fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    return port_button_is_pressed(p_fsm -> button_id);
}	

/**
 * @brief This function checks if the button is currently released and returns a boolean value.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_button_released(fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    return !(port_button_is_pressed(p_fsm -> button_id));
}

/**
 * @brief This function checks if the debounce time has elapsed since the last button press and returns a boolean value.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_timeout(fsm_t *p_this	){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    if(port_button_get_tick() > p_fsm -> next_timeout){
        return true;
    } else{
        return false;
    }
}

/* State machine output or action functions */
/**
 * @brief This function stores the current tick value when the button is first pressed.
 * @param p_this 
 */
static void do_store_tick_pressed(fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    p_fsm -> tick_pressed = port_button_get_tick();
    p_fsm -> next_timeout = p_fsm -> tick_pressed + p_fsm -> debounce_time; //MEJORA

}	

/**
 * @brief This function calculates the duration of the button press and sets the next timeout for debounce. 
 * @param p_this 
 */
static void do_set_duration	(fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    p_fsm -> duration = port_button_get_tick() - p_fsm -> tick_pressed;
    p_fsm -> next_timeout = port_button_get_tick() + (p_fsm -> debounce_time);
}	

/**
 * @brief This array defines the transitions between the FSM states and the associated input and output functions.
 */
static fsm_trans_t fsm_trans_button[] ={
{BUTTON_RELEASED, check_button_pressed, BUTTON_PRESSED_WAIT, do_store_tick_pressed}, 
{BUTTON_PRESSED_WAIT, check_timeout, BUTTON_PRESSED, NULL},
{BUTTON_PRESSED, check_button_released, BUTTON_RELEASED_WAIT, do_set_duration},
{BUTTON_RELEASED_WAIT, check_timeout, BUTTON_RELEASED, NULL},
{-1, NULL, -1, NULL}
};

/**
 * @brief This function returns the duration of the last button press.
 * @param p_this 
 * @return uint32_t 
 */
uint32_t fsm_button_get_duration(fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    return p_fsm -> duration;
}

/**
 * @brief This function resets the duration of the last button press to zero.
 * @param p_this 
 */
void fsm_button_reset_duration (fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    p_fsm -> duration = 0;
}

/**
 * @brief This function creates a new button FSM and returns a pointer to it.
 * @param debounce_time 
 * @param button_id 
 * @return fsm_t* 
 */
fsm_t *fsm_button_new(uint32_t debounce_time, uint32_t button_id){
    fsm_t *p_fsm = malloc(sizeof(fsm_button_t)); /* Do malloc to reserve memory of all other FSM elements, although it is interpreted as fsm_t (the first element of the structure) */
    fsm_button_init(p_fsm, debounce_time, button_id);
    return p_fsm;
}

/**
 * @brief This function initializes the button FSM with the specified debounce time and button ID.
 * @param p_this 
 * @param debounce_time 
 * @param button_id 
 */
void fsm_button_init(fsm_t *p_this, uint32_t debounce_time, uint32_t button_id){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    fsm_init(p_this, fsm_trans_button);
    p_fsm -> debounce_time = debounce_time;
    p_fsm -> button_id = button_id;
    p_fsm -> tick_pressed = 0;
    p_fsm -> duration = 0;
    port_button_init(button_id);
}


/**
 * @brief Check if the button FSM is active, or not. The button is inactive when it is in the status BUTTON_RELEASED.
 * @param p_this
 * @return bool indicating if it is or not
*/
bool fsm_button_check_activity (fsm_t *p_this){
    fsm_button_t *p_fsm = (fsm_button_t *)(p_this);
    if ((p_fsm->f.current_state)==BUTTON_RELEASED){
        return false;
    }else{
        return true;
    }
}
