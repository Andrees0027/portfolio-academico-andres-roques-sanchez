/**
 * @file fsm_retina.c
 * @brief Retina FSM main file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

/* Includes ------------------------------------------------------------------*/
#include "commands.h"
#include "fsm_retina.h"
#include "fsm_button.h"
#include "fsm_tx.h"
#include "fsm_rx.h"
#include "port_rgb.h"
#include "port_system.h"

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define COMMANDS_MEMORY_SIZE 8 /*!< Number of NEC commands stored in the memory of the system Retina */

/* Enums */
/**
 * @brief 
 * 
 */
enum FSM_RETINA {
  WAIT_TX = 0,
  WAIT_RX,
  SLEEP_TX,
  SLEEP_RX
};

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Structure to define the Retina FSM.
 */
typedef struct
{
    fsm_t f; /*!< Retina FSM  */
    fsm_t *p_fsm_button;
    uint32_t long_button_press_ms;
    fsm_t *p_fsm_tx;
    uint32_t tx_codes_arr_liluco [COMMANDS_MEMORY_SIZE];
    uint32_t tx_codes_arr_paulmann [COMMANDS_MEMORY_SIZE]; //MEJORA
    uint8_t tx_codes_index;
    fsm_t * p_fsm_rx;
    uint32_t rx_code; 
    uint8_t rgb_id;
} fsm_retina_t;


/**
 * @brief Identifies the command  received of any of the olor cpatterns and light the corresponding color.
 * @param rgb_id RGB LED ID. Must be unique.
 * @param code	Code parsed that identifies a color.

*/
void _process_rgb_code(uint8_t rgb_id, uint32_t code){
    if ((code == RED_BUTTON_LILUCO) || (code == RED_BUTTON_PAULMANN)) // ROJO
    {
        port_rgb_set_color(rgb_id, HIGH, LOW, LOW);
    }
    else if ((code == GREEN_BUTTON_LILUCO) || (code == GREEN_BUTTON_PAULMANN)) // VERDE
    {
        port_rgb_set_color(rgb_id, LOW, HIGH, LOW);
    }
    else if ((code == BLUE_BUTTON_LILUCO) || (code == BLUE_BUTTON_PAULMANN)) // AZUL
    {
        port_rgb_set_color(rgb_id, LOW, LOW, HIGH);
    }
    else if ((code == CYAN_BUTTON_LILUCO) || (code == CYAN_BUTTON_PAULMANN)) // CYAN
    {
        port_rgb_set_color(rgb_id, LOW, HIGH, HIGH);
    }
    else if ((code == MAGENTA_BUTTON_LILUCO) || (code == MAGENTA_BUTTON_PAULMANN)) // MAGENTA
    {
        port_rgb_set_color(rgb_id, HIGH, LOW, HIGH);
    }
    else if ((code == YELLOW_BUTTON_LILUCO) || (code == YELLOW_BUTTON_PAULMANN)) // AMARILLO
    {
        port_rgb_set_color(rgb_id, HIGH, HIGH, LOW);
    }
    else if ((code == WHITE_BUTTON_LILUCO) || (code == WHITE_BUTTON_PAULMANN)) // BLANCO
    {
        port_rgb_set_color(rgb_id, HIGH, HIGH, HIGH);
    }
    else if ((code == BLACK_BUTTON_LILUCO ) || (code == BLACK_BUTTON_PAULMANN)) // NEGRO
    {
        port_rgb_set_color(rgb_id, LOW, LOW, LOW);
    }
} 

// void _process_rgb_code(uint8_t rgb_id, uint32_t code){
//     if ((code == RED_BUTTON_LILUCO)) // ROJO
//     {
//         port_rgb_set_color(rgb_id, HIGH, LOW, LOW);
//     }
//     else if ((code == GREEN_BUTTON_LILUCO)) // VERDE
//     {
//         port_rgb_set_color(rgb_id, LOW, HIGH, LOW);
//     }
//     else if ((code == BLUE_BUTTON_LILUCO)) // AZUL
//     {
//         port_rgb_set_color(rgb_id, LOW, LOW, HIGH);
//     }
//     else if ((code == CYAN_BUTTON_LILUCO)) // CYAN
//     {
//         port_rgb_set_color(rgb_id, LOW, HIGH, HIGH);
//     }
//     else if ((code == MAGENTA_BUTTON_LILUCO)) // MAGENTA
//     {
//         port_rgb_set_color(rgb_id, HIGH, LOW, HIGH);
//     }
//     else if ((code == YELLOW_BUTTON_LILUCO)) // AMARILLO
//     {
//         port_rgb_set_color(rgb_id, HIGH, HIGH, LOW);
//     }
//     else if ((code == WHITE_BUTTON_LILUCO)) // BLANCO
//     {
//         port_rgb_set_color(rgb_id, HIGH, HIGH, HIGH);
//     }
//     else if ((code == BLACK_BUTTON_LILUCO )) // NEGRO
//     {
//         port_rgb_set_color(rgb_id, LOW, LOW, LOW);
//     }else{
//         return;
//     }
// }


/**
 * @brief Checks if any process is beeing run on the button, the receiver or the transmitter.
 * @param p_this 
 * @return true if it is
 * @return false if it is not
 */
static bool check_activity	(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    bool a = fsm_button_check_activity(p_fsm->p_fsm_button);
    bool b = fsm_tx_check_activity(p_fsm->p_fsm_tx);
    bool c = fsm_rx_check_activity(p_fsm->p_fsm_rx);
    if (a || b || c){
        return true;
    }else{
        return false;
    }
}	

/**
 * @brief Checks if any process is not beeing run on the button, the receiver or the transmitter. It calls the function check_activity and returns its inverse.
 * @param p_this 
 * @return true if it is not
 * @return false if it is
 */
static bool check_no_activity	(fsm_t *p_this){
    return !check_activity(p_this);
}

/* State machine input or transition functions */

/**
 * @brief Checks if the button has been pressed briefly.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_short_pressed (fsm_t *p_this)
{
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    if( fsm_button_get_duration(p_fsm->p_fsm_button) != 0 && fsm_button_get_duration(p_fsm->p_fsm_button) < p_fsm->long_button_press_ms)
        return true;
    else
        return false;
}

/**
 * @brief Checks if the button has been pressed for a long time.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_long_pressed (fsm_t *p_this)
{
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    if( fsm_button_get_duration(p_fsm->p_fsm_button) != 0 && fsm_button_get_duration(p_fsm->p_fsm_button) >= p_fsm->long_button_press_ms)
        return true;
    else
        return false;
}

/**
 * @brief Checks if the button has been pressed for a long time.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_code	(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    int code = fsm_rx_get_code(p_fsm -> p_fsm_rx);
    if (code != 0x00){
        p_fsm -> rx_code = code;
        return true;
    }
    return false;
}	


/**
 * @brief Checks if the button has been pressed for a long time.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_repetition (fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    return fsm_rx_get_repetition(p_fsm->p_fsm_rx);
}	


/**
 * @brief Checks if the button has been pressed for a long time.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_error (fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    return fsm_rx_get_error_code(p_fsm->p_fsm_rx);
}	


/**
 * @brief Sends the next message.
 * @param p_this 
 */
static void do_send_next_msg (fsm_t *p_this)
{
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    fsm_tx_set_code(p_fsm->p_fsm_tx, p_fsm->tx_codes_arr_liluco[p_fsm->tx_codes_index]);
    fsm_tx_set_code(p_fsm->p_fsm_tx, p_fsm->tx_codes_arr_paulmann[p_fsm->tx_codes_index]);
    fsm_button_reset_duration(p_fsm->p_fsm_button);
    if(p_fsm->tx_codes_index < COMMANDS_MEMORY_SIZE-1){
        p_fsm->tx_codes_index++;
    }
    else if(p_fsm->tx_codes_index == COMMANDS_MEMORY_SIZE){
        p_fsm->tx_codes_index = 0;
    }
}

/**
 * @brief Sleeps the sistem
 * @param p_this
 */
static void do_sleep (fsm_t *p_this){
    port_system_sleep();
}	

/**
 * @brief Execute the wright code by calling functions _process_rgb_code and fsm_rx_reset_code
 * @param p_this
 */
static void do_execute_code	(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);    
    _process_rgb_code(p_fsm -> rgb_id, p_fsm->rx_code);
    fsm_rx_reset_code(p_fsm->p_fsm_rx);
    // Reset the code of the RX FSM calling the right function
}	

/**
 * @brief Cambia de modo, apagando el transmisor y encendiendo el receptor
 * @param p_this
 */
static void do_tx_off_rx_on	(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this); 
    fsm_rx_set_rx_status(p_fsm -> p_fsm_rx, true);
    _process_rgb_code(p_fsm ->rgb_id, p_fsm ->rx_code);
    fsm_button_reset_duration(p_fsm -> p_fsm_button);
}	

/**
 * @brief Cambia de modo, apagando el receptor y encendiendo el transmisor
 * @param p_this
 */
static void do_rx_off_tx_on	(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this); 
    fsm_rx_set_rx_status(p_fsm -> p_fsm_rx, false);
    port_rgb_set_color(p_fsm -> rgb_id, 0x00, 0x00, 0x00);
    fsm_button_reset_duration(p_fsm -> p_fsm_button);
}	

/**
 * @brief Codigo a ejecutar cuando se recibe una repeticion 
 * @param p_this
 */
static void do_execute_repetition(fsm_t *p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this); 
    // To be defined. There is nothing defined in the basic project of RETINA.
    // You can do whatever you want as an IMPROVEMENT of your project to act when receiving a repetition.
    fsm_rx_reset_code(p_fsm -> p_fsm_rx);
}	

/**
 * @brief Descarta el mensaje recibido debido a que es un error
 * @param p_this
 */
static void do_discard_rx_and_reset	(fsm_t * p_this){
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this); 
    fsm_rx_reset_code(p_fsm -> p_fsm_rx);
}

/**
 * @brief array with state-machine
 */
static fsm_trans_t fsm_trans_retina[]=
{
    {WAIT_TX, check_short_pressed, WAIT_TX, do_send_next_msg},
    {WAIT_TX, check_long_pressed, WAIT_RX, do_tx_off_rx_on},
    {WAIT_TX, check_no_activity, SLEEP_TX, do_sleep},

    {WAIT_RX, check_code, WAIT_RX, do_execute_code},
    {WAIT_RX, check_repetition, WAIT_RX, do_execute_repetition},
    {WAIT_RX, check_error, WAIT_RX, do_discard_rx_and_reset},
    {WAIT_RX, check_long_pressed, WAIT_TX, do_rx_off_tx_on},
    {WAIT_RX, check_no_activity, SLEEP_RX, do_sleep},

    {SLEEP_TX, check_activity, WAIT_TX, NULL},
    {SLEEP_TX, check_no_activity, WAIT_TX, do_sleep},

    {SLEEP_RX, check_activity, WAIT_RX, NULL},
    {SLEEP_RX, check_activity, WAIT_RX, do_sleep},

    {-1, NULL, -1, NULL}

};

/* Other auxiliary functions */

/**
 * @brief Create a new RETINA FSM
 * @param p_fsm_button 
 * @param button_press_time 
 * @param p_fsm_tx 
 * @return fsm_t* 
 */
fsm_t *fsm_retina_new (fsm_t *p_fsm_button, uint32_t button_press_time_ms, fsm_t *p_fsm_tx, fsm_t *p_fsm_rx, uint8_t rgb_id)
{
    fsm_t *p_fsm = malloc(sizeof(fsm_retina_t)); /* Do malloc to reserve memory of all other FSM elements, although it is interpreted as fsm_t (the first element of the structure) */
    fsm_retina_init(p_fsm, p_fsm_button, button_press_time_ms, p_fsm_tx, p_fsm_rx, rgb_id);
    return p_fsm;
}

/**
 * @brief Inittalize the infrared transmitter FSM
 * @param p_this 
 * @param p_fsm_button 
 * @param button_press_time 
 * @param p_fsm_tx 
 */
void fsm_retina_init (fsm_t *p_this, fsm_t *p_fsm_button, uint32_t button_press_time_ms, fsm_t *p_fsm_tx, fsm_t *p_fsm_rx, uint8_t rgb_id)
{
    fsm_retina_t *p_fsm = (fsm_retina_t *)(p_this);
    fsm_init(p_this, fsm_trans_retina);
    p_fsm -> p_fsm_button = p_fsm_button;
    p_fsm -> p_fsm_tx = p_fsm_tx;
    p_fsm -> long_button_press_ms = button_press_time_ms;
    p_fsm -> tx_codes_index = 0;
    p_fsm -> tx_codes_arr_liluco[0] = RED_BUTTON_LILUCO;
    p_fsm -> tx_codes_arr_liluco[1] = GREEN_BUTTON_LILUCO;
    p_fsm -> tx_codes_arr_liluco[2] = BLUE_BUTTON_LILUCO;
    p_fsm->tx_codes_arr_liluco[3] = CYAN_BUTTON_LILUCO;
    p_fsm->tx_codes_arr_liluco[4] = MAGENTA_BUTTON_LILUCO;
    p_fsm->tx_codes_arr_liluco[5] = YELLOW_BUTTON_LILUCO;
    p_fsm->tx_codes_arr_liluco[6] = WHITE_BUTTON_LILUCO;
    p_fsm->tx_codes_arr_liluco[7] = BLACK_BUTTON_LILUCO;
    //MEJORA
    p_fsm -> tx_codes_arr_paulmann[0] = RED_BUTTON_PAULMANN;
    p_fsm -> tx_codes_arr_paulmann[1] = GREEN_BUTTON_PAULMANN;
    p_fsm -> tx_codes_arr_paulmann[2] = BLUE_BUTTON_PAULMANN;
    p_fsm->tx_codes_arr_paulmann[3] = CYAN_BUTTON_PAULMANN;
    p_fsm->tx_codes_arr_paulmann[4] = MAGENTA_BUTTON_PAULMANN;
    p_fsm->tx_codes_arr_paulmann[5] = YELLOW_BUTTON_PAULMANN;
    p_fsm->tx_codes_arr_paulmann[6] = WHITE_BUTTON_PAULMANN;
    p_fsm->tx_codes_arr_paulmann[7] = BLACK_BUTTON_PAULMANN;
    //V3
    p_fsm -> p_fsm_rx = p_fsm_rx;
    p_fsm -> rx_code = 0x00;
    p_fsm -> rgb_id = rgb_id;
    port_rgb_init(rgb_id);
}