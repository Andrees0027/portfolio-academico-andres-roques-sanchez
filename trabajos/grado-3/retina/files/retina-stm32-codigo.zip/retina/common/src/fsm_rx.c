/**
 * @file fsm_rx.c
 * @brief Infrared receiver FSM main file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdlib.h>
#include <stdio.h>

/* Other includes */
#include "fsm_rx.h"
#include "fsm_rx_nec.h"
#include "port_system.h"  
#include "port_rx.h"

/* Typedefs --------------------------------------------------------------------*/
typedef struct
{
  fsm_t f;
  fsm_t *p_fsm_rx_nec;
  uint32_t message_timeout_ms;
  uint32_t last_tick;
  uint32_t num_edges_detected;
  uint32_t code;
  bool is_repetition;
  bool is_error;
  bool status;
  uint8_t rx_id;
} fsm_rx_t;

/* Defines and enums ----------------------------------------------------------*/
/* Enums */
enum FSM_RX {
  OFF_RX,
  IDLE_RX,
  WAIT_RX
};

/* State machine input or transition functions */

/**
 * @brief Check if the infrared receiver must be turned ON.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @returns true if the receiver is turned ON
 * @returns false if the receiver is turned OFF
*/
static bool check_on_rx (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  return (p_fsm -> status);
}


/**
 * @brief Check if the infrared receiver must be turned OFF.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @returns true if the receiver is turned OFF
 * @returns false if the receiver is turned ON
*/
static bool check_off_rx (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  return !(p_fsm -> status);
}



/**
 * @brief Check if there has been a change in the GPIO connected to the infrared receiver.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @returns true if there has been a change in the GPIO connected to the infrared receiver.
 * @returns false if there has not.
*/
static bool check_edge_detection (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  if(port_rx_get_num_edges(p_fsm->rx_id) == p_fsm->num_edges_detected)
    return false;
  else 
    return true;
}  


/**
 * @brief Checks if a timeout has elapsed without detecting any change in infrared reception.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @returns true if a timeout has elapsed without detecting any change in infrared reception.
 * @returns falseif it has not
*/
static bool check_timeout (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  if(port_system_get_millis() - (p_fsm->last_tick) > p_fsm->message_timeout_ms)
    return true;
  else 
    return false;
}  


/**
 * @brief Start the infrared reception system (when the system changes to receiver mode).
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
*/
static void do_rx_start (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  p_fsm->p_fsm_rx_nec = fsm_rx_NEC_new();
  port_rx_tmr_start();
  p_fsm->num_edges_detected = 0;
  port_rx_clean_buffer(p_fsm->rx_id);
  port_rx_en(p_fsm->rx_id, true);
} 


/**
 * @brief Stop the infrared reception system (when the system changes to transmitter mode).
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
*/
static void do_rx_stop (fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  port_rx_tmr_stop();
  port_rx_en(p_fsm->rx_id, false);
  fsm_destroy(p_fsm->p_fsm_rx_nec);
} 


/**
 * @brief Transcribes the received code information using the time-ticks of the edges detected by the infrared receiver.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
*/
static void do_store_data(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  p_fsm->is_repetition = fsm_rx_NEC_parse_code(p_fsm->p_fsm_rx_nec, port_rx_get_buffer_edges(p_fsm->rx_id),port_rx_get_num_edges(p_fsm->rx_id), &(p_fsm->code));
  if(p_fsm->code == 0x00 && !p_fsm->is_repetition){
    p_fsm->is_error = true;
  }
  p_fsm->num_edges_detected = 0;
  port_rx_clean_buffer(p_fsm->rx_id);
}


/**
 * @brief Update the time of the last tick and the number of edges detected.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
*/
static void do_update_len_and_timeout(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  p_fsm->last_tick = port_system_get_millis();
  p_fsm->num_edges_detected = port_rx_get_num_edges(p_fsm -> rx_id);
}

/**
 * @brief Array representing the transitions table of the infrared receiver FSM.
*/
static fsm_trans_t fsm_trans_rx[] = {
  {OFF_RX, check_on_rx, IDLE_RX, do_rx_start},
  {IDLE_RX, check_off_rx, OFF_RX, do_rx_stop},
  {IDLE_RX, check_edge_detection, WAIT_RX, do_update_len_and_timeout},
  {WAIT_RX, check_edge_detection, WAIT_RX, do_update_len_and_timeout},
  {WAIT_RX, check_timeout, IDLE_RX, do_store_data},
  {-1, NULL, -1, NULL}
};


/**
 * @brief Set the status of the infrared receiver (on or off)
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @param status	true to turn the infrared receiver FSM ON. false to turn the infrared receiver FSM OFF.

*/
void fsm_rx_set_rx_status(fsm_t *p_this, bool status){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  p_fsm->status = status;
}

/**
 * @brief Retrieve the code parse (if any)
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * 
*/
uint32_t fsm_rx_get_code(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  return p_fsm->code;
}


/**
 * @brief Retrieve if the the code received is a repetition or not.
 * @param p_this	Pointer to an fsm_t struct than contains an fsm_rx_t.
 * @return true if the NEC code received indicated a repetition
 * @return false if the NEC code received din not indicate a repetition
 
*/
bool fsm_rx_get_repetition(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  return p_fsm->is_repetition;
}

/**
 * @brief Check if the FSM given as a param has an error on its code
 * @param p_this
 * @return bool, is_error param of the FSM given that indicates if it does or does not
 */
bool fsm_rx_get_error_code(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  return p_fsm->is_error;
}	

/**
 * @brief Reset the code of the FSM given as a param
 * @param p_this
 */
void fsm_rx_reset_code(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  p_fsm->code = 0;
  p_fsm->is_repetition = false;
  p_fsm->is_error = false;
}	

/**
 * @brief Check if the FSM given as a param is on the state WAIT_RX meaning it is active
 * @param p_this
 * @return true if it is active
 * @return false if it is not
 */
bool fsm_rx_check_activity(fsm_t *p_this){
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  if(p_fsm->f.current_state == WAIT_RX)
    return true;  
  else
    return false;
}

/* Other auxiliary functions */
/**
 * @brief Initialize an infrared transmitter FSM.
 * @param p_this
 * @param rx_id Unique infrared receiver identifier number
*/
void fsm_rx_init(fsm_t *p_this, uint8_t rx_id)
{
  fsm_rx_t *p_fsm = (fsm_rx_t *)(p_this);
  fsm_init(p_this, fsm_trans_rx);
  p_fsm->rx_id = rx_id;
  p_fsm->code = 0;
  p_fsm->num_edges_detected = 0;  
  p_fsm->last_tick = 0; 
  p_fsm->is_repetition = false;
  p_fsm->is_error = false;  
  p_fsm->status = true; 
  p_fsm->message_timeout_ms = NEC_MESSAGE_TIMEOUT_US/1000;
  port_rx_init(rx_id);
}

/**
 * @brief Create a new infrared receiver FSM
 * The infrared reception module indeed manages 2 FSMs. (i) The first one (`fsm_trans_rx_nec`) controls the reception of infrared pulses and stores the times where the changes on the GPIO occur. (ii) The second one (`fsm_trans_rx_nec`) parses the data received (an array of timestamps) to extract the NEC command. This second FSM that decodes the NEC protocol. Refer to `fsm_rx_NEC_new()` for further information about this FSM.
 * At start and reset, the code value must be '0x00'. A value of '0x00' means that it has not been received any new code. The Retina FSM is the one which stores and retains the last code until a new one is received.
 * @attention The user is required to reset the code value once it has been read. Otherwise, this value may be misinterpreted by the Retina FSM. In such a case we would be interpreting the code constantly. The function `fsm_rx_reset_code()` resets the code when its called.
 * The FSM contains information of the receiver ID. This ID is a unique identifier that is managed by the user in the `port`. That is where the user provides identifiers and HW information for all the receivers on his system. The FSM does not have to know anything of the underlying HW.
 * @param rx_id Unique infrared receiver identifier number
 * @return A pointer to the infrared receiver FSM
 */
fsm_t *fsm_rx_new(uint8_t rx_id)
{
  fsm_t *p_fsm = malloc(sizeof(fsm_rx_t));
  fsm_rx_init(p_fsm, rx_id);
  return p_fsm;
}

