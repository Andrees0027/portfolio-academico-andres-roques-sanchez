/**
 * @file fsm_rx_nec.c
 * @brief NEC processing FSM main file.
 * @author Andrés Roques Sánchez
 * @date 19/05/2023
 */

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdlib.h>
#include <stdio.h>

/* Ohter includes */
#include "fsm_rx_nec.h"
#include "fsm.h"

/* Typedefs --------------------------------------------------------------------*/
typedef struct
{
  fsm_t f;
  uint16_t *p_edge_ticks;
  uint32_t num_edges_to_read;
  uint32_t bits_remaining_to_read;
  uint32_t code;
  bool is_repetition;
} fsm_rx_nec_t;

/* Defines and enums ----------------------------------------------------------*/
/* Enums */

enum  FSM_RX_NEC {
  NEC_IDLE,
  NEC_INIT,
  NEC_SYMBOL_SILENCE,
  NEC_SYMBOL_PULSE
};

/* Private functions */

/**
 * @brief Auxiliary function to compute the time difference (in ticks) between the current and the next edge.
 *
 * @param p_edge_ticks Pointer to the array containing the the time ticks of the edges detected by the infrared receiver
 * @return Time difference in ticks
 */
static uint16_t _get_diff_ticks(uint16_t *p_edge_ticks)
{
  return *(p_edge_ticks + 1) - *(p_edge_ticks);
}

/**
 * @brief Auxiliary function to check if a given value is between two other values.
 *
 * This is used to check if a time difference is between the NEC tolerance time interval.
 *
 * @param value Value to check
 * @param min Minimum value allowed by the range (greater than or equal to).
 * @param max Maximum value allowed by the range (lower than or equal to).
 * @return true if the value given is in between the range given
 * @return false if the value given is not in between the range given
 */
bool _value_in_range(uint16_t value, uint16_t min, uint16_t max)
{
  return ((value >= min) && (value <= max));
}

// CAST fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);

/* State machine input or transition functions */
/**
 * @brief Checks if its perciveing silence
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_init_silence (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  int a = _get_diff_ticks(p_fsm -> p_edge_ticks);
  return _value_in_range(a , NEC_RX_PROLOGUE_TICKS_SILENCE_MIN, NEC_RX_PROLOGUE_TICKS_SILENCE_MAX);

}

/**
 * @brief Checks if its perciveing noise
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_init_noise (fsm_t *p_this){
  return !(check_is_init_silence(p_this));
}

/**
 * @brief Ckecks if its perciveing a prologue pulse
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_prologue_pulse (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  return _value_in_range(_get_diff_ticks(p_fsm -> p_edge_ticks), NEC_RX_PROLOGUE_TICKS_PULSE_MIN, NEC_RX_PROLOGUE_TICKS_PULSE_MAX);
}

/**
 * @brief Ckecks if its perciveing a repetition pulse
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_repetition_pulse (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  return _value_in_range(_get_diff_ticks(p_fsm -> p_edge_ticks), NEC_RX_REPETITION_TICKS_PULSE_MIN, NEC_RX_REPETITION_TICKS_PULSE_MAX);
}

/**
 * @brief
 *
 * @param p_this Checks if its not receiving a prologue pulse nor a repetition pulse, so its pulse noise 
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_init_pulse_noise (fsm_t *p_this){
  bool a = check_is_prologue_pulse(p_this);
  bool b =  check_is_repetition_pulse(p_this);
  if ((!a)&&(!b)){ // if(a||b){return false;}else{return true;}
    return true;
  }
  else {
    return false;
  };
}

/**
 * @brief Cheks if they are more bits to read of the code given 
 *
 * @param p_this
 * @return true If they are
 * @return false if they are not
 */
static bool check_is_last_symbol (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  if (p_fsm ->bits_remaining_to_read == 0){
    return true;
  }
  return false;
}

/**
 * @brief Checks if the symbol received is silence
 *
 * @param p_this
 * @return true if the time difference (in ticks) between the current and the next edge its in between NEC_RX_SYMBOL_TICKS_SILENCE_MIN and MAXNEC_RX_SYMBOL_TICKS_SILENCE_MAX
 * @return false if they are not more bits to read of the code percieved, or if the time difference (in ticks) between the current and the next edge its not in between NEC_RX_SYMBOL_TICKS_SILENCE_MIN and MAX
 */
static bool check_is_symbol_silence (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  if (check_is_last_symbol(p_this) == true){
    return false;
  }
  return _value_in_range(_get_diff_ticks(p_fsm -> p_edge_ticks), NEC_RX_SYMBOL_TICKS_SILENCE_MIN, NEC_RX_SYMBOL_TICKS_SILENCE_MAX);
}

/**
 * @brief Checks if the symbol is not silence (it is silence noise), calling check_is_symbol_silence function
 *
 * @param p_this
 * @return true if the symbol is not
 * @return false if it is
 */
static bool check_is_symbol_silence_noise (fsm_t *p_this){
  if (check_is_last_symbol(p_this) == true){
    return false;
  }
  return !check_is_symbol_silence(p_this);
}

/**
 * @brief Checks if the symbol received is a 0
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_symbol_0_pulse (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  return _value_in_range(_get_diff_ticks(p_fsm -> p_edge_ticks), NEC_RX_SYMBOL_0_TICKS_PULSE_MIN, NEC_RX_SYMBOL_0_TICKS_PULSE_MAX);
}

/**
 * @brief Checks if the symbol received is a 1
 *
 * @param p_this
 * @return true if it is
 * @return false if it is not
 */
static bool check_is_symbol_1_pulse (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);  
  int a = _get_diff_ticks(p_fsm -> p_edge_ticks);
  return _value_in_range(a, NEC_RX_SYMBOL_1_TICKS_PULSE_MIN, NEC_RX_SYMBOL_1_TICKS_PULSE_MAX);
}
 
/**
 * @brief Checks if the symbol pulse is noise, calling check_is_symbol_0_pulse and check_is_symbol_1_pulses function
 *
 * @param p_this
 * @return true if its not a 0 pulse nor a 1 pulse
 * @return false if it is either a 0 pulse or a 1 pulse
 */ 
static bool check_is_symbol_pulse_noise (fsm_t *p_this){
  bool a = check_is_symbol_0_pulse(p_this);
  bool b = check_is_symbol_1_pulse(p_this);
  if ((!a)&&(!b)){
    return true;
  }else{
    return false;
  }
}

/**
 * @brief Jumps the FSM to the next edge
 *
 * @param p_this
 */
static void do_jump_to_next_edge (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> p_edge_ticks++;
  p_fsm -> num_edges_to_read--;
}
 
/**
 * @brief Starts a repetition of the FSM
 *
 * @param p_this
 */
static void do_repetition_starts (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> p_edge_ticks++;
  p_fsm -> num_edges_to_read--;
  p_fsm -> bits_remaining_to_read = 0;
  p_fsm -> is_repetition = true;  
}
 
/**
 * @brief Starts a command of the FSM
 *
 * @param p_this
 */ 
static void do_command_starts (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> p_edge_ticks++;
  p_fsm -> num_edges_to_read--;
  p_fsm -> bits_remaining_to_read = NEC_FRAME_BITS;
  p_fsm -> is_repetition = false;
}
 
/**
 * @brief Reset the FSM and jumps to the next edge
 *
 * @param p_this
 */  
static void do_reset_and_jump_to_next_edge (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> p_edge_ticks++;
  p_fsm -> num_edges_to_read--;
  p_fsm -> code = 0;
}
 
/**
 * @brief Reset the FSM and jumps two edges
 *
 * @param p_this
 */   
static void do_reset_and_jump_two_edges (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> p_edge_ticks = p_fsm -> p_edge_ticks +2;;
  if (p_fsm -> num_edges_to_read > 1){
    p_fsm -> num_edges_to_read = p_fsm -> num_edges_to_read -2;
  }
  p_fsm -> num_edges_to_read = 0;
}

/**
 * @brief Store a bit 0 in the last bit of the code
 *
 * @param p_this
 */   
static void do_store_bit_0 (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);  
  p_fsm -> code = p_fsm -> code <<1;
  p_fsm -> p_edge_ticks++;
  p_fsm -> num_edges_to_read--;
  p_fsm -> bits_remaining_to_read--;
}
 
/**
 * @brief Store a bit 1 in the last bit of the code
 *
 * @param p_this
 */    
static void do_store_bit_1 (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);  
  p_fsm -> code = p_fsm -> code <<1;
  p_fsm -> code |= 0x00000001;
  p_fsm -> p_edge_ticks += 1; 
  p_fsm -> num_edges_to_read--;
  p_fsm -> bits_remaining_to_read--;
}

/**
 * @brief Sets the end by saving the num_edges_to_read equals to 0
 *
 * @param p_this
 */ 
static void do_set_end (fsm_t *p_this){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this);
  p_fsm -> num_edges_to_read=0;
}

/**
 * @brief array with state-machine
 */
static fsm_trans_t 	fsm_trans_rx_nec []={
  {NEC_IDLE, check_is_init_noise , NEC_IDLE, do_reset_and_jump_two_edges},
  {NEC_IDLE, check_is_init_silence , NEC_INIT, do_reset_and_jump_to_next_edge}, 
  {NEC_INIT, check_is_init_pulse_noise , NEC_IDLE, do_jump_to_next_edge}, 
  {NEC_INIT, check_is_repetition_pulse , NEC_SYMBOL_SILENCE, do_repetition_starts}, 
  {NEC_INIT, check_is_prologue_pulse , NEC_SYMBOL_SILENCE, do_command_starts}, 
  {NEC_SYMBOL_SILENCE, check_is_symbol_silence , NEC_SYMBOL_PULSE, do_jump_to_next_edge}, 
  {NEC_SYMBOL_SILENCE, check_is_last_symbol , NEC_IDLE, do_set_end}, 
  {NEC_SYMBOL_SILENCE, check_is_symbol_silence_noise , NEC_IDLE, NULL},
  {NEC_SYMBOL_PULSE, check_is_symbol_pulse_noise , NEC_IDLE, do_jump_to_next_edge},
  {NEC_SYMBOL_PULSE, check_is_symbol_0_pulse , NEC_SYMBOL_SILENCE, do_store_bit_0},
  {NEC_SYMBOL_PULSE, check_is_symbol_1_pulse , NEC_SYMBOL_SILENCE, do_store_bit_1},  
  {-1, NULL, -1, NULL}
};
 

/* Other auxiliary functions */

/**
 * @brief Sets the code of the FSM given, p_this, to 0
 *        Sets the num_edges_to_read of the FSM given, p_this, to 0
 *        Sets the p_edge_ticks of the FSM given, p_this, to NULL
 *        Sets the is_repetition of the FSM given, p_this, to false
 * @param p_this
 * @param fsm_trans_rx_nec
 */ 
void fsm_rx_NEC_init(fsm_t *p_this){
  fsm_init(p_this, fsm_trans_rx_nec); 
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this); 
  // fsm_init(p_fsm, fsm_trans_rx_nec);   
  p_fsm -> code = 0; 
  p_fsm -> num_edges_to_read = 0;
  p_fsm -> p_edge_ticks = NULL;
  p_fsm -> is_repetition = false;
}

/**
 * @brief Sets the current_state of the FSM given, p_this, to 0
 *        Sets the code of the FSM given, p_this, to 0
 *        Sets the is_repetition of the FSM given, p_this, to false
 *        Sets the p_edge_ticks of the FSM given, p_this, to p_edge_ticks given
 *        Sets the num_edges_to_read of the FSM given, p_this, to num_edges given
 *        Sets the is_repetition of the FSM given, p_this, to false
 *        Calls the function fsm_fire with the FSM given as a param while the num_edges_to_read of the FSM given is greater than 1
 *        Sets the pointer p_code given to the code of the FSM given, p_this
 * @param p_this
 * @param p_edge_ticks
 * @param num_edges
 * @param p_code
 * @return the is_repetition of the FSM given
 */ 
bool fsm_rx_NEC_parse_code	(	fsm_t *p_this, uint16_t *p_edge_ticks, uint32_t num_edges, uint32_t *p_code){
  fsm_rx_nec_t *p_fsm = (fsm_rx_nec_t *)(p_this); 
  p_fsm -> f.current_state= 0;
  p_fsm -> code = 0; 
  p_fsm -> is_repetition = false; 
  p_fsm -> p_edge_ticks = p_edge_ticks;
  p_fsm -> num_edges_to_read = num_edges;
  while ( (p_fsm -> num_edges_to_read)>1){
    fsm_fire(p_this);
  }
  *p_code = p_fsm -> code;
  return p_fsm -> is_repetition;
}	

/* Function prototypes and explanation -------------------------------------------------*/
/**
 * @brief Create a new NEC processing FSM
 *
 * This FSM is created when the main system (RETINA) works in reception mode and it is destroyed when the system works in transmission mode.
 *
 * This FSM parses a given array of time-ticks into a NEC code. Each time tick indicates that there was an edge (rising or falling edge) in the GPIO connected to the infrared receiver.
 *
 * @attention The GPIO of the infrared receiver works in input mode and it is always at high level, thus, **the first edge is always a falling edge**. Being this so, we can assert that: *all edges in even positions of the array are falling edges, and edges in odd positions of the array are rising edges*. This is useful information to debug the FSM.
 *
 * The FSM works with time tolerances (deviations in the pulse and silence widths). It is assumed that the timer used to control the time ticks has a resolution of #NEC_RX_TIMER_TICK_BASE_US microseconds.
 *
 * **The FSM goes through all the edges comparing the duration between the current and the following edge**. With this information, we can check if we are parsing (i) the prologue, (ii) a symbol 0, (iii) a symbol 1, (iv) the epilogue, (v) a repetition, or (vi) if the infrared data received was noise of a spurious event, or even a code of another protocol.
 *
 * The FSM receives information of the time ticks of the edges and the number of edges detected. The FSM parses the code and returns it as a pointer. It also indicates if the code was a repetition code or not (it was a command). The FSM stores information on the number of bits remaining to read (expected to be #NEC_FRAME_BITS).
 *
 * Check the transition table `fsm_trans_rx_nec` for further information.
 *
 * @return A pointer to the FSM that parses infrared data as NEC protocol
 */
fsm_t *fsm_rx_NEC_new()
{
  fsm_t *p_fsm = malloc(sizeof(fsm_rx_nec_t));
  fsm_rx_NEC_init(p_fsm);
  return p_fsm;
}