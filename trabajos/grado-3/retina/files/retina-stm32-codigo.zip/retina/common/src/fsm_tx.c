/**
 * @file fsm_tx.c
 * @brief Infrared transmitter FSM main file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

/* Includes ------------------------------------------------------------------*/
#include "fsm_tx.h"
#include <stdlib.h>
#include "port_tx.h"

#define BIT_MASK 0x80000000
/* Typedefs --------------------------------------------------------------------*/

/**
 * @brief Structure to define the Infrared transmitter FSM
 */
typedef struct 
{
fsm_t f; /*!<Infrared transmitter FSM*/
uint32_t code; /*!<Code to be sent*/
uint8_t tx_id; /*!<Transmitter ID.*/

} fsm_tx_t;

/* Defines and enums ----------------------------------------------------------*/
/* Enums */
enum FSM_TX{
    WAIT_TX
};

/* NEC private functions */

/**
 * @brief This function checks if a new code has been set in the FSM for the infrared transmitter. 
 * If it returns true, it indicates that a new code has been set and the FSM should transition to the next state.
 * @param p_this 
 * @return true 
 * @return false 
 */
static bool check_tx_start (fsm_t *p_this){
    fsm_tx_t *p_fsm = (fsm_tx_t *)(p_this);
    if(p_fsm->code == 0x00)
        return false;
    else
        return true;
}

/**
 * @brief This function sends the NEC code that is currently 
 * set in the FSM for the infrared transmitter using fsm_send_NEC_code.
 * @param p_this 
 */
static void do_tx_start (fsm_t *p_this){
    fsm_tx_t *p_fsm = (fsm_tx_t *)(p_this);
    fsm_send_NEC_code(p_fsm->tx_id, p_fsm->code);
    p_fsm->code = 0x00;
}

/**
 * @brief Array of transition structures that define 
 * the state transitions and their associated conditions and actions for the Infrared FSM
 */
static fsm_trans_t fsm_trans_tx[] =
{
    {WAIT_TX, check_tx_start, WAIT_TX, do_tx_start},
    {-1, NULL, -1, NULL}
};

/**
 * @brief This function compares the current tick count and the tick count at the start of the wait time. 
 * @param ticks 
 */
static void _wait_for_tx_ticks ( uint32_t ticks){
    uint32_t initTick = port_tx_tmr_get_tick();
    while(port_tx_tmr_get_tick()-initTick < ticks)
    {

    }
}

/**
 * @brief This function sends an NEC burst by the given tx_id. It turns the transmitter on for ticks_ON microseconds and off for ticks_OFF microseconds.
 * @param tx_id 
 * @param ticks_ON 
 * @param ticks_OFF 
 */
static void _send_NEC_burst (uint8_t tx_id, uint32_t ticks_ON, uint32_t ticks_OFF){
    port_tx_pwm_timer_set(tx_id, true);
    _wait_for_tx_ticks (ticks_ON);
    port_tx_pwm_timer_set(tx_id, false);
    _wait_for_tx_ticks (ticks_OFF);
    
}
   

/* State machine input or transition functions */

/**
 * @brief This function sets the code value in the FSM for the infrared transmitter.
 * @param p_this 
 * @param code 
 */
void fsm_tx_set_code (fsm_t *p_this, uint32_t code){
    fsm_tx_t *p_fsm = (fsm_tx_t *)(p_this);
    if (code != 0x00)
        p_fsm->code = code;
}

/* State machine output or action functions */


/* Other auxiliary functions */

/**
 * @brief This function sends a NEC code.
 * @param tx_id 
 * @param code 
 */
void fsm_send_NEC_code(uint8_t tx_id, uint32_t code)
{
    uint32_t b = BIT_MASK;
    port_tx_symbol_tmr_start();
    _send_NEC_burst(tx_id, NEC_TX_PROLOGUE_TICKS_ON, NEC_TX_PROLOGUE_TICKS_OFF);
    do{
    if(code & b){
        _send_NEC_burst(tx_id, NEC_TX_SYM_1_TICKS_ON, NEC_TX_SYM_1_TICKS_OFF);
    }else{
        _send_NEC_burst(tx_id, NEC_TX_SYM_0_TICKS_ON, NEC_TX_SYM_0_TICKS_OFF);
    }
    b=b>>1;
    }while(b>0);
    _send_NEC_burst(tx_id, NEC_TX_EPILOGUE_TICKS_ON, NEC_TX_EPILOGUE_TICKS_OFF);
    port_tx_symbol_tmr_stop();

}

/**
 * @brief This function creates a new instance of the FSM. It reserves memory of its elements.
 * @param tx_id 
 * @return fsm_t* 
 */
fsm_t *fsm_tx_new(uint8_t tx_id)
{
    fsm_t *p_fsm = malloc(sizeof(fsm_tx_t)); /* Do malloc to reserve memory of all other FSM elements, although it is interpreted as fsm_t (the first element of the structure) */
    fsm_tx_init(p_fsm, tx_id);
    return p_fsm;
}

/**
 * @brief This function initializes the FSM, sets the tx_id and code values in the FSM, and calls port_tx_init to initialize the transmitter port.
 * @param p_this 
 * @param tx_id 
 */
void fsm_tx_init(fsm_t *p_this, uint8_t tx_id)
{
    fsm_tx_t *p_fsm = (fsm_tx_t *)(p_this);
    fsm_init(p_this, fsm_trans_tx);
    p_fsm -> tx_id = tx_id;
    p_fsm -> code = 0;
    port_tx_init(tx_id, false);

}

/**
 * @brief Check if the transmitter FSM is active, or not.
 *        As the system is the one controlling the output (PWM and symbol timer), this FSM will always be inactive and will wake up at each interruption of the symbol timer or PWM timer.
 * @param p_this 
 * @return true 
 * @return false 
 */
bool fsm_tx_check_activity (fsm_t *p_this){
    fsm_tx_t *p_fsm = (fsm_tx_t *)(p_this);
    if(p_fsm->code == 0){
        return false;
    }else{
        return false;
    }
}