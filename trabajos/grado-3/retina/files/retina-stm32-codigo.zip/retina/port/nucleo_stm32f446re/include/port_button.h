/**
 * @file port_button.h
 * @brief Header for port_button.c file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

#ifndef PORT_BUTTON_H_
#define PORT_BUTTON_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdint.h>
#include <stdbool.h>


/* HW dependent includes */

#include "port_system.h"


/* Defines and enums ----------------------------------------------------------*/
/* Defines */
#define BUTTON_0_ID 0 /*!<Nombre (id) de boton, primer boton = 0*/
#define BUTTON_0_GPIO GPIOC /*!<GPIO conectada el boton*/
#define BUTTON_0_PIN 13 //*!<Puerto o pin del boton en la gpio*/
#define BUTTON_0_DEBOUNCE_TIME_MS 100 /*!<Tiempo de debounce, ms*/

/* Function prototypes and explanation -------------------------------------------------*/
/**
 * @brief initiates a button given the right parameters
 * 
 * @param button_id The ID of the button to check
 */
void port_button_init (uint32_t button_id);

/**
 * @brief 
 * 
 * This function checks the `flag_pressed` field of the button struct corresponding to the specified `button_id`.
 * If the flag is set to `true`, it means that the button is currently pressed.
 * 
 * @param button_id The ID of the button to check
 * @return `true` if the button is pressed
 * @return `false` if its not 
 */
bool port_button_is_pressed	(uint32_t button_id	);

/**
 * @brief Get the current system tick value.
 * 
 * This function returns the current system tick value, which is obtained using the
 * `port_system_get_millis()` function. The system tick value is used for debouncing
 * buttons and measuring button press durations.
 * 
 * @retval The current system tick value in milliseconds.
 */
uint32_t port_button_get_tick ();



#endif
