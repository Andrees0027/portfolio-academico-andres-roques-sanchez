/**
 * @file port_rgb.h
 * @brief Header for port_rgb.c file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

#ifndef PORT_RGB_H_
#define PORT_RGB_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdint.h>

/* Defines and enums ----------------------------------------------------------*/
/* Defines */
/* NEC transmission macros */
#define RGB_0_ID 0
#define RGB_R_0_GPIO GPIOB
#define RGB_R_0_PIN 4
#define RGB_G_0_GPIO GPIOC //GPIO C7
#define RGB_G_0_PIN 7
#define RGB_B_0_GPIO GPIOB
#define RGB_B_0_PIN 5 

/**
 * @brief Configure the HW specifications of a given RGB LED.
 * @param rgb_id
*/
void port_rgb_init( uint8_t rgb_id);

/**
 * @brief Set a color on the RGB LED.
 * This function receives integer values expected to be within the range [0, 255].
 * With this we can set any color by using PWM. The frequency of the PWM (timer) signal can be the same for the three LEDs.
 * However each one need a dedicated channel. Any frequency higher than 25 Hz should be sufficient to avoid flicking.
 * This would lead us to display up to 256^3=16.777.216 colors.
 * @param rgb_id
 * @param r
 * @param g
 * @param b
*/
void port_rgb_set_color	( uint8_t rgb_id, uint8_t r, uint8_t g, uint8_t b);	

















#endif