/**
 * @file port_tx.h
 * @brief Header for port_tx.c file.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

#ifndef PORT_TX_H_
#define PORT_TX_H_

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <stdint.h>
#include <stdbool.h>

/* HW dependent includes */

#include "port_system.h" // YA NO DA ERROR POR LA CARA

/* Defines and enums ----------------------------------------------------------*/

#define IR_TX_0_ID 0
#define IR_TX_0_GPIO GPIOB
#define IR_TX_0_PIN 10

/* Defines */

/* Function prototypes and explanation -------------------------------------------------*/
/**
 * @brief Configure a infrared transmitter.
 * @param tx_id 
 * @param status 
 */
void port_tx_init (uint8_t tx_id, bool status);

/**
 * @brief Set the PWM ON or OFF.
 * @param tx_id 
 * @param status 
 */
void port_tx_pwm_timer_set(uint8_t tx_id, bool status);

/**
 * @brief Start the symbol timer and reset the count of ticks. 
 */
void port_tx_symbol_tmr_start();

/**
 * @brief 	Stop the symbol timer.
 */
void port_tx_symbol_tmr_stop();

/**
 * @brief Get the count of the symbol ticks.
 * @return uint32_t 
 */
uint32_t port_tx_tmr_get_tick();

#endif