/**
 * @file port_button.c
 * @brief File containing functions related to the HW of the button FSM.
 * This files defines an internal struct which coontains the HW information of the 
 * @author Andrés Roques Sánchez
 * @date 24/03/2023
 */

/* Includes ------------------------------------------------------------------*/
#include "port_button.h"

/* Typedefs --------------------------------------------------------------------*/
typedef struct
{
    GPIO_TypeDef *p_port;
    uint8_t pin;
    bool flag_pressed;
} port_button_hw_t;

/* Global variables ------------------------------------------------------------*/

/**
 * @brief Array of hardware button configurations.
 * 
 * This static array defines the hardware configuration for each button.
 * Each element of the array corresponds to a specific button ID.
 * The hardware configuration includes the GPIO port and pin to which the button is connected,
 * as well as a flag indicating whether the button is currently pressed or not.
 *
 */

static port_button_hw_t buttons_arr[] = {
    [BUTTON_0_ID] = {.p_port = BUTTON_0_GPIO, .pin = BUTTON_0_PIN, .flag_pressed = false},
};





/**
 * @brief initiates a button given the right parameters
 * 
 * @param button_id The ID of the button to check
 */
void port_button_init(uint32_t button_id)
{
    // GPIO_TypeDef *p_port = buttons_arr[button_id].p_port;
    // uint8_t pin = buttons_arr[button_id].pin;

    port_system_gpio_config(buttons_arr[button_id].p_port, buttons_arr[button_id].pin, 0x00, 0x00);
    port_system_gpio_config_exti(buttons_arr[button_id].p_port, buttons_arr[button_id].pin, 0x08|0x03);
    port_system_gpio_exti_enable(buttons_arr[button_id].pin, 0x01, 0x00);
}


/**
 * @brief 
 * 
 * This function checks the `flag_pressed` field of the button struct corresponding to the specified `button_id`.
 * If the flag is set to `true`, it means that the button is currently pressed.
 * 
 * @param button_id The ID of the button to check
 * @return `true` if the button is pressed
 * @return `false` if its not 
 */
bool port_button_is_pressed	( uint32_t button_id ){
    return buttons_arr[button_id].flag_pressed;
}	

/**
 * @brief Get the current system tick value.
 * 
 * This function returns the current system tick value, which is obtained using the
 * `port_system_get_millis()` function. The system tick value is used for debouncing
 * buttons and measuring button press durations.
 * 
 * @retval The current system tick value in milliseconds.
 */

uint32_t port_button_get_tick () {
    return port_system_get_millis();
}	
	
//------------------------------------------------------
// INTERRUPT SERVICE ROUTINES
//------------------------------------------------------
/**
 * @brief  This function handles Px10-Px15 global interrupts.
 * 
 * First, this function identifies the line/ pin which has raised the interruption. Then, perform the desired action. Before leaving it cleans the interrupt pending register.
 *
 * > **TO-DO alumnos**
 * > 
 * > ✅ 1. Read the value of the GPIO og the user button. Use the #BUTTON_0_ID index to get the port and pin from the `buttons_arr` \n
 * > ✅ 2. If the value is #HIGH means that the button as been released, therefore set the field `flag_pressed` to `false` \n
 * > ✅ 3. If the value is #LOW means that the button as been pressed, therefore set the field `flag_pressed` to `true` \n
 * > ✅ 4. Clean the corresponding bit of the `PR` register \n
 * > &nbsp;&nbsp;&nbsp;&nbsp;💡 Recommendation: use the macro #BIT_POS_TO_MASK \n 
 * > &nbsp;&nbsp;&nbsp;&nbsp;💡 **To clean an interrupt in the *Pending Register* (`PR`) we must write '1' in the corresponding bit**. *Look at the example in section "3.9.7. Ejemplo de interrupción externa" of the reference book.* You can also find this out by consulting the *reference manual* (section "10.3.6 Pending register (EXTI_PR)") * \n 
 * \n
 * 
 */
void EXTI15_10_IRQHandler(void) {
    /* ISR user button in PC13 */
    //VERSION 4
    port_system_systick_resume();
    if (EXTI->PR & BIT_POS_TO_MASK(buttons_arr[BUTTON_0_ID].pin))
    {
      /* TO-DO alumnos */
    bool check = port_system_gpio_read(buttons_arr[BUTTON_0_ID].p_port, buttons_arr[BUTTON_0_ID].pin);
    if (check){
        buttons_arr[BUTTON_0_ID].flag_pressed = false;
    }else{
        buttons_arr[BUTTON_0_ID].flag_pressed = true;
    }
        EXTI->PR |= BIT_POS_TO_MASK(buttons_arr[BUTTON_0_ID].pin);
    }
}

