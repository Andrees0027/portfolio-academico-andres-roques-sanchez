/**
 * @file port_rgb.c
 * @brief File containing functions related to the HW of the RGB.
 * This files defines an internal struct which coontains the HW information of the 
 * @author Andrés Roques Sánchez
 * @date fecha
 */

/* Includes ------------------------------------------------------------------*/

#include "port_rgb.h"
#include "port_system.h"


typedef struct
{
    GPIO_TypeDef *p_port_red;
    uint8_t pin_red;
    GPIO_TypeDef *p_port_green;
    uint8_t pin_green;
    GPIO_TypeDef *p_port_blue;
    uint8_t pin_blue;
} port_rgb_hw_t;

/**
 * @brief Array of elements that represents the characteristics of the RGB_0_ID and defines its characteristics
 */
static port_rgb_hw_t rgb_arr[] = {
    [RGB_0_ID] = {.p_port_red = RGB_R_0_GPIO, .pin_red = RGB_R_0_PIN,
                  .p_port_green = RGB_G_0_GPIO, .pin_green = RGB_G_0_PIN,
                  .p_port_blue = RGB_B_0_GPIO, .pin_blue = RGB_B_0_PIN,}
};

/**
 * @brief Configure the HW specifications of a given RGB LED.
 * @param rgb_id
*/
void port_rgb_init ( uint8_t rgb_id){
    port_system_gpio_config(rgb_arr[rgb_id].p_port_red, rgb_arr[rgb_id].pin_red, 0x01, 0x00);
    port_system_gpio_config(rgb_arr[rgb_id].p_port_green, rgb_arr[rgb_id].pin_green, 0x01, 0x00);
    port_system_gpio_config(rgb_arr[rgb_id].p_port_blue, rgb_arr[rgb_id].pin_blue, 0x01, 0x00);
    port_rgb_set_color(rgb_id, 0x00, 0x00, 0x00);
}	

/**
 * @brief Set a color on the RGB LED.
 * This function receives integer values expected to be within the range [0, 255].
 * With this we can set any color by using PWM. The frequency of the PWM (timer) signal can be the same for the three LEDs.
 * However each one need a dedicated channel. Any frequency higher than 25 Hz should be sufficient to avoid flicking.
 * This would lead us to display up to 256^3=16.777.216 colors.
 * @param rgb_id
 * @param r
 * @param g
 * @param b
*/
void port_rgb_set_color	( uint8_t rgb_id, uint8_t r, uint8_t g, uint8_t b ){
    port_system_gpio_write(rgb_arr[rgb_id].p_port_red, rgb_arr[rgb_id].pin_red, (bool)r);
    port_system_gpio_write(rgb_arr[rgb_id].p_port_green, rgb_arr[rgb_id].pin_green, (bool)g);
    port_system_gpio_write(rgb_arr[rgb_id].p_port_blue, rgb_arr[rgb_id].pin_blue, (bool)b);
}

