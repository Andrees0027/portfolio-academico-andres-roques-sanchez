/**
 * @file port_rx.c
 * @brief Portable functions to interact with the infrared receiver FSM library.
 * @author Andrés Roques Sánchez
 * @date fecha
 * */

/* Includes ------------------------------------------------------------------*/
/* Standard C includes */
#include <string.h> /* To use memset */

/* Other includes */
#include "port_rx.h"  
#include "port_system.h"
#include "fsm_rx_nec.h"

#define TIM_AS_PWM1_MASK 0x0060 /*libro*/

/* Typedefs --------------------------------------------------------------------*/
/**
 * @brief Structure to define the HW dependencies of an infrared receiver.
 */
typedef struct
{
  GPIO_TypeDef *p_port;
  uint8_t pin;
  uint16_t edge_ticks [NEC_FRAME_EDGES];
  uint16_t edge_idx;
} port_rx_hw_t;

/* Global variables ------------------------------------------------------------*/
/**
 * @brief Array of elements that represents the HW characteristics of the infrared receivers.
 */

static port_rx_hw_t receivers_arr[] = {
  [IR_RX_0_ID] = {.p_port = IR_RX_0_GPIO, .pin = IR_RX_0_PIN,}
};

/* Infrared receiver private functions */
/**
 * @brief Set the elements of the array of time ticks to '0' and init the index to '0' as well.
 * > &nbsp;&nbsp;&nbsp;&nbsp;💡 To set all the elements of an array to one value, you can use function `memset`. You need a pointer to the array (its name), the value you want to set, and the length (in bytes) of the array (so you need to multiply the number of elements by the size of the type of the elements of the array). To use this function you need to include the <string.h> library.
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 */
static void _reset_edge_ticks_idx(uint8_t rx_id)
{
  memset(receivers_arr[rx_id].edge_ticks, 0, sizeof(uint16_t) * NEC_FRAME_EDGES);
  receivers_arr[rx_id].edge_idx = 0; //Set the elements of the array of time ticks to '0' and init the index to '0' as well.
}

// static void _store_edge_tick(uint8_t rx_id){
//   int i = receivers_arr[rx_id].edge_idx;
//   bool a = port_system_gpio_read(IR_RX_0_GPIO, IR_RX_0_PIN);
//   if (a == (i & 0x0001)){
//     if (i < NEC_FRAME_EDGES){
//       receivers_arr[rx_id].edge_ticks[i] = TIM3->CNT;
//       receivers_arr[rx_id].edge_idx +=1;
//     }
//   }else{
//     return;
//   }
// }
 

/**
 * @brief Store the time tick of the last edge detected.
 *        This function is called by the ISR after an interruption of the GPIO.
 * @param rx_id	Receiver ID. This index is used to select the element of the receivers_arr[] array.
*/
static void _store_edge_tick(uint8_t rx_id)
{
 int a = receivers_arr[rx_id].edge_idx & 0x0001;
 if (port_system_gpio_read(receivers_arr[rx_id].p_port, receivers_arr[rx_id].pin) == a){
    if (receivers_arr[rx_id].edge_idx < NEC_FRAME_EDGES){
      receivers_arr[rx_id].edge_ticks[receivers_arr[rx_id].edge_idx] = TIM3 -> CNT;
      receivers_arr[rx_id].edge_idx++;
  } 
}
}

/**
 * @brief Configure the timer tick. This timer sets the basis for tick counting for checking received NEC symbols.
          This timer does not generate interruptions. It is like the Systick, but faster.
          The Systick has a period of 1 ms which is to large for the identification of NEC symbols.
          That is why we need another counter.
          With this timer we are not interested very much on the value of the ARR register but on the PSC register.
          We will set up the ARR register to its maximum value to ensure that each increment of the prescaler corresponds to NEC_RX_TIMER_TICK_BASE_US.
          On the other hand, we set the PSC so that each increment of this register represents NEC_RX_TIMER_TICK_BASE_US.
*/
void _timer_rx_setup(){ // MIRAR NUMEROS
  RCC -> APB1ENR |= RCC_APB1ENR_TIM3EN;
  TIM3 -> CR1 &= ~ TIM_CR1_CEN;
  TIM3 -> CR1 |=TIM_CR1_ARPE ; 
  TIM3 -> CNT = 0; 
  TIM3 -> ARR = 65535;
  TIM3 -> PSC = 159; //PSC = fclk * Tinterr - 1
  TIM3 -> EGR = TIM_EGR_UG;
}

/**
 * @brief Configure the HW specifications of a given infrared receiver.
 *
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 */
void port_rx_init(uint8_t rx_id) { //port_button.c
  _timer_rx_setup();
  port_system_gpio_config(receivers_arr[rx_id].p_port, receivers_arr[rx_id].pin, 0x00, 0x00);
  port_system_gpio_config_exti(receivers_arr[rx_id].p_port, receivers_arr[rx_id].pin, 0x08|0x03);
  port_system_gpio_exti_enable(receivers_arr[rx_id].pin, 0x02, 0x00);
  _reset_edge_ticks_idx(rx_id);
}

/**
 * @brief Enable/disable the interruptions of the infrared receiver.
 *
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 * @param interr_en boolean which enable/disable the interruptions of the infrared receiver.
 */
void port_rx_en(uint8_t rx_id, bool interr_en){
  _reset_edge_ticks_idx(rx_id);
  if (interr_en == true){
    port_system_gpio_exti_enable(receivers_arr[rx_id].pin, 0x02, 0x00);
  }else{
    port_system_gpio_exti_disable(receivers_arr[rx_id].pin);
  }
}

/**
 * @brief Enable the tick count timer. It does not have params nor returns anything.
 */
void port_rx_tmr_start() {
  TIM3 -> CNT = 0;
  TIM3 -> CR1 |= TIM_CR1_CEN ;
}

/**
 * @brief Disable the tick count timer. It does not have params nor returns anything.
 */
void port_rx_tmr_stop() {
  TIM3 -> CR1 &= ~TIM_CR1_CEN;
}

/**
 * @brief Return the number of edges detected by the infrared receiver so far.
 *
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 * @return uint32_t Number of edges detected so far.
 */
uint32_t port_rx_get_num_edges(uint8_t rx_id) {
  return receivers_arr[rx_id].edge_idx;
}

/**
 * @brief Return a pointer to de memory address of the array that stores the time ticks of the edges detected by the infrared receiver.
 *
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 * @return uint16_t Pointer to the memory address of the array of time ticks.
 */
uint16_t *port_rx_get_buffer_edges(uint8_t rx_id) {
  return (uint16_t *)(&(receivers_arr[rx_id].edge_ticks));
}

/**
 * @brief Clean the array that stores the time ticks of the edges detected by the infrared receiver.
 * @param rx_id Receiver ID. This index is used to select the element of the `receivers_arr[]` array.
 */
void port_rx_clean_buffer(uint8_t rx_id) {
  _reset_edge_ticks_idx(rx_id);
}

/**
 * @brief This function handles Px5-Px9 global interrupts.
          First, this function identifies the line/ pin which has raised the interruption.
          Then, perform the desired action. Before leaving it cleans the interrupt pending register.
*/
void EXTI9_5_IRQHandler(void)
{
  //VERSION 4
  port_system_systick_resume();
  
  if (EXTI->PR & BIT_POS_TO_MASK(receivers_arr[IR_RX_0_ID].pin)) {
    EXTI->PR |= BIT_POS_TO_MASK(receivers_arr[IR_RX_0_ID].pin);
    _store_edge_tick(IR_RX_0_ID);
  }
}
