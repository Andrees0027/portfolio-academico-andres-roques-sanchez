/**
 * @file port_system.c
 * @brief File that defines the functions that are related to the access to the specific HW of the microcontroller.
 * @author Sistemas Digitales II
 * @date 2023-01-01
 */

/* Includes ------------------------------------------------------------------*/
#include "port_system.h"

/* Defines -------------------------------------------------------------------*/
#define HSI_VALUE ((uint32_t)16000000) /*!< Value of the Internal oscillator in Hz */
#define BIT_MASK 0x0f

/* GLOBAL VARIABLES */
static uint32_t msTicks = 0; /*!< Variable to store millisecond ticks. @warning **It must be declared volatile!** Just because it is modified in an ISR. **Add it to the definition** after *static*. */

/* These variables are declared extern in CMSIS (system_stm32f4xx.h) */
uint32_t SystemCoreClock = HSI_VALUE; /*!< Frequency of the System clock */
const uint8_t AHBPrescTable[16] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 6, 7, 8, 9}; /*!< Prescaler values for AHB bus */
const uint8_t APBPrescTable[8] = {0, 0, 0, 0, 1, 2, 3, 4}; /*!< Prescaler values for APB bus */

//------------------------------------------------------
// SYSTEM CONFIGURATION
//------------------------------------------------------
/**
 * @brief  Setup the microcontroller system
 *         Initialize the FPU setting, vector table location and External memory
 *         configuration.
 *
 * @note   This function is called at startup by CMSIS in startup_stm32f446xx.s.
 */
void SystemInit(void)
{
/* FPU settings ------------------------------------------------------------*/
#if (__FPU_PRESENT == 1) && (__FPU_USED == 1)
  SCB->CPACR |= ((3UL << 10 * 2) | (3UL << 11 * 2)); /* set CP10 and CP11 Full Access */
#endif

#if defined(DATA_IN_ExtSRAM) || defined(DATA_IN_ExtSDRAM)
  SystemInit_ExtMemCtl();
#endif /* DATA_IN_ExtSRAM || DATA_IN_ExtSDRAM */

  /* Configure the Vector Table location -------------------------------------*/
#if defined(USER_VECT_TAB_ADDRESS)
  SCB->VTOR = VECT_TAB_BASE_ADDRESS | VECT_TAB_OFFSET; /* Vector Table Relocation in Internal SRAM */
#endif                                                 /* USER_VECT_TAB_ADDRESS */
}

/**
 * @brief System Clock Configuration
 *
 * @attention This function should NOT be accesible from the outside to avoid configuration problems.
 * @note This function starts a system timer that generates a SysTick every 1 ms.
 * @retval None
 */
static void system_clock_config(void)
{
  /** Configure the main internal regulator output voltage */
  /* Power controller (PWR) */
  /* Control the main internal voltage regulator output voltage to achieve a trade-off between performance and power consumption when the device does not operate at the maximum frequency */
  PWR->CR &= ~PWR_CR_VOS; // Clean and set value
  PWR->CR |= (PWR_CR_VOS & (POWER_REGULATOR_VOLTAGE_SCALE3 << PWR_CR_VOS_Pos));

  /* Initializes the RCC Oscillators. */
  /* Adjusts the Internal High Speed oscillator (HSI) calibration value.*/
  RCC->CR &= ~RCC_CR_HSITRIM; // Clean and set value
  RCC->CR |= (RCC_CR_HSITRIM & (RCC_HSI_CALIBRATION_DEFAULT << RCC_CR_HSITRIM_Pos));

  /* RCC Clock Config */
  /* Initializes the CPU, AHB and APB buses clocks */
  /* To correctly read data from FLASH memory, the number of wait states (LATENCY)
      must be correctly programmed according to the frequency of the CPU clock
      (HCLK) and the supply voltage of the device. */

  /* Increasing the number of wait states because of higher CPU frequency */
  FLASH->ACR = FLASH_ACR_LATENCY_2WS; /* Program the new number of wait states to the LATENCY bits in the FLASH_ACR register */

  /* Change in clock source is performed in 16 clock cycles after writing to CFGR */
  RCC->CFGR &= ~RCC_CFGR_SW; // Clean and set value
  RCC->CFGR |= (RCC_CFGR_SW & (RCC_CFGR_SW_HSI << RCC_CFGR_SW_Pos));

  /* Update the SystemCoreClock global variable */
  SystemCoreClock = HSI_VALUE >> AHBPrescTable[(RCC->CFGR & RCC_CFGR_HPRE) >> RCC_CFGR_HPRE_Pos];

  /* Configure the source of time base considering new system clocks settings */
  SysTick_Config(SystemCoreClock / (1000U / TICK_FREQ_1KHZ)); /* Set Systick to 1 ms */
}

size_t port_system_init()
{
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  /* Configure Flash prefetch, Instruction cache, Data cache */
  /* Instruction cache enable */
  FLASH->ACR |= FLASH_ACR_ICEN;

  /* Data cache enable */
  FLASH->ACR |= FLASH_ACR_DCEN;

  /* Prefetch cache enable */
  FLASH->ACR |= FLASH_ACR_PRFTEN;

  /* Set Interrupt Group Priority */
  NVIC_SetPriorityGrouping(NVIC_PRIORITY_GROUP_4);

  /* Use systick as time base source and configure 1ms tick (default clock after Reset is HSI) */
  /* Configure the SysTick IRQ priority. It must be the highest (lower number: 0)*/
  NVIC_SetPriority(SysTick_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0U, 0U)); /* Tick interrupt priority */

  /* Init the low level hardware */
  /* Reset and clock control (RCC) */
  RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; /* Syscfg clock enabling */

  /* Peripheral clock enable register */
  RCC->APB1ENR |= RCC_APB1ENR_PWREN; /* PWREN: Power interface clock enable */

  /* Configure the system clock */
  system_clock_config();

  return 0;
}

// VERSION 4

/**
 * @brief Set the system in stop mode for low power consumption.
 *        The function sets the state of the power regulator in stop mode
 *        After that, the function sets the system mode in sleep mode, to enter in stop mode when calling _WFI() (wait for interruption).
 *        The system remains in this line until an external interruption or timer interruption occurs.
 *        If an interruption occurs the system wakes up and resets the system mode.
 * @retval None
 */
void port_system_power_stop()
{
 MODIFY_REG(PWR->CR, (PWR_CR_PDDS | PWR_CR_LPDS), PWR_CR_LPDS);   // Select the regulator state in Stop mode: Set PDDS and LPDS bits according to PWR_Regulator value
  SCB->SCR |= ((uint32_t)SCB_SCR_SLEEPDEEP_Msk);   // Set SLEEPDEEP bit of Cortex System Control Register
 __WFI(); // Select Stop mode entry : Request Wait For Interrupt
 SCB->SCR &= ~((uint32_t)SCB_SCR_SLEEPDEEP_Msk); // Reset SLEEPDEEP bit of Cortex System Control Register
}

/**
 * @brief Suspend Tick increment.
 *        The SysTick timer is the source of time base. 
 *        It is used to generate interrupts at regular time intervals.
 *        Once this function is called, the SysTick interrupt will be disabled so it saves more energy and it does not generate any interruption.
 * @retval None
 */
void port_system_systick_suspend()
{
 SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;
}

/**
 * @brief Resume Tick increment.
 *        The SysTick timer is the source of time base. 
 *        It is used to generate interrupts at regular time intervals.
 *        Once this function is called, the SysTick interrupt will be enabled and so Tick increment is resumed.
 * @retval None
 */
void port_system_systick_resume()
{
  SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
}

/**
 * @brief Enable low power consumption in sleep mode.
 * @retval None
*/
void port_system_sleep (void){
  port_system_systick_suspend();
  port_system_power_stop();
}	





//------------------------------------------------------
// TIMER RELATED FUNCTIONS
//------------------------------------------------------

/**
 * @brief This function retrieves the count of the System tick in milliseconds.
 * 
 * @return uint32_t 
 */
uint32_t port_system_get_millis ()
{
  return msTicks;
}

/**
 * @brief This functions makes the system wait for ms milliseconds.
 * 
 * @param ms Number of milliseconds to wait
 */
void port_system_delay_ms(uint32_t ms)
{
  uint32_t start = port_system_get_millis();

  while ((port_system_get_millis() - start) < ms)
  {
  }
}

/**
 * @brief This function is similar from port_system_delay_ms() but it uses a time reference from which it has to count ms milliseconds.
 * 
 * @param p_t Pointer to the time reference
 * @param ms 	Number of milliseconds to wait
 */
void port_system_delay_until_ms(uint32_t *p_t, uint32_t ms)
{
  uint32_t until = *p_t + ms;
  uint32_t t = port_system_get_millis();
  if (until > t)
  {
    port_system_delay_ms(until - t);
  }
  *p_t = port_system_get_millis();
}

//------------------------------------------------------
// GPIO RELATED FUNCTIONS
//------------------------------------------------------
/**
 * @brief This function enables interrupts of a GPIO line/pin.
 * 
 * @param pin Pin/line of the GPIO (index from 0 to 15)
 * @param priority Priority level (from highest priority: 0, to lowest priority: 15)
 * @param subpriority Subpriority level (from highest priority: 0, to lowest priority: 15)
 */
void port_system_gpio_exti_enable(uint8_t pin, uint8_t priority, uint8_t subpriority)
{
  NVIC_SetPriority(GET_PIN_IRQN(pin), NVIC_EncodePriority(NVIC_GetPriorityGrouping(), priority, subpriority));
  NVIC_EnableIRQ(GET_PIN_IRQN(pin));
}

/**
 * @brief This function disables interrupts of a GPIO line/pin.
 * 
 * @param pin Pin/line of the GPIO (index from 0 to 15)
 */
void port_system_gpio_exti_disable(uint8_t pin)
{  
  NVIC_DisableIRQ(GET_PIN_IRQN(pin));
}

/**
* @brief Configures a GPIO pin to be used with an alternate function.
* This function sets the alternate function for a given GPIO pin on a given port.
* It takes in the GPIO port pointer, pin number and the alternate function number as arguments.
* The alternate function number is used to configure the 4-bit field in the GPIO alternate function register (AFR).
* @param p_port GPIO port pointer.
* @param pin GPIO pin number.
* @param mode 	Input, output, alternate, or analog
* @param pupd Pull-up, pull-down, or no-pull
* @note This function assumes that the GPIO peripheral clock has already been enabled.
*/
void port_system_gpio_config	(	GPIO_TypeDef* p_port, uint8_t 	pin, uint8_t 	mode, uint8_t 	pupd ){
  if (p_port == GPIOA){
  RCC -> AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
  } else if (p_port == GPIOB){
  RCC -> AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
  } else if (p_port == GPIOC){
  RCC -> AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
  }
  p_port -> MODER &=  ~( 0x03 << 2U*pin );
  p_port -> MODER |= ( mode  << 2U*pin );
  p_port -> PUPDR &= ~( 0x03 << 2U*pin ) ;
  // p_port -> PUPDR |= (pupd << 2U*pin);
}

/**
* @brief Configures the EXTI (External Interrupt) mode for a GPIO pin in a specific port.
* This function enables the EXTI mode for a GPIO pin in a specific port, and sets the triggering mode for the EXTI interrupt.
* It configures the SYSCFG peripheral registers with the appropriate EXTI configuration for the selected GPIO pin.
* @param p_port Pointer to the GPIO port used for the EXTI configuration.
* @param pin The GPIO pin number used for the EXTI configuration.
* @param mode 	Input, output, alternate, or analog
*/
void port_system_gpio_config_exti	(	GPIO_TypeDef * p_port, uint8_t pin, uint32_t mode  ) {
  RCC -> APB2ENR |= RCC_APB2ENR_SYSCFGEN;
  if (pin<=3){
    SYSCFG -> EXTICR[0] |= (0x0f << 4U*(pin%4));
    if (p_port == GPIOA){
      SYSCFG -> EXTICR[0] &= (0x00 << 4U*(pin%4));
    } else if (p_port == GPIOB){
      SYSCFG -> EXTICR[0] &= (0x01 << 4U*(pin%4));
    } else if (p_port == GPIOC){
      SYSCFG -> EXTICR[0] &= (0x02 << 4U*(pin%4));
    }
  }
  else if (pin >3 && pin<8){
    SYSCFG -> EXTICR[1] |= (0x0f << 4U*(pin%4));
    if (p_port == GPIOA){
      SYSCFG -> EXTICR[1] &= (0x00 << 4U*(pin%4));
    } else if (p_port == GPIOB){
      SYSCFG -> EXTICR[1] &= (0x01 << 4U*(pin%4));
    } else if (p_port == GPIOC){
      SYSCFG -> EXTICR[1] &= (0x02 << 4U*(pin%4));
    }
  }
  else if (pin>8 && pin <12){
    SYSCFG -> EXTICR[2] |= (0x0f << 4U*(pin%4));
    if (p_port == GPIOA){
      SYSCFG -> EXTICR[2] &= (0x00 << 4U*(pin%4));
    } else if (p_port == GPIOB){
      SYSCFG -> EXTICR[2] &= (0x01 << 4U*(pin%4));
    } else if (p_port == GPIOC){
      SYSCFG -> EXTICR[2] &= (0x02 << 4U*(pin%4));
    }
  }
  else if (pin>12 && pin <16){
    SYSCFG -> EXTICR[3] |= (0x0f << 4U*(pin%4));
    if (p_port == GPIOA){
      SYSCFG -> EXTICR[3] &= (0x00 << 4U*(pin%4));
    } else if (p_port == GPIOB){
      SYSCFG -> EXTICR[3] &= (0x01 << 4U*(pin%4));
    } else if (p_port == GPIOC){
      SYSCFG -> EXTICR[3] &= (0x02 << 4U*(pin%4));
    }
  }

  if (mode & TRIGGER_RISING_EDGE){ //& same as ==
    EXTI -> RTSR &= ~BIT_POS_TO_MASK(pin);
    EXTI -> RTSR |= BIT_POS_TO_MASK(pin);

  } if (mode & TRIGGER_FALLING_EDGE){
    EXTI -> FTSR &= ~BIT_POS_TO_MASK(pin);
    EXTI -> FTSR |= BIT_POS_TO_MASK(pin);

  }if (mode & TRIGGER_ENABLE_EVENT_REQ){
    EXTI -> EMR &= ~BIT_POS_TO_MASK(pin);
    EXTI -> EMR |= BIT_POS_TO_MASK(pin);
    
  }if (mode & TRIGGER_ENABLE_INTERR_REQ){
    EXTI -> IMR &= ~BIT_POS_TO_MASK(pin);
    EXTI -> IMR |= BIT_POS_TO_MASK(pin);
  }if(mode & TRIGGER_BOTH_EDGE){
    EXTI -> RTSR &= ~BIT_POS_TO_MASK(pin);  
    EXTI -> RTSR |= BIT_POS_TO_MASK(pin); 
    EXTI -> FTSR &= ~BIT_POS_TO_MASK(pin); 
    EXTI -> FTSR |= BIT_POS_TO_MASK(pin);
  }
}

/**
* @brief Read the value of a specific GPIO pin on a given port.
* This function reads the value of a specific pin on a GPIO port and returns it as a boolean.
* @param p_port A pointer to the GPIO port.
* @param pin The pin number to read.
* @note If the pin is high, the function returns true. If the pin is low, the function returns false.
*/
bool port_system_gpio_read	(	GPIO_TypeDef *p_port, uint8_t pin ){
  bool value = (bool)(p_port -> IDR &= BIT_POS_TO_MASK(pin) );
  return value;
}

/**
* @brief Write a value to a specific GPIO pin on a given port.
* This function writes a boolean value to a specific pin on a GPIO port.
* @param p_port A pointer to the GPIO port.
* @param pin The pin number to write to.
* @param value The boolean value to write.
* @note If the value is true, the pin is set to high. If the value is false, the pin is set to low.
*/
void port_system_gpio_write	(	GPIO_TypeDef *p_port, uint8_t pin, bool value ){
  if (value == false){
    p_port -> BSRR = BIT_POS_TO_MASK(pin<<16) ;
  } else if ( value == true){
    p_port -> BSRR = BIT_POS_TO_MASK(pin) ;
  }
}

/**
* @brief Toggle the state of a specific GPIO pin on a given port.
* This function toggles the state of a specific pin on a GPIO port.
* @param p_port A pointer to the GPIO port.
* @param pin The pin number to toggle.
* @note The state of the pin is read before it is toggled to ensure that it switches between high and low.
*/
void port_system_gpio_toggle	(	GPIO_TypeDef *p_port, uint8_t pin){
  bool control = port_system_gpio_read	(p_port, pin );
  port_system_gpio_write (p_port, pin, !control);
}


/**
 * @brief Configures the Alternate Function of a specific GPIO pin on a given port.
 * If the pin is lower than 8, writes over the AFRL register, if its greater, writes over AFRH
 * 
 * @param port Port of the GPIO (CMSIS struct like)
 * @param pin Pin/line of the GPIO (index from 0 to 15)
 * @param alternate Alternate function number (values from 0 to 15)
 */
void port_system_gpio_config_alternate(GPIO_TypeDef *port, uint8_t pin, uint8_t alternate){
  if(pin<8){
    GPIOB -> AFR [0] &= ~BASE_MASK_TO_POS(BIT_MASK, 4*(pin%8));
    GPIOB -> AFR [0] |= (alternate << 4*(pin%8));
  }else{
    GPIOB -> AFR [1] &= ~BASE_MASK_TO_POS(BIT_MASK, 4*(pin%8));
    GPIOB -> AFR [1] |= (alternate << 4*(pin%8));
  }
}

//------------------------------------------------------
// INTERRUPT SERVICE ROUTINES
//------------------------------------------------------
/**
 * @brief This function handles the System tick timer that increments the system millisecond counter (global variable).
 * 
 * > **TO-DO alumnos:**
 * >
 * > ✅ 1. **Increment the System tick counter `msTicks` in 1 count.** \n
 * > &nbsp;&nbsp;&nbsp;&nbsp;💡 `msTicks` is a global `static` variable declared in @link port_system.c @endlink. \n
 *
 */
void SysTick_Handler(void)
{
  msTicks ++; /*Aumentamos el valor de la variable msTicks cada vez que se ejecuta esta interrupción, es decir, cada 1 ms*/
}

