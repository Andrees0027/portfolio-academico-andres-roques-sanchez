/**
 * @file port_tx.c
 * @brief Portable functions to interact with the infrared transmitter FSM library.
 * @author Andrés Roques Sánchez
 * @date fecha
 */

/* Includes ------------------------------------------------------------------*/
#include "port_tx.h"
#include "fsm_tx.h"
#include <math.h>
/* Defines --------------------------------------------------------------------*/
#define ALT_FUNC1_TIM2 1 /*!< TIM2 Alternate Function mapping */
#define ARR_TIM1 899 /*!< (Clock*(562.5/1000000))-1 */
#define ARR_TIM2 420 /*ARR = ((f_CLK ∗ T_PWM)/(PSC + 1))-1 */
#define TIM_AS_PWM1_MASK 0x0060 /*libro*/

// t_tick = NEC_TX_TIMER_TICK_BASE_US = 56.25 (us)
// t_symbol = 10*t_tick = 562.5 (us)
// PSCmin = ((fCLK ∗ TPWM)/ (ARRmax + 1))−1 
// DC deseado = 0.375 -> CCRx = 0,375 ∗ (ARR + 1)
// TPWM = 20 ms.
/* IMPORTANT
The timer symbol is the same for all the TX, so it is not in the structure of TX. It has been decided to be the TIM1. It is like a systick but faster.
*/

/* Typedefs --------------------------------------------------------------------*/
typedef struct{
GPIO_TypeDef * p_port;
uint8_t pin;
uint8_t alt_func;
} port_tx_hw_t;

/* Global variables ------------------------------------------------------------*/

/**
 * @brief Variable to store the count of ticks of the symbol timer
*/
static volatile uint32_t symbol_tick;

/**
 * @brief Array of elements that represents the HW characteristics of the infrared transmiters.
 */
static port_tx_hw_t transmitters_arr[] = {
  [IR_TX_0_ID] = {.p_port = IR_TX_0_GPIO, .pin = IR_TX_0_PIN, .alt_func = ALT_FUNC1_TIM2},
};

/* Infrared transmitter private functions */
/**
 * @brief  This function enables the TIM1 timer, sets the counter mode to up-counting and the auto-reload preload enable. 
 * It sets the counter value to 0, sets the auto-reload register to the calculated value, and sets the prescaler to 0.
 * It triggers an update event and clears the update interrupt flag. 
 * It sets the interrupt priority to 1 and enables the TIM1 interrupt.
 * 
 */
static void _timer_symbol_setup()
{
  RCC -> APB2ENR |= RCC_APB2ENR_TIM1EN;
  TIM1 -> CR1 &= ~TIM_CR1_CEN;
  TIM1 -> CR1 |= TIM_CR1_ARPE; 
  TIM1 -> CNT = 0;
  TIM1 -> ARR = ARR_TIM1; 
  TIM1 -> PSC = 0;
  TIM1 -> EGR = TIM_EGR_UG;
  TIM1 -> SR = ~TIM_SR_UIF;
  TIM1 -> DIER |= TIM_DIER_UIE;

  /* Finally, set the priority and enable interruptions globally. */
  NVIC_SetPriority(TIM1_UP_TIM10_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 1, 0)); /* Priority 1, sub-priority 0 */
  NVIC_EnableIRQ(TIM1_UP_TIM10_IRQn);                                                          /* Enable interrupt */
}
/**
 * @brief This function sets up the timer used for pulse-width modulation (PWM). 
 * This function enables the TIM2 timer, sets the counter mode to up-counting and the auto-reload preload enable. 
 * It sets the counter value to 0, sets the auto-reload register, and sets the prescaler to 0. 
 * It triggers an update event and clears the update interrupt flag.
 * It disables the capture/compare channel 1 output, sets the capture/compare mode register, sets the capture/compare output preload enable and register. 
 * It enables the capture/compare channel 1 output and enables the TIM2 counter.
 * 
 * @param tx_id 
 */
static void _timer_pwm_setup(uint32_t tx_id)
{
  if(tx_id == IR_TX_0_ID){
    RCC -> APB1ENR |= RCC_APB1ENR_TIM3EN;
    TIM2 -> CR1 &= ~TIM_CR1_CEN;
    TIM2 -> CR1 |= TIM_CR1_ARPE; 
    TIM2 -> CNT = 0; 
    TIM2 -> ARR = ARR_TIM2; /*ARR = ((f_CLK ∗ T_PWM)/(PSC + 1))-1 */
    TIM2 -> PSC = 0;
    TIM2 -> EGR = TIM_EGR_UG; 
    TIM2 -> CCER &= ~TIM_CCER_CC1E;
    TIM2 -> CCMR2 |= TIM_AS_PWM1_MASK ; /* Modo PWM 1 */
    TIM2 -> CCMR2 |= TIM_CCMR2_OC3PE ; /* Habilita el preload */
    TIM2 -> CCR1 = 157;
  }  
}

/* Public functions */
/**
 * @brief This function configures the GPIO port and pin, sets the GPIO alternate function, sets up the timer used for symbol timing and for pwr, and sets the PWM timer status.
 * @param tx_id 
 * @param status 
 */
void port_tx_init(uint8_t tx_id, bool status)
{ 
  port_system_gpio_config(transmitters_arr[tx_id].p_port, transmitters_arr[tx_id].pin, GPIO_MODE_ALTERNATE, 0x00);
  port_system_gpio_config_alternate(transmitters_arr[tx_id].p_port, transmitters_arr[tx_id].pin,transmitters_arr[tx_id].alt_func);
  _timer_symbol_setup();
  _timer_pwm_setup(tx_id);
  port_tx_pwm_timer_set(tx_id, status);
}

/* In order to make the academic effort of configuring the PWM, the values: timer, channel and masks are hardcoded and this function is not generic for any timer/channel. It is not the best way, but it is as it. */
/**
 * @brief This function enables or disables the capture/compare channel 1 output and enables or disables the TIM2 counter depending on the specified status.
 * @param tx_id 
 * @param status 
 */
void port_tx_pwm_timer_set(uint8_t tx_id, bool status){
  if(tx_id == IR_TX_0_ID){ /*Just if I have more transmitters (not the case)*/
    if (status == true){ 
      TIM2 -> CCER |= TIM_CCER_CC3E; /*enable the output compare*/
      TIM2 -> CR1 |= TIM_CR1_CEN; /*enable the counter of the PWM*/
    }
    else {
      TIM2 -> CCER &= ~TIM_CCER_CC3E; /*disable the output compare*/
      TIM2 -> CR1 &= ~TIM_CR1_CEN; /*disable the counter of the PWM*/
    }
  }
}
/**
 * @brief This function sets the counter value to 0 and enables the TIM1 counter. 
 * It also initializes the symbol_tick variable to 0.
 */
void port_tx_symbol_tmr_start(){
  TIM1 -> CNT = 0;
  TIM1 -> CR1 |= TIM_CR1_CEN;
  symbol_tick = 0;
}

/**
 * @brief This function disables the TIM1 counter.
 */
void port_tx_symbol_tmr_stop(){
  TIM1 -> CR1 &= ~TIM_CR1_CEN;
}

/**
 * @brief The function returns the current tick value of the port transmission timer. 
 * The tick value is incremented periodically in the interrupt service routine of the timer.
 * @return uint32_t 
 */
uint32_t port_tx_tmr_get_tick(){
  return symbol_tick;
}

//------------------------------------------------------
// INTERRUPT SERVICE ROUTINES
//------------------------------------------------------
/**
 * @brief Interrupt service routine for TIM1 Update and TIM10 global interrupts.
 * This interrupt service routine increments the tick value of the port transmission timer to know the time since the timer was started. 
 */
void TIM1_UP_TIM10_IRQHandler(void)
{
  TIM1 -> SR = ~TIM_SR_UIF;
  symbol_tick++;
}