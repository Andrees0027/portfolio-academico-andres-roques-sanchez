#!/usr/bin/env python

from lib_mv import MV
import logging, sys, subprocess, json, os

def init_log():
    # Creacion y configuracion del logger
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger('auto_p2')
    ch = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', "%Y-%m-%d %H:%M:%S")
    ch.setFormatter(formatter)
    log.addHandler(ch)
    log.propagate = False

def pause():
    programPause = input("Press the <ENTER> key to continue...")

def loadJSON():
    with open('auto-p2.json') as f:
        data = json.load(f)
        global DEBUG
        DEBUG = data['debug']
        global NUM_SERV
        NUM_SERV = data['num_serv']
        if NUM_SERV < 1 or NUM_SERV > 5:
            print('Error: el número de servidores debe ser entre 1 y 5')
            quit()

def debugMessage(mv, m):
    if DEBUG:
        if m == "init":
            log.debug("{} inicializada".format(mv))
        elif m == "create":
            log.debug("{} creada".format(mv))
        elif m == "start":
            log.debug("{} arrancada".format(mv))
        elif m == "console":
            log.debug("{} mostrando su consola".format(mv))
        elif m == "stop":
            log.debug("{} parada".format(mv))
        elif m == "destroy":
            log.debug("{} destruida".format(mv))
    else: 
        return


# Main
init_log()
log = logging.getLogger('auto_p2')
print('CDPS - mensaje info1')
NUM_SERV = 0
DEBUG = False
loadJSON()
mv_dict = {}
MVs = ["c1", "s1", "s2", "s3", "s4", "s5", "lb"]

orden = sys.argv[1]

if DEBUG:
    log.debug('Orden recibida: ' + orden)
    log.debug('Procediendo a ' + orden + ' las máquinas virtuales')


if orden == "crear":

    if DEBUG:
        log.debug("Borrando ficheros de MVs de ejecuciones anteriores")

    for i in range(0, len(MVs)):
        subprocess.call("rm {}.xml".format(MVs[i]), shell=True)
        subprocess.call("rm {}.qcow2".format(MVs[i]), shell=True)

    print('CDPS - Creando Máquinas virtuales ...')

    c1 = MV('c1')
    debugMessage("c1", "init")
    c1.crear_mv('c1.qcow2', '10.11.1.2', False )
    debugMessage("c1", "create")
    
    for i in range(1, NUM_SERV + 1):
        mv_dict['s{}'.format(i)] = MV('s{}'.format(i))
        debugMessage("s{}".format(i), "init")
        mv_dict['s{}'.format(i)].crear_mv('s{}.qcow2'.format(i), "10.11.2.3{}".format(i), False)
        debugMessage("s{}".format(i), "create")
    
    lb = MV('lb')
    debugMessage("lb", "init")

    lb.crear_mv('lb.qcow2', ["10.11.1.1", "10.11.2.1"], True )
    debugMessage("lb", "create")

        

elif orden == "arrancar":

    
    for i in range(1, NUM_SERV + 1):

        mv_dict['s{}'.format(i)] = MV('s{}'.format(i))
        debugMessage("s{}".format(i), "init")

        mv_dict['s{}'.format(i)].arrancar_mv()
        debugMessage("s{}".format(i), "start")

        mv_dict['s{}'.format(i)].mostrar_consola_mv()
        debugMessage("s{}".format(i), "console")


        
    c1 = MV('c1')
    debugMessage("c1", "init")
    c1.arrancar_mv()
    debugMessage("c1", "start")
    c1.mostrar_consola_mv()
    debugMessage("c1", "console")

    lb = MV('lb')
    debugMessage("c1", "init")
    lb.arrancar_mv()
    debugMessage("c1", "start")
    lb.mostrar_consola_mv()
    debugMessage("c1", "console")


elif orden == "parar":

    vm = sys.argv[2]

    VM = MV(vm)
    debugMessage(vm, "init")

    VM.parar_mv()


elif orden == "liberar":

    vm = sys.argv[2]

    VM = MV(vm)
    debugMessage(vm, "init")
    VM.liberar_mv()

elif orden == "monitor":
    print('CDPS - Monitorizando el estado de las máquinas virtuales ...')

    # Obtenemos información del estado de las máquinas virtuales con virsh
    for vm_name in MVs:
        subprocess.call(f"sudo virsh domstate {vm_name}", shell=True)
        subprocess.call(f"sudo virsh dominfo {vm_name}", shell=True)
        subprocess.call(f"sudo virsh cpu-stats {vm_name}", shell=True)
        print("\n" + "-"*40 + "\n")

    # Verificamos la conectividad con las máquinas virtuales usando ping
    for vm_name in MVs:
        if vm_name == "c1":
            subprocess.call(f"ping -c 3 10.11.1.2", shell=True)
        if vm_name == "s1":
            subprocess.call(f"ping -c 3 10.11.2.31", shell=True)
        if vm_name == "s2":
            subprocess.call(f"ping -c 3 10.11.2.32", shell=True)
        if vm_name == "s3":
            subprocess.call(f"ping -c 3 10.11.2.33", shell=True)
        if vm_name == "s4":
            subprocess.call(f"ping -c 3 10.11.2.34", shell=True)
        if vm_name == "s5":
            subprocess.call(f"ping -c 3 10.11.2.35", shell=True)
        if vm_name == "lb":
            subprocess.call(f"ping -c 3 10.11.1.1", shell=True)

else:
    print("Pero pon un comando espabilao")



