import logging, subprocess, os
from lxml import etree
import os.path as path
import json

log = logging.getLogger('auto_p2')

def pause():
    programPause = input("Press the <ENTER> key to continue...")

def myLogger(m):
    with open('auto-p2.json') as f:
        data = json.load(f)
        global DEBUG
        DEBUG = data['debug']
    if DEBUG:
        log.debug(m)

class MV:
    def __init__(self, nombre):
        self.nombre = nombre
        log.debug('init MV ' + self.nombre)

        def xmlEditor(nombre):
            tree = etree.parse(nombre+".xml")
            print(etree.tounicode(tree, pretty_print=True))
            root = tree.getroot()
            print(root.tag)

            name = root.find("name")
            name.text = nombre
            devices = root.find("devices")
            source = root.find("devices/disk/source")
            source.set("file", '/mnt/tmp/' + nombre + '.qcow2')

            interface_source_element = root.find("devices/interface/source")
            if nombre in ['c1']:
                interface_source_element.set("bridge", "LAN1")
                
            elif nombre in ['lb']:
                interface_source_element.set("bridge", "LAN1")
                interface2 = etree.SubElement(devices, "interface", type="bridge")
                bridge2 = etree.SubElement(interface2, "source", bridge="LAN2")
                model2 = etree.SubElement(interface2, "model", type="virtio")
                etree.indent(root)
                print(etree.tounicode(root.find("devices"), pretty_print=True))
            elif nombre in ['s1', 's2', 's3', 's4', 's5']:
                interface_source_element.set("bridge", "LAN2")
            print(etree.tounicode(tree, pretty_print=True))
            f = open(nombre + ".xml", 'wb')
            f.write(etree.tostring(root, pretty_print=True))
            f.close()

        if not path.exists(self.nombre+'.qcow2'):
            subprocess.call("qemu-img create -f qcow2 -b cdps-vm-base-pc1.qcow2 " + self.nombre + ".qcow2", shell=True)
            myLogger("Imagen {}.qcow2 creada".format(self.nombre))
        if not path.exists(self.nombre+'.xml'):
            subprocess.call("cp plantilla-vm-pc1.xml " + self.nombre + ".xml", shell=True)
            xmlEditor(self.nombre)
            myLogger("Plantilla {}.xml creada y editada".format(self.nombre))

        
    

        
        

        
    

    def crear_mv(self, imagen, interfaces_red, router):
        log.debug("crear_mv " + self.nombre)

        # Creación e inicialización de las redes LAN del escenario
        subprocess.call("sudo brctl addbr LAN1", shell=True)
        myLogger("Red LAN1 creada")
        subprocess.call("sudo brctl addbr LAN2", shell=True)
        myLogger("Red LAN2 creada")
        subprocess.call("sudo ifconfig LAN1 up", shell=True)
        myLogger("Red LAN1 inicializada")
        subprocess.call("sudo ifconfig LAN2 up", shell=True)
        myLogger("Red LAN2 inicializada")

        if router:
            subprocess.call("sudo virt-edit -a " + self.nombre + ".qcow2 /etc/sysctl.conf -e 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/'", shell=True)
            myLogger("lb configurado como ROUTER")

        # Creación de ficheros de configuración de las MVs
        with open("interfaces", "w") as f:
            if self.nombre == "c1":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.1.1")
            elif self.nombre == "lb":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red[0] + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1\nauto eth1\niface eth1 inet static\n  address " + interfaces_red[1] + "\n  netmask 255.255.255.0\n  gateway 10.11.1.1")
            elif self.nombre == "s1":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1")
            elif self.nombre == "s2":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1")
            elif self.nombre == "s3":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1")
            elif self.nombre == "s4":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1")
            elif self.nombre == "s5":
                f.write("auto lo\niface lo inet loopback\n\nauto eth0\niface eth0 inet static\n  address " + interfaces_red + "\n  netmask 255.255.255.0\n  gateway 10.11.2.1")
        
        # Creación de ficheros de configuración a las MVs
        subprocess.call("sudo virt-edit -a "+ self.nombre +".qcow2 /etc/hostname -e 's/cdps.*/"+ self.nombre + "/'" , shell=True)
        myLogger("Fichero /etc/hostname editado correctamente, comprobar a continuación")
        subprocess.call("sudo virt-cat -a " + self.nombre + ".qcow2 /etc/hostname", shell=True)

        subprocess.call("sudo virt-copy-in -a " + self.nombre + ".qcow2 interfaces /etc/network/", shell=True)
        myLogger("Fichero /etc/network/interfaces copiado correctamente, comprobar a continuación")
        subprocess.call("sudo virt-cat -a " + self.nombre + ".qcow2 /etc/network/interfaces", shell=True)
        
        subprocess.call("sudo virt-edit -a " + self.nombre + ".qcow2 /etc/hosts -e 's/127.0.1.1.*/127.0.1.1 " + self.nombre + "/'", shell=True)
        myLogger("Fichero /etc/hosts editado correctamente, comprobar a continuación")
        subprocess.call("sudo virt-cat -a " + self.nombre + ".qcow2 /etc/hosts", shell=True)

        # Configuración de las páginas web iniciales de las MVs
        subprocess.call("xterm -rv -sb -rightbar -fa monospace -fs 10 -title '" + self.nombre + "' -e 'sudo bash -c 'echo {} > /var/www/html/index.html'' &".format(self.nombre), shell=True)
        myLogger("Fichero index.html configurado correctamente")

        # Configuración del balanceador de carga
        if self.nombre == "lb":
            subprocess.call("xterm -rv -sb -rightbar -fa monospace -fs 10 -title '" + self.nombre + "' -e 'sudo service apache2 stop", shell=True)
            myLogger("Servidor apache de lb detenido")
            pause()
            new_lines_to_append = "frontend lb\n  bind *:80\n  mode http\n  default_backend webservers\nbackend webservers\n  mode http\n  balance roundrobin\n  server s1 10.11.2.31:80 check\n  server s2 10.11.2.32:80 check\n  server s3 10.11.2.33:80 check\n  server s4 10.11.2.34:80 check\n  server s5 10.11.2.35:80 check"

            subprocess.run("ssh lb@10.11.1.1 'echo -e \"{ '\\n'.join(new_lines_to_append) }\" | sudo tee -a /etc/haproxy/haproxy.cfg' &", shell=True)
            #subprocess.call("sudo virt-copy-out -a lb.qcow2 /etc/haproxy/haproxy.cfg .", shell=True)
            #subprocess.call("chmod +w haproxy.cfg", shell=True)
            #with open("haproxy.cfg", "a") as f:
                #f.write("frontend lb\n  bind *:80\n  mode http\n  default_backend webservers\nbackend webservers\n  mode http\n  balance roundrobin\n  server s1 10.11.2.31:80 check\n  server s2 10.11.2.32:80 check\n  server s3 10.11.2.33:80 check\n  server s4 10.11.2.34:80 check\n  server s5 10.11.2.35:80 check")
            myLogger("Fichero haproxy.cfg editado")
            pause()
            subprocess.call("xterm -rv -sb -rightbar -fa monospace -fs 10 -title '" + self.nombre + "' -e 'sudo service haproxy restart", shell=True)
            myLogger("Servicio Haproxy restablecido")
            pause()
        
        
        # Definición de la MV a partir del fichero XML
        subprocess.call("sudo virsh define " + self.nombre + ".xml", shell=True)
        myLogger("{} inicializada correctamente".format(self.nombre))
        myLogger("Lista de MVs inicializadas")
        subprocess.call("sudo virsh list --all", shell=True)

        
    def arrancar_mv(self):
        log.debug("arrancar_mv " + self.nombre)
        subprocess.call("sudo ifconfig LAN1 10.11.1.3/24", shell=True)
        subprocess.call("sudo ip route add 10.11.0.0/16 via 10.11.1.1", shell=True)
        subprocess.call("sudo virsh start " + self.nombre, shell=True)
        myLogger("{} arrancada correctamente".format(self.nombre))



    def mostrar_consola_mv(self):
        log.debug("mostrar_mv " + self.nombre)
        subprocess.call("xterm -e 'sudo virsh console " + self.nombre + "' &", shell=True)
        myLogger("{} mostrando su consola correctamente".format(self.nombre))

    def parar_mv(self):
        log.debug("parar_mv " + self.nombre)
        subprocess.call("sudo virsh shutdown " + self.nombre, shell=True)
        myLogger("{} parada correctamente".format(self.nombre))


    def liberar_mv(self):
        log.debug("liberar_mv " + self.nombre)
        subprocess.call("sudo virsh destroy " + self.nombre, shell=True)
        myLogger("{} destruida correctamente".format(self.nombre))


# No se ha hecho uso de esta clase ni sus métodos en el proyecto

"""
class Red:
    def __init__(self, nombre):
        self.nombre = nombre
        log.debug('init Red ' + self.nombre)

    def crear_red(self):
        log.debug('crear_red ' + self.nombre)

    def liberar_red(self):
        log.debug('liberar_red ' + self.nombre)
"""
