export default {
  mapsApiKey: 'YOUR_GOOGLE_MAPS_API_KEY',
  mapId: 'YOUR_MAP_ID'
};
