import { useState } from "react";
import { useEffect } from 'react';
import './App.css';
import Header from "./Header";
import SearchPage from "./Searchpage";
import Page from './Page';
import NotFound from "./NotFound";
import {Routes,  Route} from "react-router-dom";
import Spinner from 'react-bootstrap/Spinner';
import CONFIG from "./config/config";
import {mockdata} from "./constants/products"; 
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  const [resultado, setResultado] = useState (mockdata.products);
  const [loading,setLoading]= useState(true);
  const USE_SERVER = CONFIG.use_server;


  useEffect(() => {
    if (loading) {
      setTimeout(() => {
      setLoading(false);
    }, 1000);
    }
  }, [loading]);

  async function callServer(){
    if (USE_SERVER){
      try {
        const response = await fetch(`${CONFIG.server_url}`);
        const data = await response.json();    
        setResultado(data.products);
      } catch (error) {
        console.log(error);
        setResultado({ error: {description: error.message} });
      }
    } else {
      setResultado(mockdata.products);
    }
  }
  useEffect(() =>{
    callServer();
  }, []);

return (
  // <Router>
    <div id="main">
        <Header />
        {loading ? <Spinner id="loading" className='spinner' animation="border" role="status">
          <span className="visually-hidden">Cargando...</span>
          </Spinner> : 
          <Routes>
            <Route exact path="/" element={resultado && <SearchPage theproducts={resultado}/>}/>
            <Route exact path="/products/:productId" element={resultado && <Page theproducts={resultado} />}/>
            <Route exact path="*" element={<NotFound />} />
          </Routes>  
        }     
    </div>
    // </Router>
  );
}



export default App;
