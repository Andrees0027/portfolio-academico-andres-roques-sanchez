import logo from './logo.svg';
import React from 'react';
export default function Header() {  
  return (
    <div id="cabecera">
      <img className="logo" src={logo} alt="logo" id="logo"/>
      <h3 className="mensaje">Andrés Roques Sánchez</h3>      
    </div>
  )  
}

