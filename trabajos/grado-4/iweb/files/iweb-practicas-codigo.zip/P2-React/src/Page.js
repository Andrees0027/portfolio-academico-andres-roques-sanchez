import {Link, useParams} from "react-router-dom";
import Location from "./Location"

export default function Page (props){

    let { productId } = useParams();
    return (<div id="main">
        <Location/>
        <p id="titulo">Nombre:<b> {props.theproducts[productId].title}</b></p>
        <img src={props.theproducts[productId].images[3]}/>
         <p> Descripcion: <b>{props.theproducts[productId].description}</b></p>
           <p>Price: {props.theproducts[productId].price}$</p>
            <p>Rating:{props.theproducts[productId].rating}</p>
            <p>Stock:{props.theproducts[productId].stock}</p>
        <Link to="/"><button className="index" id="volver">Volver</button></Link>
    </div>
    )
    }