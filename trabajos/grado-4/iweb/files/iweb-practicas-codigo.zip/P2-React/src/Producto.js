import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';

export default function Producto (props){
    <div id='proucto'>
        {props.productosListados.map(item => (
        <Card className="unproducto">
        <Card.Img variant="top" src={item.images[0]} />
        <Card.Body>
               <Card.Title>{item.title}</Card.Title>
                <Card.Text>{item.description}</Card.Text>
               <Button variant="primary">Ver</Button>
        </Card.Body>
        </Card>
        ))}
    </div>
}

