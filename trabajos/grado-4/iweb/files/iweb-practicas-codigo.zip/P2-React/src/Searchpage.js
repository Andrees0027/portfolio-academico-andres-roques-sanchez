import React, { useState } from 'react';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Location from "./Location"

export default function SearchPage (props) {
    const [query, setQuery] = useState("");
    const [filteredProducts, setFilteredProducts] = useState(null);
    const [productos, setProductos] = useState(true);
    const [selectedProducts, setSelectedProducts] = useState(null);
    const [selector, setSelector] = useState(null);

    const callServer = () =>{
        setProductos(false);
        setSelectedProducts(false)
        setFilteredProducts(props.theproducts.filter(item => item.title.toLowerCase().includes(query)));
    }

    const categoriasRepetidas= props.theproducts.map(item=>item.category);
    const categorias = categoriasRepetidas.reduce(
        (previousValue,currentValue)=>{
            if(!previousValue.includes(currentValue)){
                return [...previousValue,currentValue];
            }
            return previousValue;
        },
    [],
    );

    const filtrador = (f) =>{
        setSelector(f);
        if (f==="All"){
            setProductos(false);
            setFilteredProducts(false);
            setSelectedProducts(props.theproducts.filter(item => item.category.includes(f)));
        }
        else{
            setProductos(false);
            setFilteredProducts(false);
            setSelectedProducts(props.theproducts.filter(item => item.category.includes(f)));
        }
    }

  return (

    <div>
        <Location/>
        <h2 id="catálogo">Catálogo</h2>
        <div className='search-input'>
        <input type="text" id="filtro" placeholder="Buscar productos..." value={query} onChange={(e) => setQuery(e.target.value)}/>
        <button id="buscador" onClick={()=>callServer()}>Buscar</button>
        <p></p><p></p><p></p><p></p><p></p><p></p>
        <label for="filtro"> Filtrar </label>
                    <select id="selector" name="filtrado" onChange={e=>filtrador(e.target.value)}>
                        <option value="All">All</option>
                        {categorias.map(item=> ( 
                        <option value={item}>
                        {item}</option> ))}
                    </select> 
        </div>
        <div id="resultados">
            {productos && <div id="productosresultados">
            {props.theproducts.map((item,index) => (
            <Card className="unproducto" key={index.toString()}>
            <Card.Img className="foto" variant="top" src= {item.images[0]} />
                <Card.Body>
                    <Card.Title>{item.title}</Card.Title>
                    <Card.Text>{item.description}</Card.Text>
                    <Link to={"/products/"+index}><Button variant="primary" className="show">ver</Button></Link>   
                </Card.Body>
            </Card>
            ))}</div>}

            {filteredProducts && <div id="productosresultados">
            {filteredProducts.map((item, index) => (
            <Card className="unproducto" key={index.toString()}>
            <Card.Img variant="top" src={item.images[0]} />
                <Card.Body >
                    <Card.Title>{item.title}</Card.Title>
                    <Card.Text>{item.description}</Card.Text>
                    <Link to={"/products/"+index}><Button variant="primary" className="show">ver</Button></Link>
                </Card.Body>
            </Card>
            ))}</div>}

            {selectedProducts && <div id="productosresultados">
            {selectedProducts.map((item, index) => (
            <Card className="unproducto" key={index.toString()}>
            <Card.Img variant="top" src={item.images[0]} />
                <Card.Body >
                    <Card.Title>{item.title}</Card.Title>
                    <Card.Text>{item.description}</Card.Text>
                    <Link to={"/products/"+index}><Button variant="primary" className="show">ver</Button></Link>
                </Card.Body>
            </Card>
            ))}</div>}
        </div>
    </div>
  );
};










