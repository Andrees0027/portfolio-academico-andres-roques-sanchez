import { View, Text, Image, StyleSheet  } from "react-native"
export default function Header (props){
    return(
        <View testID="cabecera" style={styles.cabecera}>
            <Image source={require("../assets/favicon.png")} style={styles.image} testID="logo" alt="logo pagina"/>
            <Text testID="mensaje">Andres Roques Sanchez</Text>
        </View>
    )
}
const styles = StyleSheet.create({
    image: {
      width:60,
      height:60,
    },
    cabecera: {
        backgroundColor: '#888',
        padding: 10,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
      }
  });