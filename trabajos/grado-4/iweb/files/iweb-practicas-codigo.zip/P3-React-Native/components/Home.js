import {mockdata} from "./constants/products"
import Header from "./Header"
import SearchPage from './SearchPage'
import {useState, useEffect} from 'react';
import CONFIG from "./config/config";
import {Image, View, StyleSheet} from "react-native";
import Pagina from "./Pagina";

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

function Home() {
  const [resultado, setResultado]=useState(null)
  const [loading,setLoading]= useState(true);
  const USE_SERVER = CONFIG.use_server;
  const SERVER_URL=CONFIG.server_url;
 
  useEffect(() => {
    if (loading) {
      setTimeout(() => {
      setLoading(false);
    }, 200);
    }
  }, [loading]);

  const callServer = async () => {    
    if(USE_SERVER) {
      try {
        const response = await fetch(SERVER_URL);
        const data = await response.json(); 
        setResultado(data.products);
      } catch (error) {
        console.log(error);
        setResultado({ error: {description: error.message} });
      }
    } else {
      setResultado(mockdata.products);
    }
}
useEffect(() =>{
  callServer();
}, []);

  return (
    <View className="App" style={styles.container}>
    <NavigationContainer>
        <Header/>
        {loading ? <Image testID="loading" source={{uri: "https://i.stack.imgur.com/hzk6C.gif"}} style={styles.image} /> :
          <Stack.Navigator>
          <Stack.Screen name='Home'>
            { props => <SearchPage {...props} theproducts={resultado}/>}
          </Stack.Screen>
          <Stack.Screen name='Pagina' component = {Pagina}/>
        </Stack.Navigator>
        }
      </NavigationContainer>

  </View>
  );
}
const styles = StyleSheet.create({
  image: {
    flex: 1,
    width:60,
    height:60
  },
  container: {
    flex:1,
    marginTop: 100,

  }
});

export default Home;
