import {Text, Button, View, Image, StyleSheet} from "react-native";

export default function Pagina (props){

return (
    <View testID="main">
        <Text testID="detalle">Nombre:{props.route.params.product.title}</Text>
        <Text>Descripcion: {props.route.params.product.description}</Text>
        <Text>Price: {props.route.params.product.price}$</Text>
        <Text>Rating:{props.route.params.product.rating}</Text>
        <Text>Stock:{props.route.params.product.stock}</Text>
        {/* <Image style={styles.image} source={{props.route.params.product.image}} /> */}

        <Button className="index" title="volver" testID="volver" onPress={() => props.navigation.navigate('Home')}/>
    </View>)
    }const styles = StyleSheet.create({
        image: {
          width:400,
          height:400
        }
    });