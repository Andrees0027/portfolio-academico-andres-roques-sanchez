import { useState } from "react";
import {Text, TextInput, Button, View, FlatList, Image, StyleSheet} from "react-native";
import Pagina from "./Pagina";

export default function SearchPage (props){
    const [query, setQuery] = useState("");
    const [filterProducts, setFilterProducts] = useState(null);
    const [productos, setProductos] = useState(props.theproducts);

    const callServer = () =>{
        setProductos(false);
        setFilterProducts(props.theproducts.filter(item => item.title.toLowerCase().includes(query)));
    }

    const renderItem = ({item}) => (
        <View key={item.id} style={styles.container}>
            <View testID={"item_"+item.id}>
            <Image style={styles.image} source={{uri:item.images[0]}}/>
            <View style={styles.texto}>
            <Text testID={"title_"+item.id}>Título: {item.title}</Text>
            <Text>Descripcion: {item.description}</Text>
            <Button testID={"button_"+item.id} title='Ver Detalles'onPress={()=> props.navigation.navigate('Pagina', {product:item} )}/>
            </View>
            </View>  
        </View>
      )
     
    return(
            <View testID="inicio">
            <View style= {styles.cabecera}>
            <Text testID="catalogo">Catálogo disponible:</Text>
            <TextInput type="text" testID="filtro" value={query} placeholder="Busque su producto" onChangeText={setQuery}/>
            <Button testID="buscador" title='Buscar' onPress={()=>callServer()}/>    
            </View>
            {productos  && <View>
                <FlatList
                data={productos}
                renderItem={renderItem}
                />
            </View>}
            {filterProducts  && <View>
                <FlatList
                data={filterProducts}
                renderItem={renderItem}
                />
            </View>}
            </View>         
    );
}const styles = StyleSheet.create({
    image: {
      width:400,
      height:400
    },
    content: {
      height: 300
    },
    texto:{
      backgroundColor: '#bbb'
    },
    container: {
      flex:1,
      backgroundColor: '#fff',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center'
    },
    cabecera: {
      backgroundColor: '#ccc',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center'
    },
    


  });

//el toLowerCase lo he puesto para que me coja y me busque las palabras aunque las ponga en minisculas
//            <MyButton testID={"button_"+item.id} title='Ver Detalles' onPress={()=>props.navigation.navigate('Pagina')} />

