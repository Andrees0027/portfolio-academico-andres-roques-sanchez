//
//  P4.1App.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 1/12/23.
//

import Foundation

import SwiftUI

@main
struct QuizApp: App {
    
    @StateObject var quizzesModel = QuizzesModel()
    @StateObject var scoresModel = ScoresModel()
    //@StateObject private var quizzesViewModel = QuizzesViewModel()
    
    var body: some Scene {
        WindowGroup {
            QuizzesView()
                .environmentObject(quizzesModel)
                .environmentObject(scoresModel)
                
        }
    }
}
