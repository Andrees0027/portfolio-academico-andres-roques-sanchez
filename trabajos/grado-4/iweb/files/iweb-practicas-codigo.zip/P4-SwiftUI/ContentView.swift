//
//  ContentView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 6/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            Text("Home")
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            .navigationTitle("Home")
            
        }
        .padding()

    }
}

#Preview {
    ContentView()
}
