//
//  EasyAsyncImage.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 1/12/23.
//

import Foundation
import SwiftUI

struct EasyAsyncImage: View {
    
    var url : URL?
    
    var body: some View {
        AsyncImage(url: url){ phase in
            if url == nil {
                Color.white
            } else if let image = phase.image {
                image.resizable()
            } else if phase.error != nil {
                Color.red
            } else {
                ProgressView()
            }
        }
    }
}

#Preview {
    EasyAsyncImage()
}
