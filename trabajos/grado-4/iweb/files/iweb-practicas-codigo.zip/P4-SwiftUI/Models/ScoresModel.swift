//
//  ScoresModel.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 22/11/23.
//

import Foundation

class ScoresModel: ObservableObject{
    
    @Published private(set) var acertadas: Set<Int> = []
    
    func add(answer: String, quiz: QuizItem){

        if (answer.lowercased() == quiz.answer.lowercased()){
            if (!acertadas.contains(quiz.id)){
                acertadas.insert(quiz.id)
            }else { return }	
        }
    }
}

