//
//  NavigationStackView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 6/11/23.
//

import SwiftUI

struct NavigationStackView: View {
    var body: some View {
        VStack{
             Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        }
    }
}

#Preview {
    NavigationStackView()
}
