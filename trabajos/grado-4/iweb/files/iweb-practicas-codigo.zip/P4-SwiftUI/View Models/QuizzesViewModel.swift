//
//  QuizzesViewModel.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 6/11/23.
//

import Foundation

class QuizzesViewModel: ObservableObject {
    
    //Modelo
    @Published private var model = QuizzesModel()
    
    
    var quizzes: [QuizItem] {
        model.quizzes
    }
    
    
}
