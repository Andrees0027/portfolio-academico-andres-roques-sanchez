//
//  PlayingView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 15/11/23.
//

import SwiftUI

struct PlayingView: View {
    
    var quizItem: QuizItem
    
    @State var answer : String  = ""
    @State var showCheckAlert = false
    @EnvironmentObject var scoresModel: ScoresModel
    
    var body: some View {
        VStack{
            titulo
            Spacer()
            pregunta
            Spacer()
            Spacer()
            adjunto
            Spacer()
            autor
            Spacer()
            puntuacion
            
        }
        .padding()
        .navigationTitle("Quiz game")
    }
    
    private var pregunta : some View {
        VStack{
            TextField("Introduzca su respuesta", text: $answer)
                .textFieldStyle(.roundedBorder)
                .onSubmit {
                    if (answer.lowercased() == quizItem.answer.lowercased()){
                        scoresModel.add(answer: answer, quiz: quizItem)
                        print("Respuesta correcta")
                    }
                    showCheckAlert = true
                }
            
            Button("Compruebe su respueta"){
                if (answer.lowercased() == quizItem.answer.lowercased()){
                    scoresModel.add(answer: answer, quiz: quizItem)
                    print("Respuesta incorrecta")
                }
                showCheckAlert = true
            }
        }
        .alert("Resultado", isPresented: $showCheckAlert){
        } message: {
            Text(answer.lowercased() == quizItem.answer.lowercased() ? "correcto": "incorrecto")
        } //FALTA UNA EXTENSION PARA EL MAS O MENOS IGUAL
    }
    
    
    private var titulo : some View {
        HStack{
            Text(quizItem.question)
                .font(.title)
                .fontWeight(.bold)
            Spacer()
            Image(quizItem.favourite ? "Estrella_amarilla" : "Estrella_gris")
                .resizable()
                .imageScale(.small)
                .frame(width: 30, height: 30)
        }
    }
    
    
    
    
    private var autor : some View {
        HStack{
            Spacer()
            Text(quizItem.author?.username ??
                 quizItem.author?.profileName ??
                 "Anonimo")
            
            EasyAsyncImage(url: quizItem.author?.photo?.url)
                .frame(width: 30, height: 30)
                .scaledToFill ()
                .clipShape(Circle())
                .overlay {
                    Circle().stroke(Color.blue, lineWidth: 2)
                }
                .shadow(color: .black, radius: 15, x: 0.0, y:0.0)
        }
    }
    
    
    private var adjunto : some View {
        GeometryReader { g in
            EasyAsyncImage(url: quizItem.attachment?.url)
                .saturation(showCheckAlert ? 0:1)
                .scaledToFill()
                .frame(width: g.size.width, height: g.size.height)
                .clipShape(RoundedRectangle(cornerRadius: 25))
                .overlay{
                    RoundedRectangle(cornerRadius: 25).stroke(Color.black, lineWidth: 2)
                }
                .shadow(color: .black, radius: 6, x: 0, y: 0)
        }
    }
    
    private var puntuacion : some View {
        HStack {
            Text(" SU PUNTUACIÓN ES \(scoresModel.acertadas.count)")
        }
    }
}

