//
//  QuizItemRowView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 15/11/23.
//

import SwiftUI

struct QuizItemRowView: View{
    var quizItem: QuizItem
    var body: some View{
        AsyncImage(url:quizItem.attachment?.url)
        .frame(width:40, height:40)
        .clipped()
        Text(quizItem.question)
        Image(quizItem.favourite ? "estrella_amarilla" : "estrella_gris")
    }
}
#Preview {
    
    QuizItemRowView(quizItem: <#T##QuizItem#>)

    }
