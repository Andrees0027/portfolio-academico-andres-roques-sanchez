//
//  QuizzesListView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 15/11/23.
//

import SwiftUI

struct QuizzesListView: View {
    
    @State var quizzesModel = QuizzesModel()
    
   
    
    
    
    var quizItem: QuizItem
    var body: some View{
        HStack{
            EasyAsyncImage(url: quizItem.attachment?.url)
                .scaledToFit()
                .frame(width: 100, height: 100)
                .clipShape(Circle())
                .overlay{
                    Circle().stroke(Color.black, lineWidth: 1)
                }
                .shadow(color: .black, radius:10)

            Spacer()
            VStack{
            
                HStack{
                    Spacer()
	
                    Image(quizItem.favourite ? "Estrella_amarilla" : "Estrella_gris")
                        .resizable()
                        .imageScale(.small)
                        .frame(width: 30, height: 30)
                        
                    Spacer()

                    Text(quizItem.author?.profileName ?? "Anonimo")
                        .font(.caption)

                    EasyAsyncImage(url: quizItem.author?.photo?.url)
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .overlay{
                            Circle().stroke(Color.gray, lineWidth: 2)
                        }
                        .shadow(color: .gray, radius:5)
                }
                HStack{
                    Text(quizItem.question)
                        .lineLimit(3)

                }
            }
        }
        .padding()
    }

}
#Preview {
    let model: QuizzesModel = {
        let m = QuizzesModel()
        m.load()
        return m
    }()
    return QuizzesListView(quizItem: model.quizzes[0])}
