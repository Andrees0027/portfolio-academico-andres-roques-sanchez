//
//  ContentView.swift
//  P4_parte1_IWEB
//
//  Created by c156 DIT UPM on 6/11/23.
//

import SwiftUI
import Foundation

struct QuizzesView: View {
    
    @EnvironmentObject var quizzesModel: QuizzesModel
    @EnvironmentObject var scoresModel: ScoresModel
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(quizzesModel.quizzes) { quiz in
                    NavigationLink {
                        PlayingView(quizItem: quiz)

                    } label: {
                        QuizzesListView(quizItem: quiz)

                    }

                }
            }
            .navigationTitle("QUIZZ GAME")
            .listStyle(.plain)
            .onAppear{
                quizzesModel.load()
            }
        }
        .padding()
    }
    
}

